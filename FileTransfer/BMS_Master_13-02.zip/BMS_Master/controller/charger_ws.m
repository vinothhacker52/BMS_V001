
ChargerRes = 0;
ChargerParRes = 10000;
ChargerCap = 5e-3;