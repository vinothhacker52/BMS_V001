#ifndef SYSTEMGETVOLTAGE_H
#define SYSTEMGETVOLTAGE_H

#include "rtwtypes.h"

extern float SystemGetVoltage(uint8_T channel);

#endif
