/*
 * File: BMS_Master_private.h
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef BMS_Master_private_h_
#define BMS_Master_private_h_
#include "rtwtypes.h"
#include "BMS_Master_types.h"
#include "BMS_Master.h"

extern real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
  uint32_T maxIndex);

#endif                                 /* BMS_Master_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
