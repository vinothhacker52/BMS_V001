/*
 * File: BMS_Master_types.h
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef BMS_Master_types_h_
#define BMS_Master_types_h_
#include "rtwtypes.h"
#include "SystemState_t.h"
#ifndef DEFINED_TYPEDEF_FOR_BMSBatteryPackData_
#define DEFINED_TYPEDEF_FOR_BMSBatteryPackData_

typedef struct {
  real_T SegmentTempVector[18];
  real_T SegmentVoltageVector[18];
  real_T SegmentCurrentVector[18];
  real_T SegmentRealSOCVector[18];
} BMSBatteryPackData;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BMSContactorModuleData_
#define DEFINED_TYPEDEF_FOR_BMSContactorModuleData_

typedef struct {
  real_T IBatt;
  real_T VBatt;
} BMSContactorModuleData;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BusInputBMS_
#define DEFINED_TYPEDEF_FOR_BusInputBMS_

typedef struct {
  BMSBatteryPackData BMSBatteryPackData;
  BMSContactorModuleData BMSContactorModuleData;
} BusInputBMS;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SimulationSystemInput_
#define DEFINED_TYPEDEF_FOR_SimulationSystemInput_

typedef struct {
  SystemState_t SystemState;
  real_T DrivingCurrentRqst;
  real_T ChargingCurrentRequest;
} SimulationSystemInput;

#endif

#ifndef DEFINED_TYPEDEF_FOR_SimulationBatteryPackInput_
#define DEFINED_TYPEDEF_FOR_SimulationBatteryPackInput_

typedef struct {
  boolean_T ShortCircuitInjection[18];
  boolean_T OpenCircuitInjection[18];
} SimulationBatteryPackInput;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BusSimulationInput_
#define DEFINED_TYPEDEF_FOR_BusSimulationInput_

typedef struct {
  SimulationSystemInput SimulationSystemInput;
  SimulationBatteryPackInput SimulationBatteryPackInput;
} BusSimulationInput;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BusSOCEstimation_
#define DEFINED_TYPEDEF_FOR_BusSOCEstimation_

typedef struct {
  real_T EKFEstimation[18];
  real_T CDCEstimation[18];
} BusSOCEstimation;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BMSBatteryPackInput_
#define DEFINED_TYPEDEF_FOR_BMSBatteryPackInput_

typedef struct {
  boolean_T BalCmdVector[18];
  real_T balancingDeltaVCell;
  boolean_T balancingFlags;
} BMSBatteryPackInput;

#endif

#ifndef DEFINED_TYPEDEF_FOR_BusOutputBMS_
#define DEFINED_TYPEDEF_FOR_BusOutputBMS_

typedef struct {
  boolean_T ContactorOperationCmd;
  BMSBatteryPackInput BMSBatteryPackInput;
  BusSOCEstimation BusSOCEstimation;
} BusOutputBMS;

#endif

#ifndef DEFINED_TYPEDEF_FOR_DiagSts_
#define DEFINED_TYPEDEF_FOR_DiagSts_

typedef enum {
  NoFault = 0,                         /* Default value */
  OverCurrentWarning,
  OverCurrentFault,
  OverTemperatureWarning,
  OverTemperatureFault,
  OverVoltageWarning,
  OverVoltageFault,
  UnderVoltageWarning,
  UnderVoltageFault
} DiagSts;

#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM_BMS_Master_T RT_MODEL_BMS_Master_T;

#endif                                 /* BMS_Master_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
