/*
 * File: SystemState_t.h
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef SystemState_t_h_
#define SystemState_t_h_
#include "rtwtypes.h"

/* General System State enum typedef */
typedef int16_T SystemState_t;

/* enum SystemState_t */
#define SystemState_t_Parking          ((SystemState_t)0)        /* Default value */
#define SystemState_t_Driving          ((SystemState_t)1)
#define SystemState_t_Charging         ((SystemState_t)2)
#define SystemState_t_Balancing        ((SystemState_t)3)
#endif                                 /* SystemState_t_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
