/*
 * File: BMS_Master.h
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef BMS_Master_h_
#define BMS_Master_h_
#ifndef BMS_Master_COMMON_INCLUDES_
#define BMS_Master_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rt_nonfinite.h"
#include "math.h"
#endif                                 /* BMS_Master_COMMON_INCLUDES_ */

#include "BMS_Master_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S19>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_c;/* '<S7>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_l;/* '<S9>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_g;/* '<S10>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_e;/* '<S11>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_ck;/* '<S12>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_l1;/* '<S13>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_k;/* '<S14>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_o;/* '<S15>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_e2;/* '<S17>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_p;/* '<S16>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_i;/* '<S18>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_d;/* '<S20>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_m;/* '<S21>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_en;/* '<S22>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTATE_j;/* '<S23>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_da;/* '<S24>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator_DSTAT_g5;/* '<S8>/Discrete-Time Integrator' */
  real_T BleedCellTemp;                /* '<S1>/Chart' */
  real_T sortedVoltVector[18];         /* '<S1>/Chart' */
  uint32_T temporalCounter_i1;      /* '<S3>/Passive Balancing State Machine' */
  uint16_T temporalCounter_i1_m;       /* '<S1>/Chart' */
  uint8_T is_active_c2_BMS_Master;  /* '<S3>/Passive Balancing State Machine' */
  uint8_T is_c2_BMS_Master;         /* '<S3>/Passive Balancing State Machine' */
  uint8_T is_ON;                    /* '<S3>/Passive Balancing State Machine' */
  uint8_T is_active_c1_BMS_Master;     /* '<S1>/Chart' */
  uint8_T is_c1_BMS_Master;            /* '<S1>/Chart' */
  uint8_T is_PassiveCellBalancingOn;   /* '<S1>/Chart' */
  boolean_T flagBalancingDone;      /* '<S3>/Passive Balancing State Machine' */
} DW_BMS_Master_T;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T TmpSignalConversionAtTransp[18];
  const real_T Transpose[18];          /* '<S6>/Transpose' */
  const boolean_T DataTypeConversion;  /* '<S1>/Data Type Conversion' */
} ConstB_BMS_Master_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: single(LUTBattery_Charge);)
   * Referenced by:
   *   '<S7>/n-D Lookup Table'
   *   '<S8>/n-D Lookup Table'
   *   '<S9>/n-D Lookup Table'
   *   '<S10>/n-D Lookup Table'
   *   '<S11>/n-D Lookup Table'
   *   '<S12>/n-D Lookup Table'
   *   '<S13>/n-D Lookup Table'
   *   '<S14>/n-D Lookup Table'
   *   '<S15>/n-D Lookup Table'
   *   '<S16>/n-D Lookup Table'
   *   '<S17>/n-D Lookup Table'
   *   '<S18>/n-D Lookup Table'
   *   '<S19>/n-D Lookup Table'
   *   '<S20>/n-D Lookup Table'
   *   '<S21>/n-D Lookup Table'
   *   '<S22>/n-D Lookup Table'
   *   '<S23>/n-D Lookup Table'
   *   '<S24>/n-D Lookup Table'
   */
  real_T pooled4[3];

  /* Pooled Parameter (Expression: single(LUTBattery_Charge_Temp);)
   * Referenced by:
   *   '<S7>/n-D Lookup Table'
   *   '<S8>/n-D Lookup Table'
   *   '<S9>/n-D Lookup Table'
   *   '<S10>/n-D Lookup Table'
   *   '<S11>/n-D Lookup Table'
   *   '<S12>/n-D Lookup Table'
   *   '<S13>/n-D Lookup Table'
   *   '<S14>/n-D Lookup Table'
   *   '<S15>/n-D Lookup Table'
   *   '<S16>/n-D Lookup Table'
   *   '<S17>/n-D Lookup Table'
   *   '<S18>/n-D Lookup Table'
   *   '<S19>/n-D Lookup Table'
   *   '<S20>/n-D Lookup Table'
   *   '<S21>/n-D Lookup Table'
   *   '<S22>/n-D Lookup Table'
   *   '<S23>/n-D Lookup Table'
   *   '<S24>/n-D Lookup Table'
   */
  real_T pooled5[3];
} ConstP_BMS_Master_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  BusInputBMS FromPlant;               /* '<Root>/FromPlant' */
  BusSimulationInput InputSimulationBus;/* '<Root>/InputSimulationBus' */
  boolean_T ASWEnFlg;                  /* '<Root>/ASWEnFlg' */
} ExtU_BMS_Master_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  BusOutputBMS ToPlant;                /* '<Root>/ToPlant' */
  real_T CBM_MaxCellBalCount;          /* '<Root>/CBM_MaxCellBalCount' */
  boolean_T CBM_CellBalStartCmd;       /* '<Root>/CBM_CellBalStartCmd' */
} ExtY_BMS_Master_T;

/* Real-time Model Data Structure */
struct tag_RTM_BMS_Master_T {
  const char_T * volatile errorStatus;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    struct {
      uint8_T TID[2];
    } TaskCounters;
  } Timing;
};

/* Block states (default storage) */
extern DW_BMS_Master_T BMS_Master_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_BMS_Master_T BMS_Master_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_BMS_Master_T BMS_Master_Y;
extern const ConstB_BMS_Master_T BMS_Master_ConstB;/* constant block i/o */

/* Constant parameters (default storage) */
extern const ConstP_BMS_Master_T BMS_Master_ConstP;

/* Model entry point functions */
extern void BMS_Master_initialize(void);
extern void BMS_Master_step(void);
extern void BMS_Master_terminate(void);

/* Real-time Model object */
extern RT_MODEL_BMS_Master_T *const BMS_Master_M;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S2>/Selector3' : Unused code path elimination
 * Block '<S1>/Selector' : Eliminated due to all input elements selected
 * Block '<S1>/Selector1' : Eliminated due to all input elements selected
 * Block '<S3>/Selector' : Eliminated due to all input elements selected
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'BMS_Master'
 * '<S1>'   : 'BMS_Master/BMS StateMachine'
 * '<S2>'   : 'BMS_Master/Battery SOC Estimation'
 * '<S3>'   : 'BMS_Master/Cell Balancing Module'
 * '<S4>'   : 'BMS_Master/Fault Handling Module'
 * '<S5>'   : 'BMS_Master/BMS StateMachine/Chart'
 * '<S6>'   : 'BMS_Master/Battery SOC Estimation/Subsystem'
 * '<S7>'   : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference1'
 * '<S8>'   : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference10'
 * '<S9>'   : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference2'
 * '<S10>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference24'
 * '<S11>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference25'
 * '<S12>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference26'
 * '<S13>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference27'
 * '<S14>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference28'
 * '<S15>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference29'
 * '<S16>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference3'
 * '<S17>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference30'
 * '<S18>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference4'
 * '<S19>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference43'
 * '<S20>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference5'
 * '<S21>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference6'
 * '<S22>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference7'
 * '<S23>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference8'
 * '<S24>'  : 'BMS_Master/Battery SOC Estimation/Subsystem/Subsystem Reference9'
 * '<S25>'  : 'BMS_Master/Cell Balancing Module/Passive Balancing State Machine'
 * '<S26>'  : 'BMS_Master/Fault Handling Module/Compare To Constant'
 * '<S27>'  : 'BMS_Master/Fault Handling Module/Compare To Constant1'
 * '<S28>'  : 'BMS_Master/Fault Handling Module/Compare To Constant2'
 * '<S29>'  : 'BMS_Master/Fault Handling Module/Compare To Constant3'
 * '<S30>'  : 'BMS_Master/Fault Handling Module/Compare To Constant4'
 * '<S31>'  : 'BMS_Master/Fault Handling Module/Compare To Constant5'
 * '<S32>'  : 'BMS_Master/Fault Handling Module/Compare To Constant6'
 * '<S33>'  : 'BMS_Master/Fault Handling Module/Compare To Constant7'
 */
#endif                                 /* BMS_Master_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
