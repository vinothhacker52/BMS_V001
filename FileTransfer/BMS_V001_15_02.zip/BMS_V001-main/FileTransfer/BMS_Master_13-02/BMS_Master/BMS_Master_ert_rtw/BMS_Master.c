/*
 * File: BMS_Master.c
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BMS_Master.h"
#include "rtwtypes.h"
#include <math.h>
#include <string.h>
#include "BMS_Master_types.h"
#include "SystemState_t.h"
#include "rt_nonfinite.h"
#include "BMS_Master_private.h"

/* Named constants for Chart: '<S1>/Chart' */
#define BMS_M_IN_PassiveCellBalancingOn ((uint8_T)3U)
#define BMS_M_IN_StartBalancingMax1Cell ((uint8_T)2U)
#define BMS_M_IN_StartBalancingMax2Cell ((uint8_T)3U)
#define BMS_Master_CellMaxVThreshold   (0.0)
#define BMS_Master_CellMinVThreshold   (2.8)
#define BMS_Master_IN_ApplicationEntry ((uint8_T)1U)
#define BMS_Master_IN_CooldownPeriod   ((uint8_T)1U)
#define BMS_Master_IN_Idle             ((uint8_T)2U)
#define BMS_Master_IN_NO_ACTIVE_CHILD  ((uint8_T)0U)

/* Named constants for Chart: '<S3>/Passive Balancing State Machine' */
#define BMS_Master_IN_Balancing        ((uint8_T)1U)
#define BMS_Master_IN_BalancingFinished ((uint8_T)2U)
#define BMS_Master_IN_MeasureVoltages  ((uint8_T)3U)
#define BMS_Master_IN_OFF              ((uint8_T)1U)
#define BMS_Master_IN_ON               ((uint8_T)2U)
#define BMS_Master_IN_WaitRelaxation   ((uint8_T)4U)

/* Block states (default storage) */
DW_BMS_Master_T BMS_Master_DW;

/* External inputs (root inport signals with default storage) */
ExtU_BMS_Master_T BMS_Master_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_BMS_Master_T BMS_Master_Y;

/* Real-time model */
static RT_MODEL_BMS_Master_T BMS_Master_M_;
RT_MODEL_BMS_Master_T *const BMS_Master_M = &BMS_Master_M_;

/* Forward declaration for local functions */
static real_T BMS_Master_maximum(const real_T x[18]);
static void rate_scheduler(void);
real_T look1_binlxpw(real_T u0, const real_T bp0[], const real_T table[],
                     uint32_T maxIndex)
{
  real_T frac;
  real_T yL_0d0;
  uint32_T iLeft;

  /* Column-major Lookup 1-D
     Search method: 'binary'
     Use previous index: 'off'
     Interpolation method: 'Linear point-slope'
     Extrapolation method: 'Linear'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  /* Prelookup - Index and Fraction
     Index Search method: 'binary'
     Extrapolation method: 'Linear'
     Use previous index: 'off'
     Use last breakpoint for index at or above upper limit: 'off'
     Remove protection against out-of-range input in generated code: 'off'
   */
  if (u0 <= bp0[0U]) {
    iLeft = 0U;
    frac = (u0 - bp0[0U]) / (bp0[1U] - bp0[0U]);
  } else if (u0 < bp0[maxIndex]) {
    uint32_T bpIdx;
    uint32_T iRght;

    /* Binary Search */
    bpIdx = maxIndex >> 1U;
    iLeft = 0U;
    iRght = maxIndex;
    while (iRght - iLeft > 1U) {
      if (u0 < bp0[bpIdx]) {
        iRght = bpIdx;
      } else {
        iLeft = bpIdx;
      }

      bpIdx = (iRght + iLeft) >> 1U;
    }

    frac = (u0 - bp0[iLeft]) / (bp0[iLeft + 1U] - bp0[iLeft]);
  } else {
    iLeft = maxIndex - 1U;
    frac = (u0 - bp0[maxIndex - 1U]) / (bp0[maxIndex] - bp0[maxIndex - 1U]);
  }

  /* Column-major Interpolation 1-D
     Interpolation method: 'Linear point-slope'
     Use last breakpoint for index at or above upper limit: 'off'
     Overflow mode: 'portable wrapping'
   */
  yL_0d0 = table[iLeft];
  return (table[iLeft + 1U] - yL_0d0) * frac + yL_0d0;
}

/*
 *         This function updates active task flag for each subrate.
 *         The function is called at model base rate, hence the
 *         generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (BMS_Master_M->Timing.TaskCounters.TID[1])++;
  if ((BMS_Master_M->Timing.TaskCounters.TID[1]) > 1) {/* Sample time: [0.01s, 0.0s] */
    BMS_Master_M->Timing.TaskCounters.TID[1] = 0;
  }
}

/* Function for Chart: '<S1>/Chart' */
static real_T BMS_Master_maximum(const real_T x[18])
{
  real_T ex;
  int32_T idx;
  int32_T k;
  if (!rtIsNaN(x[0])) {
    idx = 1;
  } else {
    boolean_T exitg1;
    idx = 0;
    k = 2;
    exitg1 = false;
    while ((!exitg1) && (k < 19)) {
      if (!rtIsNaN(x[k - 1])) {
        idx = k;
        exitg1 = true;
      } else {
        k++;
      }
    }
  }

  if (idx == 0) {
    ex = x[0];
  } else {
    ex = x[idx - 1];
    for (k = idx + 1; k < 19; k++) {
      real_T x_0;
      x_0 = x[k - 1];
      if (ex < x_0) {
        ex = x_0;
      }
    }
  }

  return ex;
}

/* Model step function */
void BMS_Master_step(void)
{
  real_T rtb_Selector1[18];
  real_T maxV;
  real_T maxV_0;
  real_T maxV_1;
  real_T maxV_tmp;
  real_T minV;
  int32_T i;
  int8_T rtb_DataTypeConversion[8];
  boolean_T exitg1;
  boolean_T y;
  DiagSts rtb_VectorConcatenate[8];
  if (BMS_Master_M->Timing.TaskCounters.TID[1] == 0) {
    /* MinMax: '<S3>/Max' incorporates:
     *  Inport: '<Root>/FromPlant'
     */
    maxV = BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[0];

    /* MinMax: '<S3>/Min' incorporates:
     *  Inport: '<Root>/FromPlant'
     */
    minV = BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[0];
    for (i = 0; i < 17; i++) {
      /* MinMax: '<S3>/Max' incorporates:
       *  Inport: '<Root>/FromPlant'
       *  MinMax: '<S3>/Min'
       */
      maxV_tmp =
        BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i + 1];
      maxV = fmax(maxV, maxV_tmp);

      /* MinMax: '<S3>/Min' */
      minV = fmin(minV, maxV_tmp);
    }

    /* Chart: '<S3>/Passive Balancing State Machine' incorporates:
     *  Inport: '<Root>/FromPlant'
     *  Inport: '<Root>/InputSimulationBus'
     *  MinMax: '<S3>/Max'
     *  MinMax: '<S3>/Min'
     */
    if (BMS_Master_DW.temporalCounter_i1 < MAX_uint32_T) {
      BMS_Master_DW.temporalCounter_i1++;
    }

    if (BMS_Master_DW.is_active_c2_BMS_Master == 0) {
      BMS_Master_DW.is_active_c2_BMS_Master = 1U;
      BMS_Master_DW.is_c2_BMS_Master = BMS_Master_IN_OFF;
      for (i = 0; i < 18; i++) {
        BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] = false;
      }

      BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = false;
      BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV - minV;
    } else if (BMS_Master_DW.is_c2_BMS_Master == BMS_Master_IN_OFF) {
      if ((BMS_Master_U.InputSimulationBus.SimulationSystemInput.SystemState ==
           SystemState_t_Balancing) &&
          (BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell > 0.001))
      {
        BMS_Master_DW.is_c2_BMS_Master = BMS_Master_IN_ON;
        BMS_Master_DW.temporalCounter_i1 = 0U;
        BMS_Master_DW.is_ON = BMS_Master_IN_Balancing;
        for (i = 0; i < 18; i++) {
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] =
            (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i] -
             minV > 0.001);
        }

        BMS_Master_DW.flagBalancingDone = true;
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 18)) {
          if (BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i]) {
            BMS_Master_DW.flagBalancingDone = false;
            exitg1 = true;
          } else {
            i++;
          }
        }

        BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = true;
      } else {
        BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV -
          minV;
      }

      /* case IN_ON: */
    } else if (BMS_Master_U.InputSimulationBus.SimulationSystemInput.SystemState
               != SystemState_t_Balancing) {
      BMS_Master_DW.is_ON = BMS_Master_IN_NO_ACTIVE_CHILD;
      BMS_Master_DW.is_c2_BMS_Master = BMS_Master_IN_OFF;
      for (i = 0; i < 18; i++) {
        BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] = false;
      }

      BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = false;
      BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV - minV;
    } else {
      switch (BMS_Master_DW.is_ON) {
       case BMS_Master_IN_Balancing:
        if (BMS_Master_DW.flagBalancingDone) {
          BMS_Master_DW.is_ON = BMS_Master_IN_BalancingFinished;
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV -
            minV;
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = false;
        } else if ((uint32_T)((int32_T)BMS_Master_DW.temporalCounter_i1 * 10) >=
                   2000U) {
          BMS_Master_DW.temporalCounter_i1 = 0U;
          BMS_Master_DW.is_ON = BMS_Master_IN_WaitRelaxation;
          for (i = 0; i < 18; i++) {
            BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] = false;
          }
        }
        break;

       case BMS_Master_IN_BalancingFinished:
        if (BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell > 0.001)
        {
          BMS_Master_DW.temporalCounter_i1 = 0U;
          BMS_Master_DW.is_ON = BMS_Master_IN_Balancing;
          for (i = 0; i < 18; i++) {
            BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] =
              (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i]
               - minV > 0.001);
          }

          BMS_Master_DW.flagBalancingDone = true;
          i = 0;
          exitg1 = false;
          while ((!exitg1) && (i < 18)) {
            if (BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i]) {
              BMS_Master_DW.flagBalancingDone = false;
              exitg1 = true;
            } else {
              i++;
            }
          }

          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = true;
        } else {
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV -
            minV;
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = false;
        }
        break;

       case BMS_Master_IN_MeasureVoltages:
        BMS_Master_DW.temporalCounter_i1 = 0U;
        BMS_Master_DW.is_ON = BMS_Master_IN_Balancing;
        for (i = 0; i < 18; i++) {
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i] =
            (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i] -
             minV > 0.001);
        }

        BMS_Master_DW.flagBalancingDone = true;
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 18)) {
          if (BMS_Master_Y.ToPlant.BMSBatteryPackInput.BalCmdVector[i]) {
            BMS_Master_DW.flagBalancingDone = false;
            exitg1 = true;
          } else {
            i++;
          }
        }

        BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingFlags = true;
        break;

       default:
        /* case IN_WaitRelaxation: */
        if ((uint32_T)((int32_T)BMS_Master_DW.temporalCounter_i1 * 10) >= 1000U)
        {
          BMS_Master_DW.is_ON = BMS_Master_IN_MeasureVoltages;
          BMS_Master_Y.ToPlant.BMSBatteryPackInput.balancingDeltaVCell = maxV -
            minV;
        }
        break;
      }
    }

    /* End of Chart: '<S3>/Passive Balancing State Machine' */

    /* BusCreator generated from: '<Root>/ToPlant' incorporates:
     *  DiscreteIntegrator: '<S10>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S11>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S12>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S13>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S14>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S15>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S16>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S17>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S18>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S19>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S20>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S21>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S22>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S23>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S24>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S7>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S8>/Discrete-Time Integrator'
     *  DiscreteIntegrator: '<S9>/Discrete-Time Integrator'
     *  Math: '<S6>/Transpose'
     */
    memcpy(&BMS_Master_Y.ToPlant.BusSOCEstimation.EKFEstimation[0],
           &BMS_Master_ConstB.Transpose[0], 18U * sizeof(real_T));
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[0] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[1] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[2] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[3] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[4] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[5] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[6] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[7] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[8] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[9] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[10] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[11] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[12] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[13] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[14] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[15] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[16] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da;
    BMS_Master_Y.ToPlant.BusSOCEstimation.CDCEstimation[17] =
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5;

    /* BusCreator generated from: '<Root>/ToPlant' incorporates:
     *  Outport: '<Root>/ToPlant'
     */
    BMS_Master_Y.ToPlant.ContactorOperationCmd =
      BMS_Master_ConstB.DataTypeConversion;

    /* Selector: '<S4>/Selector1' incorporates:
     *  Inport: '<Root>/FromPlant'
     */
    memcpy(&rtb_Selector1[0],
           &BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[0],
           10U * sizeof(real_T));

    /* MinMax: '<S4>/Max4' */
    maxV = rtb_Selector1[0];

    /* MinMax: '<S4>/Max7' incorporates:
     *  Inport: '<Root>/FromPlant'
     *  Selector: '<S4>/Selector4'
     */
    maxV_0 = BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector[0];

    /* MinMax: '<S4>/Max10' incorporates:
     *  Inport: '<Root>/FromPlant'
     *  Selector: '<S4>/Selector7'
     */
    maxV_1 = BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[0];

    /* MinMax: '<S4>/Max13' incorporates:
     *  Inport: '<Root>/FromPlant'
     *  Selector: '<S4>/Selector10'
     */
    minV = BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[0];
    for (i = 0; i < 9; i++) {
      /* MinMax: '<S4>/Max4' */
      maxV = fmax(maxV, rtb_Selector1[i + 1]);

      /* MinMax: '<S4>/Max7' incorporates:
       *  Inport: '<Root>/FromPlant'
       *  Selector: '<S4>/Selector4'
       */
      maxV_0 = fmax(maxV_0,
                    BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector[i
                    + 1]);

      /* Selector: '<S4>/Selector7' incorporates:
       *  Inport: '<Root>/FromPlant'
       *  MinMax: '<S4>/Max10'
       *  MinMax: '<S4>/Max13'
       *  Selector: '<S4>/Selector10'
       */
      maxV_tmp =
        BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i + 1];

      /* MinMax: '<S4>/Max10' incorporates:
       *  Selector: '<S4>/Selector7'
       */
      maxV_1 = fmax(maxV_1, maxV_tmp);

      /* MinMax: '<S4>/Max13' */
      minV = fmin(minV, maxV_tmp);
    }

    /* Switch: '<S4>/Switch1' incorporates:
     *  Constant: '<S26>/Constant'
     *  Constant: '<S4>/Constant2'
     *  Constant: '<S4>/Constant3'
     *  MinMax: '<S4>/Max4'
     *  RelationalOperator: '<S26>/Compare'
     */
    if (maxV >= 20.0) {
      rtb_VectorConcatenate[0] = NoFault;
    } else {
      rtb_VectorConcatenate[0] = OverCurrentWarning;
    }

    /* End of Switch: '<S4>/Switch1' */

    /* Switch: '<S4>/Switch2' incorporates:
     *  Constant: '<S27>/Constant'
     *  Constant: '<S4>/Constant1'
     *  Constant: '<S4>/Constant4'
     *  MinMax: '<S4>/Max4'
     *  RelationalOperator: '<S27>/Compare'
     */
    if (maxV >= 50.0) {
      rtb_VectorConcatenate[1] = NoFault;
    } else {
      rtb_VectorConcatenate[1] = OverCurrentFault;
    }

    /* End of Switch: '<S4>/Switch2' */

    /* Switch: '<S4>/Switch3' incorporates:
     *  Constant: '<S28>/Constant'
     *  Constant: '<S4>/Constant5'
     *  Constant: '<S4>/Constant6'
     *  MinMax: '<S4>/Max7'
     *  RelationalOperator: '<S28>/Compare'
     */
    if (maxV_0 >= 323.15) {
      rtb_VectorConcatenate[2] = NoFault;
    } else {
      rtb_VectorConcatenate[2] = OverTemperatureWarning;
    }

    /* End of Switch: '<S4>/Switch3' */

    /* Switch: '<S4>/Switch4' incorporates:
     *  Constant: '<S29>/Constant'
     *  Constant: '<S4>/Constant7'
     *  Constant: '<S4>/Constant8'
     *  MinMax: '<S4>/Max7'
     *  RelationalOperator: '<S29>/Compare'
     */
    if (maxV_0 >= 338.15) {
      rtb_VectorConcatenate[3] = NoFault;
    } else {
      rtb_VectorConcatenate[3] = OverTemperatureFault;
    }

    /* End of Switch: '<S4>/Switch4' */

    /* Switch: '<S4>/Switch5' incorporates:
     *  Constant: '<S30>/Constant'
     *  Constant: '<S4>/Constant10'
     *  Constant: '<S4>/Constant9'
     *  MinMax: '<S4>/Max10'
     *  RelationalOperator: '<S30>/Compare'
     */
    if (maxV_1 >= 4.21) {
      rtb_VectorConcatenate[4] = NoFault;
    } else {
      rtb_VectorConcatenate[4] = OverVoltageWarning;
    }

    /* End of Switch: '<S4>/Switch5' */

    /* Switch: '<S4>/Switch6' incorporates:
     *  Constant: '<S31>/Constant'
     *  Constant: '<S4>/Constant11'
     *  Constant: '<S4>/Constant12'
     *  MinMax: '<S4>/Max10'
     *  RelationalOperator: '<S31>/Compare'
     */
    if (maxV_1 >= 4.25) {
      rtb_VectorConcatenate[5] = NoFault;
    } else {
      rtb_VectorConcatenate[5] = OverVoltageFault;
    }

    /* End of Switch: '<S4>/Switch6' */

    /* Switch: '<S4>/Switch7' incorporates:
     *  Constant: '<S32>/Constant'
     *  Constant: '<S4>/Constant13'
     *  Constant: '<S4>/Constant16'
     *  MinMax: '<S4>/Max13'
     *  RelationalOperator: '<S32>/Compare'
     */
    if (minV <= 2.7) {
      rtb_VectorConcatenate[6] = NoFault;
    } else {
      rtb_VectorConcatenate[6] = UnderVoltageWarning;
    }

    /* End of Switch: '<S4>/Switch7' */

    /* Switch: '<S4>/Switch8' incorporates:
     *  Constant: '<S33>/Constant'
     *  Constant: '<S4>/Constant14'
     *  Constant: '<S4>/Constant15'
     *  MinMax: '<S4>/Max13'
     *  RelationalOperator: '<S33>/Compare'
     */
    if (minV <= 2.65) {
      rtb_VectorConcatenate[7] = NoFault;
    } else {
      rtb_VectorConcatenate[7] = UnderVoltageFault;
    }

    /* End of Switch: '<S4>/Switch8' */

    /* DataTypeConversion: '<S4>/Data Type  Conversion' */
    for (i = 0; i < 8; i++) {
      rtb_DataTypeConversion[i] = (int8_T)rtb_VectorConcatenate[i];
    }

    /* End of DataTypeConversion: '<S4>/Data Type  Conversion' */

    /* Chart: '<S1>/Chart' incorporates:
     *  Inport: '<Root>/ASWEnFlg'
     *  Inport: '<Root>/FromPlant'
     *  Outport: '<Root>/CBM_MaxCellBalCount'
     */
    if (BMS_Master_DW.temporalCounter_i1_m < 2047) {
      BMS_Master_DW.temporalCounter_i1_m++;
    }

    if (BMS_Master_DW.is_active_c1_BMS_Master == 0) {
      BMS_Master_DW.is_active_c1_BMS_Master = 1U;
      BMS_Master_DW.is_c1_BMS_Master = BMS_Master_IN_Idle;
    } else {
      switch (BMS_Master_DW.is_c1_BMS_Master) {
       case BMS_Master_IN_ApplicationEntry:
        if (!BMS_Master_U.ASWEnFlg) {
          BMS_Master_DW.is_c1_BMS_Master = BMS_Master_IN_Idle;
        } else {
          y = false;
          i = 0;
          exitg1 = false;
          while ((!exitg1) && (i < 18)) {
            if (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[i]
                < BMS_Master_CellMinVThreshold) {
              y = true;
              exitg1 = true;
            } else {
              i++;
            }
          }

          if (y) {
            y = false;
            i = 0;
            exitg1 = false;
            while ((!exitg1) && (i < 18)) {
              if (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentVoltageVector[
                  i] <= BMS_Master_CellMaxVThreshold) {
                y = true;
                exitg1 = true;
              } else {
                i++;
              }
            }

            if (y) {
              y = true;
              i = 0;
              exitg1 = false;
              while ((!exitg1) && (i < 8)) {
                if (rtb_DataTypeConversion[i] == 0) {
                  y = false;
                  exitg1 = true;
                } else {
                  i++;
                }
              }

              y = !y;
            } else {
              y = false;
            }
          } else {
            y = false;
          }

          if (y) {
            BMS_Master_DW.is_c1_BMS_Master = BMS_M_IN_PassiveCellBalancingOn;

            /* Outport: '<Root>/CBM_CellBalStartCmd' */
            BMS_Master_Y.CBM_CellBalStartCmd = true;
            BMS_Master_DW.BleedCellTemp = BMS_Master_maximum
              (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector);
            BMS_Master_DW.temporalCounter_i1_m = 0U;
            BMS_Master_DW.is_PassiveCellBalancingOn =
              BMS_M_IN_StartBalancingMax1Cell;

            /* Outport: '<Root>/CBM_MaxCellBalCount' incorporates:
             *  Inport: '<Root>/FromPlant'
             */
            BMS_Master_Y.CBM_MaxCellBalCount = 1.0;
          }
        }
        break;

       case BMS_Master_IN_Idle:
        if (BMS_Master_U.ASWEnFlg) {
          BMS_Master_DW.is_c1_BMS_Master = BMS_Master_IN_ApplicationEntry;
        }
        break;

       default:
        /* case IN_PassiveCellBalancingOn: */
        if (BMS_Master_Y.CBM_MaxCellBalCount == 0.0) {
          switch (BMS_Master_DW.is_PassiveCellBalancingOn) {
           case BMS_Master_IN_CooldownPeriod:
            BMS_Master_DW.is_PassiveCellBalancingOn =
              BMS_Master_IN_NO_ACTIVE_CHILD;
            break;

           case BMS_M_IN_StartBalancingMax1Cell:
            BMS_Master_Y.CBM_MaxCellBalCount = 0.0;
            BMS_Master_DW.is_PassiveCellBalancingOn =
              BMS_Master_IN_NO_ACTIVE_CHILD;
            break;

           case BMS_M_IN_StartBalancingMax2Cell:
            BMS_Master_Y.CBM_MaxCellBalCount = 1.0;
            BMS_Master_DW.is_PassiveCellBalancingOn =
              BMS_Master_IN_NO_ACTIVE_CHILD;
            break;
          }

          /* Outport: '<Root>/CBM_CellBalStartCmd' */
          BMS_Master_Y.CBM_CellBalStartCmd = false;
          BMS_Master_DW.is_c1_BMS_Master = BMS_Master_IN_ApplicationEntry;
        } else {
          switch (BMS_Master_DW.is_PassiveCellBalancingOn) {
           case BMS_Master_IN_CooldownPeriod:
            if ((BMS_Master_DW.BleedCellTemp < 35.0) &&
                (BMS_Master_DW.temporalCounter_i1_m >= 500)) {
              /* Outport: '<Root>/CBM_CellBalStartCmd' */
              BMS_Master_Y.CBM_CellBalStartCmd = true;
              BMS_Master_DW.temporalCounter_i1_m = 0U;
              BMS_Master_DW.is_PassiveCellBalancingOn =
                BMS_M_IN_StartBalancingMax1Cell;
              BMS_Master_Y.CBM_MaxCellBalCount = 1.0;
            }
            break;

           case BMS_M_IN_StartBalancingMax1Cell:
            if ((BMS_Master_DW.temporalCounter_i1_m >= 2000) ||
                (BMS_Master_DW.BleedCellTemp > 40.0)) {
              BMS_Master_Y.CBM_MaxCellBalCount = 0.0;
              BMS_Master_DW.temporalCounter_i1_m = 0U;
              BMS_Master_DW.is_PassiveCellBalancingOn =
                BMS_Master_IN_CooldownPeriod;

              /* Outport: '<Root>/CBM_CellBalStartCmd' */
              BMS_Master_Y.CBM_CellBalStartCmd = false;
            } else if (BMS_Master_DW.sortedVoltVector[1] <
                       BMS_Master_CellMinVThreshold) {
              BMS_Master_DW.is_PassiveCellBalancingOn =
                BMS_M_IN_StartBalancingMax2Cell;
              BMS_Master_Y.CBM_MaxCellBalCount = 2.0;
            } else {
              BMS_Master_DW.temporalCounter_i1_m = 0U;
              BMS_Master_DW.is_PassiveCellBalancingOn =
                BMS_M_IN_StartBalancingMax1Cell;
              BMS_Master_Y.CBM_MaxCellBalCount = 1.0;
            }
            break;

           default:
            /* case IN_StartBalancingMax2Cell: */
            break;
          }
        }
        break;
      }
    }

    /* End of Chart: '<S1>/Chart' */

    /* Update for DiscreteIntegrator: '<S19>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S19>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S19>/n-D Lookup Table'
     *  Product: '<S19>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[0] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [0], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S19>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S7>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S7>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S7>/n-D Lookup Table'
     *  Product: '<S7>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[1] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [1], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S7>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S9>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S9>/n-D Lookup Table'
     *  Product: '<S9>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[2] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [2], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S10>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S10>/n-D Lookup Table'
     *  Product: '<S10>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[3] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [3], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S11>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S11>/n-D Lookup Table'
     *  Product: '<S11>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[4] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [4], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S12>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S12>/n-D Lookup Table'
     *  Product: '<S12>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[5] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [5], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S13>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S13>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S13>/n-D Lookup Table'
     *  Product: '<S13>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[6] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [6], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S13>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S14>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S14>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S14>/n-D Lookup Table'
     *  Product: '<S14>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[7] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [7], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S14>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S15>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S15>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S15>/n-D Lookup Table'
     *  Product: '<S15>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[8] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [8], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S15>/Discrete-Time Integrator' */

    /* Lookup_n-D: '<S17>/n-D Lookup Table' incorporates:
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S8>/n-D Lookup Table'
     *  Selector: '<S2>/Selector2'
     */
    maxV = look1_binlxpw
      (BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector[9],
       BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4, 2U);

    /* Update for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S17>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S17>/n-D Lookup Table'
     *  Product: '<S17>/Divide'
     *  Selector: '<S2>/Selector1'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[9] / maxV *
      0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S16>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S16>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S16>/n-D Lookup Table'
     *  Product: '<S16>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[10] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [10], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S16>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S18>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S18>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S18>/n-D Lookup Table'
     *  Product: '<S18>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[11] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [11], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S18>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S20>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S20>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S20>/n-D Lookup Table'
     *  Product: '<S20>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[12] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [12], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S20>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S21>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S21>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S21>/n-D Lookup Table'
     *  Product: '<S21>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[13] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [13], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S21>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S22>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S22>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S22>/n-D Lookup Table'
     *  Product: '<S22>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[14] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [14], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S22>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S23>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S23>/n-D Lookup Table'
     *  Product: '<S23>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[15] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [15], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S24>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Lookup_n-D: '<S24>/n-D Lookup Table'
     *  Product: '<S24>/Divide'
     *  Selector: '<S2>/Selector1'
     *  Selector: '<S2>/Selector2'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[16] /
      look1_binlxpw(BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentTempVector
                    [16], BMS_Master_ConstP.pooled5, BMS_Master_ConstP.pooled4,
                    2U) * 0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */

    /* Update for DiscreteIntegrator: '<S8>/Discrete-Time Integrator' incorporates:
     *  Gain: '<S8>/Gain'
     *  Inport: '<Root>/FromPlant'
     *  Product: '<S8>/Divide'
     *  Selector: '<S2>/Selector1'
     */
    BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 += -0.00027777778450399637 *
      BMS_Master_U.FromPlant.BMSBatteryPackData.SegmentCurrentVector[17] / maxV *
      0.01;
    if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 > 1.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 = 1.0;
    } else if (BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 < 0.0) {
      BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 = 0.0;
    }

    /* End of Update for DiscreteIntegrator: '<S8>/Discrete-Time Integrator' */
  }

  rate_scheduler();
}

/* Model initialize function */
void BMS_Master_initialize(void)
{
  /* InitializeConditions for DiscreteIntegrator: '<S19>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S7>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_c = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_l = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_g = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_e = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_ck = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S13>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_l1 = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S14>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_k = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S15>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_o = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S17>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_e2 = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S16>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_p = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S18>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_i = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S20>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_d = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S21>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_m = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S22>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_en = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S23>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTATE_j = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S24>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_da = 1.0;

  /* InitializeConditions for DiscreteIntegrator: '<S8>/Discrete-Time Integrator' */
  BMS_Master_DW.DiscreteTimeIntegrator_DSTAT_g5 = 1.0;
}

/* Model terminate function */
void BMS_Master_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
