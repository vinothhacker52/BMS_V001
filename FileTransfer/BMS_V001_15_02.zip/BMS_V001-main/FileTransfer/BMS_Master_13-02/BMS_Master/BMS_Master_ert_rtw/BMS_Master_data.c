/*
 * File: BMS_Master_data.c
 *
 * Code generated for Simulink model 'BMS_Master'.
 *
 * Model version                  : 9.40
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Sun Feb 15 17:23:35 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BMS_Master.h"

/* Invariant block signals (default storage) */
const ConstB_BMS_Master_T BMS_Master_ConstB = {
  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0 },

  { 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0,
    0.0, 0.0, 0.0 },                   /* '<S6>/Transpose' */
  true                                 /* '<S1>/Data Type Conversion' */
};

/* Constant parameters (default storage) */
const ConstP_BMS_Master_T BMS_Master_ConstP = {
  /* Pooled Parameter (Expression: single(LUTBattery_Charge);)
   * Referenced by:
   *   '<S7>/n-D Lookup Table'
   *   '<S8>/n-D Lookup Table'
   *   '<S9>/n-D Lookup Table'
   *   '<S10>/n-D Lookup Table'
   *   '<S11>/n-D Lookup Table'
   *   '<S12>/n-D Lookup Table'
   *   '<S13>/n-D Lookup Table'
   *   '<S14>/n-D Lookup Table'
   *   '<S15>/n-D Lookup Table'
   *   '<S16>/n-D Lookup Table'
   *   '<S17>/n-D Lookup Table'
   *   '<S18>/n-D Lookup Table'
   *   '<S19>/n-D Lookup Table'
   *   '<S20>/n-D Lookup Table'
   *   '<S21>/n-D Lookup Table'
   *   '<S22>/n-D Lookup Table'
   *   '<S23>/n-D Lookup Table'
   *   '<S24>/n-D Lookup Table'
   */
  { 3.0299999713897705, 3.0, 2.9200000762939453 },

  /* Pooled Parameter (Expression: single(LUTBattery_Charge_Temp);)
   * Referenced by:
   *   '<S7>/n-D Lookup Table'
   *   '<S8>/n-D Lookup Table'
   *   '<S9>/n-D Lookup Table'
   *   '<S10>/n-D Lookup Table'
   *   '<S11>/n-D Lookup Table'
   *   '<S12>/n-D Lookup Table'
   *   '<S13>/n-D Lookup Table'
   *   '<S14>/n-D Lookup Table'
   *   '<S15>/n-D Lookup Table'
   *   '<S16>/n-D Lookup Table'
   *   '<S17>/n-D Lookup Table'
   *   '<S18>/n-D Lookup Table'
   *   '<S19>/n-D Lookup Table'
   *   '<S20>/n-D Lookup Table'
   *   '<S21>/n-D Lookup Table'
   *   '<S22>/n-D Lookup Table'
   *   '<S23>/n-D Lookup Table'
   *   '<S24>/n-D Lookup Table'
   */
  { 278.14999389648438, 293.14999389648438, 323.14999389648438 }
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
