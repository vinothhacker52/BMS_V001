
InverterRes = 0;
InverterParRes = 10000;
InverterCap = 2.5e-3;