/*
 * File: BMSV001_data.c
 *
 * Code generated for Simulink model 'BMSV001'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Wed Feb 11 11:02:14 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "BMSV001.h"

/* Invariant block signals (default storage) */
const ConstB_BMSV001_T BMSV001_ConstB = {
  { 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F,
    3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.5225F, 3.95F, 3.95F,
    3.95F }                            /* '<S4>/Data Type Conversion' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
