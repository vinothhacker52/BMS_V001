/*
 * File: BMSV001_capi.h
 *
 * Code generated for Simulink model 'BMSV001'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Wed Feb 11 11:02:14 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef BMSV001_capi_h_
#define BMSV001_capi_h_

extern void BMSV001_InitializeDataMapInfo(void);

#endif                                 /* BMSV001_capi_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
