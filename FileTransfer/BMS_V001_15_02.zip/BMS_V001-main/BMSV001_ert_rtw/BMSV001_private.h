/*
 * File: BMSV001_private.h
 *
 * Code generated for Simulink model 'BMSV001'.
 *
 * Model version                  : 1.30
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Wed Feb 11 11:02:14 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Renesas->RH850
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef BMSV001_private_h_
#define BMSV001_private_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "BMSV001_types.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* BMSV001_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
