/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018, 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : Config_RIIC0.c
* Component Version: 1.6.1
* Device(s)        : R7F701690
* Description      : This file implements device driver for Config_RIIC0.
***********************************************************************************************************************/
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "McuMacrodriver.h"
#include "McuI2c.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile uint8_t          g_riic0_mode_flag;               /* RIIC0 master transmit receive flag */
volatile uint8_t          g_riic0_state;                   /* RIIC0 state */
volatile uint16_t         g_riic0_slave_address;           /* RIIC0 slave address */
volatile uint8_t *        gp_riic0_tx_address;             /* RIIC0 transmit buffer address */
volatile uint16_t         g_riic0_tx_count;                /* RIIC0 transmit data number */
volatile uint8_t *        gp_riic0_rx_address;             /* RIIC0 receive buffer address */
volatile uint16_t         g_riic0_rx_count;                /* RIIC0 receive data number */
volatile uint16_t         g_riic0_rx_length;               /* RIIC0 receive data length */
volatile uint8_t          g_riic0_dummy_read_count;        /* RIIC0 count for dummy read */
volatile uint8_t          g_riic0_stop_generation;         /* RIIC0 stop condition generation flag */
extern volatile uint32_t  g_cg_sync_read;
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: McuI2CInit
* Description  : This function initializes the IIC Bus Interface.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuI2CInit(void)
{
    uint32_t tmp_port;

    /* Disable RIIC0 interrupt (INTRIIC0TI) operation and clear request */
    INTC2.ICRIIC0TI.BIT.MKRIIC0TI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0TI.BIT.RFRIIC0TI = INT_REQUEST_NOT_OCCUR;
    /* Disable RIIC0 interrupt (INTRIIC0TEI) operation and clear request */
    INTC2.ICRIIC0TEI.BIT.MKRIIC0TEI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0TEI.BIT.RFRIIC0TEI = INT_REQUEST_NOT_OCCUR;
    /* Disable RIIC0 interrupt (INTRIIC0RI) operation and clear request */
    INTC2.ICRIIC0RI.BIT.MKRIIC0RI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0RI.BIT.RFRIIC0RI = INT_REQUEST_NOT_OCCUR;
    /* Disable RIIC0 interrupt (INTRIIC0EE) operation and clear request */
    INTC2.ICRIIC0EE.BIT.MKRIIC0EE = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0EE.BIT.RFRIIC0EE = INT_REQUEST_NOT_OCCUR;
    /* Set RIIC0 interrupt (INTRIIC0TI) setting */
    INTC2.ICRIIC0TI.BIT.TBRIIC0TI = INT_TABLE_VECTOR;
    INTC2.ICRIIC0TI.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set RIIC0 interrupt (INTRIIC0TEI) setting */
    INTC2.ICRIIC0TEI.BIT.TBRIIC0TEI = INT_TABLE_VECTOR;
    INTC2.ICRIIC0TEI.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set RIIC0 interrupt (INTRIIC0RI) setting */
    INTC2.ICRIIC0RI.BIT.TBRIIC0RI = INT_TABLE_VECTOR;
    INTC2.ICRIIC0RI.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set RIIC0 interrupt (INTRIIC0EE) setting */
    INTC2.ICRIIC0EE.BIT.TBRIIC0EE = INT_TABLE_VECTOR;
    INTC2.ICRIIC0EE.UINT16 &= INT_PRIORITY_LOWEST;
    /* Reset RIIC0 */
    RIIC0.CR1.UINT32 &= RIIC_DISABLE;
    RIIC0.CR1.UINT32 |= RIIC_RESET;
    RIIC0.CR1.UINT32 |= RIIC_INTERNAL_RESET;
    /* Set RIIC0 setting */
    RIIC0.MR1.UINT32 = RIIC_CLOCK_SELECTION_8;
    RIIC0.BRL.UINT32 = RIIC_RIICBRL_DEFAULT_VALUE | _RIIC0_BITRATE_LOW_LEVEL_PERIOD;
    RIIC0.BRH.UINT32 = RIIC_RIICBRH_DEFAULT_VALUE | _RIIC0_BITRATE_HIGH_LEVEL_PERIOD;
    RIIC0.MR3.UINT32 = RIIC_DIGITAL_NF_STAGE_SINGLE;
    RIIC0.FER.UINT32 = RIIC_SCL_SYNC_CIRCUIT_USED | RIIC_NOISE_FILTER_USED | RIIC_TRANSFER_SUSPENSION_DISABLED | 
                       RIIC_NACK_ARBITRATION_DISABLE | RIIC_MASTER_ARBITRATION_DISABLE | 
                       RIIC_TIMEOUT_FUNCTION_DISABLED;
    RIIC0.IER.UINT32 = RIIC_TRANSMIT_DATA_EMPTY_INT_DISABLE | RIIC_TRANSMIT_END_INT_DISABLE | 
                       RIIC_RECEIVE_COMPLETE_INT_ENABLE | RIIC_START_CONDITION_INT_DISABLE | 
                       RIIC_STOP_CONDITION_INT_DISABLE | RIIC_TIMEOUT_INT_DISABLE | 
                       RIIC_ARBITRATION_LOST_INT_DISABLE | RIIC_NACK_RECEPTION_INT_DISABLE;
    /* Cancel internal reset */
    RIIC0.CR1.UINT32 &= RIIC_CLEAR_INTERNAL_RESET;
    /* Synchronization processing */
    g_cg_sync_read = RIIC0.MR1.UINT32;
    __syncp();

    /* Set RIIC0SCL pin */
    PORT.PIBC10 &= PORT_CLEAR_BIT3;
    PORT.PBDC10 &= PORT_CLEAR_BIT3;
    PORT.PM10 |= PORT_SET_BIT3;
    PORT.PMC10 &= PORT_CLEAR_BIT3;
    PORT.PIPC10 &= PORT_CLEAR_BIT3;
    tmp_port = PORT.PDSC10;
    PORT.PPCMD10 = WRITE_PROTECT_COMMAND;
    PORT.PDSC10 = (tmp_port & PORT_CLEAR_BIT3);
    PORT.PDSC10 = (uint32_t) ~(tmp_port & PORT_CLEAR_BIT3);
    PORT.PDSC10 = (tmp_port & PORT_CLEAR_BIT3);
    tmp_port = PORT.PODC10;
    PORT.PPCMD10 = WRITE_PROTECT_COMMAND;
    PORT.PODC10 = (tmp_port | PORT_SET_BIT3);
    PORT.PODC10 = (uint32_t) ~(tmp_port | PORT_SET_BIT3);
    PORT.PODC10 = (tmp_port | PORT_SET_BIT3);
    PORT.PBDC10 |= PORT_SET_BIT3;
    PORT.PFC10 |= PORT_SET_BIT3;
    PORT.PFCE10 &= PORT_CLEAR_BIT3;
    PORT.PMC10 |= PORT_SET_BIT3;
    PORT.PM10 &= PORT_CLEAR_BIT3;

    /* Set RIIC0SDA pin */
    PORT.PIBC10 &= PORT_CLEAR_BIT2;
    PORT.PBDC10 &= PORT_CLEAR_BIT2;
    PORT.PM10 |= PORT_SET_BIT2;
    PORT.PMC10 &= PORT_CLEAR_BIT2;
    PORT.PIPC10 &= PORT_CLEAR_BIT2;
    tmp_port = PORT.PDSC10;
    PORT.PPCMD10 = WRITE_PROTECT_COMMAND;
    PORT.PDSC10 = (tmp_port & PORT_CLEAR_BIT2);
    PORT.PDSC10 = (uint32_t) ~(tmp_port & PORT_CLEAR_BIT2);
    PORT.PDSC10 = (tmp_port & PORT_CLEAR_BIT2);
    tmp_port = PORT.PODC10;
    PORT.PPCMD10 = WRITE_PROTECT_COMMAND;
    PORT.PODC10 = (tmp_port | PORT_SET_BIT2);
    PORT.PODC10 = (uint32_t) ~(tmp_port | PORT_SET_BIT2);
    PORT.PODC10 = (tmp_port | PORT_SET_BIT2);
    PORT.PBDC10 |= PORT_SET_BIT2;
    PORT.PFC10 |= PORT_SET_BIT2;
    PORT.PFCE10 &= PORT_CLEAR_BIT2;
    PORT.PMC10 |= PORT_SET_BIT2;
    PORT.PM10 &= PORT_CLEAR_BIT2;

}

/***********************************************************************************************************************
* Function Name: McuI2CStart
* Description  : This function starts the IIC Bus Interface.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuI2CStart(void)
{
    /* Clear RIIC0 interrupt request and enable operation */
    INTC2.ICRIIC0TI.BIT.RFRIIC0TI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0TEI.BIT.RFRIIC0TEI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0RI.BIT.RFRIIC0RI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0EE.BIT.RFRIIC0EE = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0TI.BIT.MKRIIC0TI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0TEI.BIT.MKRIIC0TEI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0RI.BIT.MKRIIC0RI = INT_PROCESSING_ENABLED;
    INTC2.ICRIIC0EE.BIT.MKRIIC0EE = INT_PROCESSING_DISABLED;
}

/***********************************************************************************************************************
* Function Name: McuI2CStop
* Description  : This function stops the IIC Bus Interface.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuI2CStop(void)
{
    /* Disable RIIC0 interrupt operation and clear request */
    INTC2.ICRIIC0TI.BIT.MKRIIC0TI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0TEI.BIT.MKRIIC0TEI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0RI.BIT.MKRIIC0RI = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0EE.BIT.MKRIIC0EE = INT_PROCESSING_DISABLED;
    INTC2.ICRIIC0TI.BIT.RFRIIC0TI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0TEI.BIT.RFRIIC0TEI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0RI.BIT.RFRIIC0RI = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRIIC0EE.BIT.RFRIIC0EE = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = INTC2.ICRIIC0RI.UINT16;
    __syncp();
}

/***********************************************************************************************************************
* Function Name: McuI2cTrasmit
* Description  : This function writes data to a slave device.
* Arguments    : adr -
*                    address of slave device
*                tx_buf -
*                    transfer buffer pointer
*                tx_num -
*                    transmit data length
* Return Value : status -
*                    MD_OK, MD_ERROR1 or MD_ERROR2
***********************************************************************************************************************/
#if 0
MD_STATUS McuI2c0Transmit(uint16_t adr, uint8_t * const txBuf, uint16_t txNum)
{
    if((RIIC0.CR2.UINT32 & RIIC_BUS_BUSY) == RIIC_BUS_BUSY) /* Checking bus state */
    {
	return MD_ERROR1;
    }
    /* Set parameter */
    i2c0TxCount = txNum;
    i2c0TxAddress = txBuf;
    i2c0SlaveAddress = adr;
    i2c0ModeFlag = RIIC_MASTER_TRANSMIT;

    if (adr <= RIIC_ADDRESS_7BIT)
    {
	i2c0State = RIIC_MASTER_SENDS_ADR_7_W;
    }
    else
    {
	i2c0State = RIIC_MASTER_SENDS_ADR_10A_W;
    }

    McuI2c0StartCondition();  /* Issue a start condition */
    while (i2c0TxCount > 0U)
    {
	if((RIIC0.SR2.UINT32 & RIIC_NACK_DETECTED) != RIIC_NACK_DETECTED)
	{
	    if((RIIC0.SR2.UINT32 & RIIC_TRANSMIT_DATA_EMPTY) == RIIC_TRANSMIT_DATA_EMPTY)
	    {
		if((RIIC_MASTER_SENDS_ADR_7_W == i2c0State) && (adr == 0))
		{
		    i2c0State = RIIC_MASTER_SENDS_DATA;
		}
		else if (RIIC_MASTER_SENDS_ADR_7_W == i2c0State)
		{
		    RIIC0.DRT.UINT32 = (uint8_t)(i2c0SlaveAddress << RIIC_ADDRESS_7BIT_SHIFT);		
		    i2c0State = RIIC_MASTER_SENDS_DATA;
		}
		else if(i2c0State == RIIC_MASTER_SENDS_DATA)
		{
		    RIIC0.DRT.UINT32 = *i2c0TxAddress;
		    //while((RIIC0.SR2.UINT32 & RIIC_TRANSMIT_END) != RIIC_TRANSMIT_END );
		    i2c0TxAddress++;
		    i2c0TxCount--;
		}
		else
		{
		    /* Error conidtion to be defined */
		}
		if(i2c0TxCount == 0)
		{
		    McuI2c0TransmitStopCondition();
		}

	    }
	}
	else
	{
	    McuI2c0TransmitStopCondition();
	    break;
	}
    }
}
#endif
/***********************************************************************************************************************
* Function Name: McuI2CRecieve
* Description  : This function reads data from a slave device.
* Arguments    : adr -
*                    address of slave device
*                rx_buf -
*                    receive buffer pointer
*                rx_num -
*                    number of bytes to be received
* Return Value : status -
*                    MD_OK, MD_ERROR1 or MD_ERROR2
***********************************************************************************************************************/
#if 0
uint8_t McuI2c0Receive(uint16_t adr, uint8_t * const rxBuf, uint16_t rxNum)
{
    volatile uint8_t dummy;
    uint16_t temp;
    if (adr > RIIC_ADDRESS_10BIT)
    {
	return MD_ERROR1;
    }
    
	/* Set parameter */
	i2c0RxLength = rxNum;
	i2c0RxCount = 0U;
	i2c0RxAddress = rxBuf;
	i2c0SlaveAddress = adr;
	i2c0DummyReadCount = 0U;
	i2c0ModeFlag = RIIC_MASTER_RECEIVE;

	if (adr <= RIIC_ADDRESS_7BIT)
	{
	    i2c0State = RIIC_MASTER_SENDS_ADR_7_R;
	}
	while ((RIIC_BUS_BUSY & RIIC0.CR2.UINT32) == RIIC_BUS_BUSY)
	{
	    NOP();
	}
	McuI2c0StartCondition();

	while((RIIC0.SR2.UINT32 & RIIC_TRANSMIT_DATA_EMPTY) != RIIC_TRANSMIT_DATA_EMPTY)
	{
	    NOP();
	}

	/* Transmitting slave address */
	RIIC0.DRT.UINT32 = (uint8_t)((i2c0SlaveAddress << RIIC_ADDRESS_7BIT_SHIFT)  | 
			    RIIC_ADDRESS_RECEIVE);
	i2c0State = RIIC_MASTER_RECEIVES_START;

	/* Wait for data */
	while((RIIC0.SR2.UINT32 & RIIC_RECEIVE_COMPLETE) != RIIC_RECEIVE_COMPLETE)
	{
	    NOP();
	}

	if((RIIC0.SR2.UINT32 & RIIC_NACK_DETECTED) != RIIC_NACK_DETECTED)
	{
	    while(i2c0RxLength > i2c0RxCount)
	    {

		if (RIIC_MASTER_RECEIVES_START == i2c0State)
		{
		    if ((2U == i2c0RxLength) || (1U == i2c0RxLength))
		    {
			RIIC0.MR3.UINT32 |= RIIC_WAIT;
		    }

		    if (1U == i2c0RxLength)
		    {
			RIIC0.MR3.UINT32 |= RIIC_RDRF_FLAG_SET_SCL_EIGHTH;
			RIIC0.MR3.UINT32 |= RIIC_ACKBT_BIT_MODIFICATION_ENABLED;
			RIIC0.MR3.UINT32 |= RIIC_NACK_TRANSMISSION;
		    }

		    /* Dummy read to release SCL */
		    dummy = (uint8_t)RIIC0.DRR.UINT32;

		    if (1U == i2c0RxLength)
		    {
			i2c0State = RIIC_MASTER_RECEIVES_STOPPING;
		    }
		    else
		    {
			i2c0State = RIIC_MASTER_RECEIVES_DATA;
		    }
		}
		else if (RIIC_MASTER_RECEIVES_DATA == i2c0State)
		{
		    temp = i2c0RxLength;
		    if (i2c0RxCount < temp)
		    {
			if ((temp - 3U) == i2c0RxCount)
			{
			    RIIC0.MR3.UINT32 |= RIIC_WAIT;
			    while((RIIC0.SR2.UINT32 & RIIC_RECEIVE_COMPLETE) != RIIC_RECEIVE_COMPLETE)
			    {
				NOP();
			    }
			    *i2c0RxAddress = (uint8_t)RIIC0.DRR.UINT32;
			    i2c0RxAddress++;
			    i2c0RxCount++;
			}
			else if ((temp - 2U) == i2c0RxCount)
			{
			    RIIC0.MR3.UINT32 |= RIIC_RDRF_FLAG_SET_SCL_EIGHTH;
			    RIIC0.MR3.UINT32 |= RIIC_ACKBT_BIT_MODIFICATION_ENABLED;
			    RIIC0.MR3.UINT32 |= RIIC_NACK_TRANSMISSION;
			    while((RIIC0.SR2.UINT32 & RIIC_RECEIVE_COMPLETE) != RIIC_RECEIVE_COMPLETE)
			    {
				NOP();
			    }
			    *i2c0RxAddress = (uint8_t)RIIC0.DRR.UINT32;
			    i2c0RxAddress++;
			    i2c0RxCount++;
			    i2c0State = RIIC_MASTER_RECEIVES_STOPPING;
			}
			else
			{
			    while((RIIC0.SR2.UINT32 & RIIC_RECEIVE_COMPLETE) != RIIC_RECEIVE_COMPLETE)
			    {
				NOP();
			    }
			    *i2c0RxAddress = (uint8_t)RIIC0.DRR.UINT32;
			    i2c0RxAddress++;
			    i2c0RxCount++;
			}
		    }
		}
		else if (RIIC_MASTER_RECEIVES_STOPPING == i2c0State)
		{
		    //while((RIIC0.SR2.UINT32 & RIIC_RECEIVE_COMPLETE) != RIIC_RECEIVE_COMPLETE);
		    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_STOP_CONDITION_DETECTED;
		    RIIC0.CR2.UINT32 |= RIIC_STOP_CONDITION_REQUEST;			
		    *i2c0RxAddress = (uint8_t)RIIC0.DRR.UINT32;
		    i2c0RxAddress++;
		    i2c0RxCount++;
		    RIIC0.MR3.UINT32 &= (uint32_t) ~RIIC_WAIT;
		    McuI2c0ReceiveStopCondition();
		}
		else
		{
		    /* Error condition to be defined */
		}

	    }
	}
	else
	{
	    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_STOP_CONDITION_DETECTED;
	    RIIC0.CR2.UINT32 |= RIIC_STOP_CONDITION_REQUEST;
	    dummy = (uint8_t)RIIC0.DRR.UINT32;
	    McuI2c0ReceiveStopCondition();
	}

    
}
#endif
/***********************************************************************************************************************
* Function Name: McuI2CStartCondition
* Description  : This function generates IIC start condition.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuI2CStartCondition(void)
{
    /* Set start condition flag */
    RIIC0.CR2.UINT32 |= RIIC_START_CONDITION_REQUEST;
}

/***********************************************************************************************************************
* Function Name: McuI2CStopCondition
* Description  : This function generates IIC stop condition.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuI2CStopCondition(void)
{
    /* Set stop condition flag */
    RIIC0.CR2.UINT32 |= RIIC_STOP_CONDITION_REQUEST;
}

/*-----------------------------------------------------------------------------
** Function: McuI2c0TransmitStopCondition
**
** Description:
** This function generates I2C stop condition for Transmitend.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuI2c0TransmitStopCondition(void)
{
    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_STOP_CONDITION_DETECTED;
    RIIC0.CR2.UINT32 |= RIIC_STOP_CONDITION_REQUEST;
    while ((RIIC0.SR2.UINT32 & RIIC_STOP_CONDITION_DETECTED) != RIIC_STOP_CONDITION_DETECTED)
    {
	    NOP();
    }
    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_NACK_DETECTED;
    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_STOP_CONDITION_DETECTED;
}
/*-----------------------------------------------------------------------------
** Function: McuI2c0ReceiveStopCondition
**
** Description:
** This function generates I2C stop condition for Receive end.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuI2c0ReceiveStopCondition(void)
{
    while ((RIIC0.SR2.UINT32 & RIIC_STOP_CONDITION_DETECTED) != RIIC_STOP_CONDITION_DETECTED)
    {
	    NOP();
    }
    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_NACK_DETECTED;
    RIIC0.SR2.UINT32 &= (uint32_t) ~RIIC_STOP_CONDITION_DETECTED;
}
/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
