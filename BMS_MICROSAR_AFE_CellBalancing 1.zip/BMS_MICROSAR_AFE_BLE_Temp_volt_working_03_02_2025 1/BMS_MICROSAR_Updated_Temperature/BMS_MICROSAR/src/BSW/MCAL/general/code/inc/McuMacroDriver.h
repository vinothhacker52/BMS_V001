/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                         
** File: McuMacroDriver.h
**
** Description:
** Header file containing Macro header file for code generation.
**---------------------------------------------------------------------------*/
#ifndef MCU_MACRO_DRIVER_H
#define MCU_MACRO_DRIVER_H

#include "dr7f701690.dvf.h  "
#include <stdbool.h>
#include "McuTypedefs.h"

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#ifndef __TYPEDEF__
/*#define DI()      __DI()
#define EI()      __EI()
#define HALT()    __halt()
#define NOP()     __nop()*/
#define EI()      __asm("ei")
#define DI()      __asm("di")
#define NOP()     __asm("nop")
#define HALT()    __asm("halt")
#define __syncp() __asm("syncp")
#endif
/* Status list definition */
#define MD_STATUSBASE        (0x00U)
#define MD_OK                (MD_STATUSBASE + 0x00U) /* register setting OK */
#define MD_SPT               (MD_STATUSBASE + 0x01U) /* IIC stop */
#define MD_NACK              (MD_STATUSBASE + 0x02U) /* IIC no ACK */
#define MD_BUSY1             (MD_STATUSBASE + 0x03U) /* busy 1 */
#define MD_BUSY2             (MD_STATUSBASE + 0x04U) /* busy 2 */
#define MD_OVERRUN           (MD_STATUSBASE + 0x05U) /* IIC OVERRUN occur */
/* Error list definition */
#define MD_ERRORBASE         (0x80U)
#define MD_ERROR             (MD_ERRORBASE + 0x00U)  /* error */
#define MD_ARGERROR          (MD_ERRORBASE + 0x01U)  /* error argument input error */
#define MD_ERROR1            (MD_ERRORBASE + 0x02U)  /* error 1 */
#define MD_ERROR2            (MD_ERRORBASE + 0x03U)  /* error 2 */
#define MD_ERROR3            (MD_ERRORBASE + 0x04U)  /* error 3 */
#define MD_ERROR4            (MD_ERRORBASE + 0x05U)  /* error 4 */
#define MD_ERROR5            (MD_ERRORBASE + 0x06U)  /* error 5 */
#define MD_TIMEOUT           (MD_ERRORBASE + 0x07U) /* timeout occurred 
/* Write protected macro definition */
#define WRITE_PROTECT_COMMAND              (0x000000A5UL)  /* Write protected */
#define WRITE_PROTECT_ERROR_OCCURED	   (0x01)	
/* Interrupt request flag (RFxxx) */
#define INT_REQUEST_NOT_OCCUR              (0x0U)  /* No interrupt request is made */
/* Interrupt mask (MKxxx) */
#define INT_PROCESSING_ENABLED             (0x0U)  /* Enables interrupt processing */
#define INT_PROCESSING_DISABLED            (0x1U)  /* Disables interrupt processing */
/* Interrupt vector method select (TBxxx) */
#define INT_DIRECT_VECTOR                  (0x0U)  /* Direct jumping to an address by the level of priority */
#define INT_TABLE_VECTOR                   (0x1U)  /* Table reference */
/* Specify 16 interrupt priority levels (P3xxx,P2xxx,P1xxx,P0xxx) */
#define INT_PRIORITY_HIGHEST               (0x00C0U)  /* Level 0 (highest) */
#define INT_PRIORITY_LEVEL1                (0x00C1U)  /* Level 1 */
#define INT_PRIORITY_LEVEL2                (0x00C2U)  /* Level 2 */
#define INT_PRIORITY_LEVEL3                (0x00C3U)  /* Level 3 */
#define INT_PRIORITY_LEVEL4                (0x00C4U)  /* Level 4 */
#define INT_PRIORITY_LEVEL5                (0x00C5U)  /* Level 5 */
#define INT_PRIORITY_LEVEL6                (0x00C6U)  /* Level 6 */
#define INT_PRIORITY_LEVEL7                (0x00C7U)  /* Level 7 */
#define INT_PRIORITY_LEVEL8                (0x00C8U)  /* Level 8 */
#define INT_PRIORITY_LEVEL9                (0x00C9U)  /* Level 9 */
#define INT_PRIORITY_LEVEL10               (0x00CAU)  /* Level 10 */
#define INT_PRIORITY_LEVEL11               (0x00CBU)  /* Level 11 */
#define INT_PRIORITY_LEVEL12               (0x00CCU)  /* Level 12 */
#define INT_PRIORITY_LEVEL13               (0x00CDU)  /* Level 13 */
#define INT_PRIORITY_LEVEL14               (0x00CEU)  /* Level 14 */
#define INT_PRIORITY_LOWEST                (0x00CFU)  /* Level 15 (lowest) */
/* Specify PORT initialize clear bits */
#define PORT_CLEAR_BIT0                    (0xFFFEU)  /* clear bit 0 */
#define PORT_CLEAR_BIT1                    (0xFFFDU)  /* clear bit 1 */
#define PORT_CLEAR_BIT2                    (0xFFFBU)  /* clear bit 2 */
#define PORT_CLEAR_BIT3                    (0xFFF7U)  /* clear bit 3 */
#define PORT_CLEAR_BIT4                    (0xFFEFU)  /* clear bit 4 */
#define PORT_CLEAR_BIT5                    (0xFFDFU)  /* clear bit 5 */
#define PORT_CLEAR_BIT6                    (0xFFBFU)  /* clear bit 6 */
#define PORT_CLEAR_BIT7                    (0xFF7FU)  /* clear bit 7 */
#define PORT_CLEAR_BIT8                    (0xFEFFU)  /* clear bit 8 */
#define PORT_CLEAR_BIT9                    (0xFDFFU)  /* clear bit 9 */
#define PORT_CLEAR_BIT10                   (0xFBFFU)  /* clear bit 10 */
#define PORT_CLEAR_BIT11                   (0xF7FFU)  /* clear bit 11 */
#define PORT_CLEAR_BIT12                   (0xEFFFU)  /* clear bit 12 */
#define PORT_CLEAR_BIT13                   (0xDFFFU)  /* clear bit 13 */
#define PORT_CLEAR_BIT14                   (0xBFFFU)  /* clear bit 14 */
#define PORT_CLEAR_BIT15                   (0x7FFFU)  /* clear bit 15 */
/* Specify PORT initialize set bits */
#define PORT_SET_BIT0                      (0x0001U)  /* set bit 0 */
#define PORT_SET_BIT1                      (0x0002U)  /* set bit 1 */
#define PORT_SET_BIT2                      (0x0004U)  /* set bit 2 */
#define PORT_SET_BIT3                      (0x0008U)  /* set bit 3 */
#define PORT_SET_BIT4                      (0x0010U)  /* set bit 4 */
#define PORT_SET_BIT5                      (0x0020U)  /* set bit 5 */
#define PORT_SET_BIT6                      (0x0040U)  /* set bit 6 */
#define PORT_SET_BIT7                      (0x0080U)  /* set bit 7 */
#define PORT_SET_BIT8                      (0x0100U)  /* set bit 8 */
#define PORT_SET_BIT9                      (0x0200U)  /* set bit 9 */
#define PORT_SET_BIT10                     (0x0400U)  /* set bit 10 */
#define PORT_SET_BIT11                     (0x0800U)  /* set bit 11 */
#define PORT_SET_BIT12                     (0x1000U)  /* set bit 12 */
#define PORT_SET_BIT13                     (0x2000U)  /* set bit 13 */
#define PORT_SET_BIT14                     (0x4000U)  /* set bit 14 */
#define PORT_SET_BIT15                     (0x8000U)  /* set bit 15 */
/* Specify JPORT initialize clear bits */
#define JPORT_CLEAR_BIT0                   (0xFEU)  /* clear bit 0 */
#define JPORT_CLEAR_BIT1                   (0xFDU)  /* clear bit 1 */
#define JPORT_CLEAR_BIT2                   (0xFBU)  /* clear bit 2 */
#define JPORT_CLEAR_BIT3                   (0xF7U)  /* clear bit 3 */
#define JPORT_CLEAR_BIT4                   (0xEFU)  /* clear bit 4 */
#define JPORT_CLEAR_BIT5                   (0xDFU)  /* clear bit 5 */
#define JPORT_CLEAR_BIT6                   (0xBFU)  /* clear bit 6 */
#define JPORT_CLEAR_BIT7                   (0x7FU)  /* clear bit 7 */
/* Specify JPORT initialize set bits */
#define JPORT_SET_BIT0                     (0x01U)  /* set bit 0 */
#define JPORT_SET_BIT1                     (0x02U)  /* set bit 1 */
#define JPORT_SET_BIT2                     (0x04U)  /* set bit 2 */
#define JPORT_SET_BIT3                     (0x08U)  /* set bit 3 */
#define JPORT_SET_BIT4                     (0x10U)  /* set bit 4 */
#define JPORT_SET_BIT5                     (0x20U)  /* set bit 5 */
#define JPORT_SET_BIT6                     (0x40U)  /* set bit 6 */
#define JPORT_SET_BIT7                     (0x80U)  /* set bit 7 */
/* Specify PODCn register clear bits */
#define PODC_CLEAR_BIT0                    (0xFFFFFFFEUL)  /* clear bit 0 */
#define PODC_CLEAR_BIT1                    (0xFFFFFFFDUL)  /* clear bit 1 */
#define PODC_CLEAR_BIT2                    (0xFFFFFFFBUL)  /* clear bit 2 */
#define PODC_CLEAR_BIT3                    (0xFFFFFFF7UL)  /* clear bit 3 */
#define PODC_CLEAR_BIT4                    (0xFFFFFFEFUL)  /* clear bit 4 */
#define PODC_CLEAR_BIT5                    (0xFFFFFFDFUL)  /* clear bit 5 */
#define PODC_CLEAR_BIT6                    (0xFFFFFFBFUL)  /* clear bit 6 */
#define PODC_CLEAR_BIT7                    (0xFFFFFF7FUL)  /* clear bit 7 */
#define PODC_CLEAR_BIT8                    (0xFFFFFEFFUL)  /* clear bit 8 */
#define PODC_CLEAR_BIT9                    (0xFFFFFDFFUL)  /* clear bit 9 */
#define PODC_CLEAR_BIT10                   (0xFFFFFBFFUL)  /* clear bit 10 */
#define PODC_CLEAR_BIT11                   (0xFFFFF7FFUL)  /* clear bit 11 */
#define PODC_CLEAR_BIT12                   (0xFFFFEFFFUL)  /* clear bit 12 */
#define PODC_CLEAR_BIT13                   (0xFFFFDFFFUL)  /* clear bit 13 */
#define PODC_CLEAR_BIT14                   (0xFFFFBFFFUL)  /* clear bit 14 */
#define PODC_CLEAR_BIT15                   (0xFFFF7FFFUL)  /* clear bit 15 */
#define PODC_CLEAR_BIT16                   (0xFFFEFFFFUL)  /* clear bit 16 */
#define PODC_CLEAR_BIT17                   (0xFFFDFFFFUL)  /* clear bit 17 */
#define PODC_CLEAR_BIT18                   (0xFFFBFFFFUL)  /* clear bit 18 */
#define PODC_CLEAR_BIT19                   (0xFFF7FFFFUL)  /* clear bit 19 */
#define PODC_CLEAR_BIT20                   (0xFFEFFFFFUL)  /* clear bit 20 */
#define PODC_CLEAR_BIT21                   (0xFFDFFFFFUL)  /* clear bit 21 */
#define PODC_CLEAR_BIT22                   (0xFFBFFFFFUL)  /* clear bit 22 */
#define PODC_CLEAR_BIT23                   (0xFF7FFFFFUL)  /* clear bit 23 */
#define PODC_CLEAR_BIT24                   (0xFEFFFFFFUL)  /* clear bit 24 */
#define PODC_CLEAR_BIT25                   (0xFDFFFFFFUL)  /* clear bit 25 */
#define PODC_CLEAR_BIT26                   (0xFBFFFFFFUL)  /* clear bit 26 */
#define PODC_CLEAR_BIT27                   (0xF7FFFFFFUL)  /* clear bit 27 */
#define PODC_CLEAR_BIT28                   (0xEFFFFFFFUL)  /* clear bit 28 */
#define PODC_CLEAR_BIT29                   (0xDFFFFFFFUL)  /* clear bit 29 */
#define PODC_CLEAR_BIT30                   (0xBFFFFFFFUL)  /* clear bit 30 */
#define PODC_CLEAR_BIT31                   (0x7FFFFFFFUL)  /* clear bit 31 */
/* Specify PODCn register set bits */
#define PODC_SET_BIT0                      (0x00000001UL)  /* set bit 0 */
#define PODC_SET_BIT1                      (0x00000002UL)  /* set bit 1 */
#define PODC_SET_BIT2                      (0x00000004UL)  /* set bit 2 */
#define PODC_SET_BIT3                      (0x00000008UL)  /* set bit 3 */
#define PODC_SET_BIT4                      (0x00000010UL)  /* set bit 4 */
#define PODC_SET_BIT5                      (0x00000020UL)  /* set bit 5 */
#define PODC_SET_BIT6                      (0x00000040UL)  /* set bit 6 */
#define PODC_SET_BIT7                      (0x00000080UL)  /* set bit 7 */
#define PODC_SET_BIT8                      (0x00000100UL)  /* set bit 8 */
#define PODC_SET_BIT9                      (0x00000200UL)  /* set bit 9 */
#define PODC_SET_BIT10                     (0x00000400UL)  /* set bit 10 */
#define PODC_SET_BIT11                     (0x00000800UL)  /* set bit 11 */
#define PODC_SET_BIT12                     (0x00001000UL)  /* set bit 12 */
#define PODC_SET_BIT13                     (0x00002000UL)  /* set bit 13 */
#define PODC_SET_BIT14                     (0x00004000UL)  /* set bit 14 */
#define PODC_SET_BIT15                     (0x00008000UL)  /* set bit 15 */
#define PODC_SET_BIT16                     (0x00010000UL)  /* set bit 16 */
#define PODC_SET_BIT17                     (0x00020000UL)  /* set bit 17 */
#define PODC_SET_BIT18                     (0x00040000UL)  /* set bit 18 */
#define PODC_SET_BIT19                     (0x00080000UL)  /* set bit 19 */
#define PODC_SET_BIT20                     (0x00100000UL)  /* set bit 20 */
#define PODC_SET_BIT21                     (0x00200000UL)  /* set bit 21 */
#define PODC_SET_BIT22                     (0x00400000UL)  /* set bit 22 */
#define PODC_SET_BIT23                     (0x00800000UL)  /* set bit 23 */
#define PODC_SET_BIT24                     (0x01000000UL)  /* set bit 24 */
#define PODC_SET_BIT25                     (0x02000000UL)  /* set bit 25 */
#define PODC_SET_BIT26                     (0x04000000UL)  /* set bit 26 */
#define PODC_SET_BIT27                     (0x08000000UL)  /* set bit 27 */
#define PODC_SET_BIT28                     (0x10000000UL)  /* set bit 28 */
#define PODC_SET_BIT29                     (0x20000000UL)  /* set bit 29 */
#define PODC_SET_BIT30                     (0x40000000UL)  /* set bit 30 */
#define PODC_SET_BIT31                     (0x80000000UL)  /* set bit 31 */

/* Common Macros*/
#define SET_BIT(REG,BIT)	((REG) |= (1<<((uint8_t)BIT)))
#define CLEAR_BIT(REG,BIT)	((REG) &= ~(1<<((uint8_t)BIT)))

#define	ZERO_BASE_INDEX	0U
#define ONE_BASE_INDEX	1U

#define SINGLE_INDEX_INCREMENT	1U
#define DOUBLE_INDEX_INCREMENT	2U

#define SHIFT_TWO_BYTES		16U

#define PERCENTAGE_CONVERSION_FACTOR	0.01f

#define NULL 0



/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void McuSysteminit(void);

#endif // MCU_MACRO_DRIVER_H

/*--------------------------- End McuMacroDriver.h -----------------------------*/
