#include "SystemCommonIncludes.h"
#include "McuMacroDriver.h"
#include "McuCan.h"
#include "SystemCan.h"
#include "SystemAdc.h"
#include "SystemGpio.h"
#include "SystemPwm.h"
#include "SystemOstim0.h"
#include "SystemAfe.h"
#include "SystemAfePrivate.h"
#include "SystemBle.h"

/***********Function Prototype****************/
extern void Systeminit();
void r_main_userinit(void);
void Task1Ms(void);
void CanMessage_Handler(void);
void delay_ms(uint16_t ms);

/************Variable From External Files*************/
volatile uint32_t milliTick;
extern volatile uint32_t _100MicroTick;
extern SystemUartAfeMeasRaw pRawMeasurements;
extern SystemUartAfeMeas pMeasurements;

int main(void)
{
    r_main_userinit();	
    SystemAfeInit();
    while(1)
    {
    SystemUartRdVoltage();
    SystemUartAfeCalc();
    SystemUartPcvmCanPacking();
    SystemUartRdTemp();
    
    }
}
void r_main_userinit(void)
{
    DI();
    Systeminit();
    EI();
}


void Task1Ms(void)
{
    static uint16_t tick1S = 0;
    SystemAfeCanMsgOut();
    tick1S++;
    if(tick1S > 1000){
	SystemBlePcvmSend();
	//SystemBleTempSend();
	tick1S = 0;
    }	
}

void delay_ms(uint16_t ms) 
{
    uint32_t temp = _100MicroTick;
    while((_100MicroTick - temp) < (ms * 10));
}

void delay100uS(uint16_t uS100){
    uint32_t temp = _100MicroTick;
    while((_100MicroTick - temp) < uS100);
}


