/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                         
** File: McuPortConfig.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for PORT peripheral.
**---------------------------------------------------------------------------*/
#ifndef MCU_PORT_CONFIG_H
#define MCU_PORT_CONFIG_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
/*
    Port Mode Register (PMn)
*/
/* PMn0 specifies input/output mode of the corresponding pin (PMn0) */
#define PORT_PMn0_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn0_MODE_INPUT                     (0x0001U) /* Input mode (output buffer off) */
#define PORT_PMn0_MODE_UNUSED                    (0x0001U) /* Unused mode */
/* PMn1 specifies input/output mode of the corresponding pin (PMn1) */
#define PORT_PMn1_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn1_MODE_INPUT                     (0x0002U) /* Input mode (output buffer off) */
#define PORT_PMn1_MODE_UNUSED                    (0x0002U) /* Unused mode */
/* PMn2 specifies input/output mode of the corresponding pin (PMn2) */
#define PORT_PMn2_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn2_MODE_INPUT                     (0x0004U) /* Input mode (output buffer off) */
#define PORT_PMn2_MODE_UNUSED                    (0x0004U) /* Unused mode */
/* PMn3 specifies input/output mode of the corresponding pin (PMn3) */
#define PORT_PMn3_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn3_MODE_INPUT                     (0x0008U) /* Input mode (output buffer off) */
#define PORT_PMn3_MODE_UNUSED                    (0x0008U) /* Unused mode */
/* PMn4 specifies input/output mode of the corresponding pin (PMn4) */
#define PORT_PMn4_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn4_MODE_INPUT                     (0x0010U) /* Input mode (output buffer off) */
#define PORT_PMn4_MODE_UNUSED                    (0x0010U) /* Unused mode */
/* PMn5 specifies input/output mode of the corresponding pin (PMn5) */
#define PORT_PMn5_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn5_MODE_INPUT                     (0x0020U) /* Input mode (output buffer off) */
#define PORT_PMn5_MODE_UNUSED                    (0x0020U) /* Unused mode */
/* PMn6 specifies input/output mode of the corresponding pin (PMn6) */
#define PORT_PMn6_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn6_MODE_INPUT                     (0x0040U) /* Input mode (output buffer off) */
#define PORT_PMn6_MODE_UNUSED                    (0x0040U) /* Unused mode */
/* PMn7 specifies input/output mode of the corresponding pin (PMn7) */
#define PORT_PMn7_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn7_MODE_INPUT                     (0x0080U) /* Input mode (output buffer off) */
#define PORT_PMn7_MODE_UNUSED                    (0x0080U) /* Unused mode */
/* PMn8 specifies input/output mode of the corresponding pin (PMn8) */
#define PORT_PMn8_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn8_MODE_INPUT                     (0x0100U) /* Input mode (output buffer off) */
#define PORT_PMn8_MODE_UNUSED                    (0x0100U) /* Unused mode */
/* PMn9 specifies input/output mode of the corresponding pin (PMn9) */
#define PORT_PMn9_MODE_OUTPUT                    (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn9_MODE_INPUT                     (0x0200U) /* Input mode (output buffer off) */
#define PORT_PMn9_MODE_UNUSED                    (0x0200U) /* Unused mode */
/* PMn10 specifies input/output mode of the corresponding pin (PMn10) */
#define PORT_PMn10_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn10_MODE_INPUT                    (0x0400U) /* Input mode (output buffer off) */
#define PORT_PMn10_MODE_UNUSED                   (0x0400U) /* Unused mode */
/* PMn11 specifies input/output mode of the corresponding pin (PMn11) */
#define PORT_PMn11_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn11_MODE_INPUT                    (0x0800U) /* Input mode (output buffer off) */
#define PORT_PMn11_MODE_UNUSED                   (0x0800U) /* Unused mode */
/* PMn12 specifies input/output mode of the corresponding pin (PMn12) */
#define PORT_PMn12_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn12_MODE_INPUT                    (0x1000U) /* Input mode (output buffer off) */
#define PORT_PMn12_MODE_UNUSED                   (0x1000U) /* Unused mode */
/* PMn13 specifies input/output mode of the corresponding pin (PMn13) */
#define PORT_PMn13_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn13_MODE_INPUT                    (0x2000U) /* Input mode (output buffer off) */
#define PORT_PMn13_MODE_UNUSED                   (0x2000U) /* Unused mode */
/* PMn14 specifies input/output mode of the corresponding pin (PMn14) */
#define PORT_PMn14_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn14_MODE_INPUT                    (0x4000U) /* Input mode (output buffer off) */
#define PORT_PMn14_MODE_UNUSED                   (0x4000U) /* Unused mode */
/* PMn15 specifies input/output mode of the corresponding pin (PMn15) */
#define PORT_PMn15_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_PMn15_MODE_INPUT                    (0x8000U) /* Input mode (output buffer off) */
#define PORT_PMn15_MODE_UNUSED                   (0x8000U) /* Unused mode */

/*
    Analog Port Mode Register (APMn)
*/
/* APMn0 specifies input/output mode of the corresponding pin (APMn0) */
#define PORT_APMn0_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn0_MODE_INPUT                    (0x0001U) /* Input mode (output buffer off) */
#define PORT_APMn0_MODE_UNUSED                   (0x0001U) /* Unused mode */
/* APMn1 specifies input/output mode of the corresponding pin (APMn1) */
#define PORT_APMn1_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn1_MODE_INPUT                    (0x0002U) /* Input mode (output buffer off) */
#define PORT_APMn1_MODE_UNUSED                   (0x0002U) /* Unused mode */
/* APMn2 specifies input/output mode of the corresponding pin (APMn2) */
#define PORT_APMn2_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn2_MODE_INPUT                    (0x0004U) /* Input mode (output buffer off) */
#define PORT_APMn2_MODE_UNUSED                   (0x0004U) /* Unused mode */
/* APMn3 specifies input/output mode of the corresponding pin (APMn3) */
#define PORT_APMn3_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn3_MODE_INPUT                    (0x0008U) /* Input mode (output buffer off) */
#define PORT_APMn3_MODE_UNUSED                   (0x0008U) /* Unused mode */
/* APMn4 specifies input/output mode of the corresponding pin (APMn4) */
#define PORT_APMn4_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn4_MODE_INPUT                    (0x0010U) /* Input mode (output buffer off) */
#define PORT_APMn4_MODE_UNUSED                   (0x0010U) /* Unused mode */
/* APMn5 specifies input/output mode of the corresponding pin (APMn5) */
#define PORT_APMn5_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn5_MODE_INPUT                    (0x0020U) /* Input mode (output buffer off) */
#define PORT_APMn5_MODE_UNUSED                   (0x0020U) /* Unused mode */
/* APMn6 specifies input/output mode of the corresponding pin (APMn6) */
#define PORT_APMn6_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn6_MODE_INPUT                    (0x0040U) /* Input mode (output buffer off) */
#define PORT_APMn6_MODE_UNUSED                   (0x0040U) /* Unused mode */
/* APMn7 specifies input/output mode of the corresponding pin (APMn7) */
#define PORT_APMn7_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn7_MODE_INPUT                    (0x0080U) /* Input mode (output buffer off) */
#define PORT_APMn7_MODE_UNUSED                   (0x0080U) /* Unused mode */
/* APMn8 specifies input/output mode of the corresponding pin (APMn8) */
#define PORT_APMn8_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn8_MODE_INPUT                    (0x0100U) /* Input mode (output buffer off) */
#define PORT_APMn8_MODE_UNUSED                   (0x0100U) /* Unused mode */
/* APMn9 specifies input/output mode of the corresponding pin (APMn9) */
#define PORT_APMn9_MODE_OUTPUT                   (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn9_MODE_INPUT                    (0x0200U) /* Input mode (output buffer off) */
#define PORT_APMn9_MODE_UNUSED                   (0x0200U) /* Unused mode */
/* APMn10 specifies input/output mode of the corresponding pin (APMn10) */
#define PORT_APMn10_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn10_MODE_INPUT                   (0x0400U) /* Input mode (output buffer off) */
#define PORT_APMn10_MODE_UNUSED                  (0x0400U) /* Unused mode */
/* APMn11 specifies input/output mode of the corresponding pin (APMn11) */
#define PORT_APMn11_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn11_MODE_INPUT                   (0x0800U) /* Input mode (output buffer off) */
#define PORT_APMn11_MODE_UNUSED                  (0x0800U) /* Unused mode */
/* APMn12 specifies input/output mode of the corresponding pin (APMn12) */
#define PORT_APMn12_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn12_MODE_INPUT                   (0x1000U) /* Input mode (output buffer off) */
#define PORT_APMn12_MODE_UNUSED                  (0x1000U) /* Unused mode */
/* APMn13 specifies input/output mode of the corresponding pin (APMn13) */
#define PORT_APMn13_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn13_MODE_INPUT                   (0x2000U) /* Input mode (output buffer off) */
#define PORT_APMn13_MODE_UNUSED                  (0x2000U) /* Unused mode */
/* APMn14 specifies input/output mode of the corresponding pin (APMn14) */
#define PORT_APMn14_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn14_MODE_INPUT                   (0x4000U) /* Input mode (output buffer off) */
#define PORT_APMn14_MODE_UNUSED                  (0x4000U) /* Unused mode */
/* APMn15 specifies input/output mode of the corresponding pin (APMn15) */
#define PORT_APMn15_MODE_OUTPUT                  (0x0000U) /* Output mode (output buffer on) */
#define PORT_APMn15_MODE_INPUT                   (0x8000U) /* Input mode (output buffer off) */
#define PORT_APMn15_MODE_UNUSED                  (0x8000U) /* Unused mode */

/*
    JTAG Port Mode Register (JPMn)
*/
/* JPMn0 specifies input/output mode of the corresponding pin (JPMn0) */
#define PORT_JPMn0_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn0_MODE_INPUT                    (0x01U) /* Input mode (output buffer off) */
#define PORT_JPMn0_MODE_UNUSED                   (0x01U) /* Unused mode */
/* JPMn1 specifies input/output mode of the corresponding pin (JPMn1) */
#define PORT_JPMn1_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn1_MODE_INPUT                    (0x02U) /* Input mode (output buffer off) */
#define PORT_JPMn1_MODE_UNUSED                   (0x02U) /* Unused mode */
/* JPMn2 specifies input/output mode of the corresponding pin (JPMn2) */
#define PORT_JPMn2_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn2_MODE_INPUT                    (0x04U) /* Input mode (output buffer off) */
#define PORT_JPMn2_MODE_UNUSED                   (0x04U) /* Unused mode */
/* JPMn3 specifies input/output mode of the corresponding pin (JPMn3) */
#define PORT_JPMn3_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn3_MODE_INPUT                    (0x08U) /* Input mode (output buffer off) */
#define PORT_JPMn3_MODE_UNUSED                   (0x08U) /* Unused mode */
/* JPMn4 specifies input/output mode of the corresponding pin (JPMn4) */
#define PORT_JPMn4_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn4_MODE_INPUT                    (0x10U) /* Input mode (output buffer off) */
#define PORT_JPMn4_MODE_UNUSED                   (0x10U) /* Unused mode */
/* JPMn5 specifies input/output mode of the corresponding pin (JPMn5) */
#define PORT_JPMn5_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn5_MODE_INPUT                    (0x20U) /* Input mode (output buffer off) */
#define PORT_JPMn5_MODE_UNUSED                   (0x20U) /* Unused mode */
/* JPMn6 specifies input/output mode of the corresponding pin (JPMn6) */
#define PORT_JPMn6_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn6_MODE_INPUT                    (0x40U) /* Input mode (output buffer off) */
#define PORT_JPMn6_MODE_UNUSED                   (0x40U) /* Unused mode */
/* JPMn7 specifies input/output mode of the corresponding pin (JPMn7) */
#define PORT_JPMn7_MODE_OUTPUT                   (0x00U) /* Output mode (output buffer on) */
#define PORT_JPMn7_MODE_INPUT                    (0x80U) /* Input mode (output buffer off) */
#define PORT_JPMn7_MODE_UNUSED                   (0x80U) /* Unused mode */

/*
    Port Input Buffer Control Register (PIBCn)
*/
/* PIBCn0 enable and disable the input buffer in input port mode. (PIBCn0) */
#define PORT_PIBCn0_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn0_INPUT_BUFFER_ENABLE          (0x0001U) /* Input buffer is enabled. */
/* PIBCn1 enable and disable the input buffer in input port mode. (PIBCn1) */
#define PORT_PIBCn1_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn1_INPUT_BUFFER_ENABLE          (0x0002U) /* Input buffer is enabled. */
/* PIBCn2 enable and disable the input buffer in input port mode. (PIBCn2) */
#define PORT_PIBCn2_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn2_INPUT_BUFFER_ENABLE          (0x0004U) /* Input buffer is enabled. */
/* PIBCn3 enable and disable the input buffer in input port mode. (PIBCn3) */
#define PORT_PIBCn3_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn3_INPUT_BUFFER_ENABLE          (0x0008U) /* Input buffer is enabled. */
/* PIBCn4 enable and disable the input buffer in input port mode. (PIBCn4) */
#define PORT_PIBCn4_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn4_INPUT_BUFFER_ENABLE          (0x0010U) /* Input buffer is enabled. */
/* PIBCn5 enable and disable the input buffer in input port mode. (PIBCn5) */
#define PORT_PIBCn5_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn5_INPUT_BUFFER_ENABLE          (0x0020U) /* Input buffer is enabled. */
/* PIBCn6 enable and disable the input buffer in input port mode. (PIBCn6) */
#define PORT_PIBCn6_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn6_INPUT_BUFFER_ENABLE          (0x0040U) /* Input buffer is enabled. */
/* PIBCn7 enable and disable the input buffer in input port mode. (PIBCn7) */
#define PORT_PIBCn7_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn7_INPUT_BUFFER_ENABLE          (0x0080U) /* Input buffer is enabled. */
/* PIBCn8 enable and disable the input buffer in input port mode. (PIBCn8) */
#define PORT_PIBCn8_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn8_INPUT_BUFFER_ENABLE          (0x0100U) /* Input buffer is enabled. */
/* PIBCn9 enable and disable the input buffer in input port mode. (PIBCn9) */
#define PORT_PIBCn9_INPUT_BUFFER_DISABLE         (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn9_INPUT_BUFFER_ENABLE          (0x0200U) /* Input buffer is enabled. */
/* PIBCn10 enable and disable the input buffer in input port mode. (PIBCn10) */
#define PORT_PIBCn10_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn10_INPUT_BUFFER_ENABLE         (0x0400U) /* Input buffer is enabled. */
/* PIBCn11 enable and disable the input buffer in input port mode. (PIBCn11) */
#define PORT_PIBCn11_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn11_INPUT_BUFFER_ENABLE         (0x0800U) /* Input buffer is enabled. */
/* PIBCn12 enable and disable the input buffer in input port mode. (PIBCn12) */
#define PORT_PIBCn12_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn12_INPUT_BUFFER_ENABLE         (0x1000U) /* Input buffer is enabled. */
/* PIBCn13 enable and disable the input buffer in input port mode. (PIBCn13) */
#define PORT_PIBCn13_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn13_INPUT_BUFFER_ENABLE         (0x2000U) /* Input buffer is enabled. */
/* PIBCn14 enable and disable the input buffer in input port mode. (PIBCn14) */
#define PORT_PIBCn14_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn14_INPUT_BUFFER_ENABLE         (0x4000U) /* Input buffer is enabled. */
/* PIBCn15 enable and disable the input buffer in input port mode. (PIBCn15) */
#define PORT_PIBCn15_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_PIBCn15_INPUT_BUFFER_ENABLE         (0x8000U) /* Input buffer is enabled. */

/*
    Analog Port Input Buffer Control Register (APIBCn)
*/
/* APIBCn0 enable and disable the input buffer in input port mode. (APIBCn0) */
#define PORT_APIBCn0_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn0_INPUT_BUFFER_ENABLE         (0x0001U) /* Input buffer is enabled. */
/* APIBCn1 enable and disable the input buffer in input port mode. (APIBCn1) */
#define PORT_APIBCn1_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn1_INPUT_BUFFER_ENABLE         (0x0002U) /* Input buffer is enabled. */
/* APIBCn2 enable and disable the input buffer in input port mode. (APIBCn2) */
#define PORT_APIBCn2_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn2_INPUT_BUFFER_ENABLE         (0x0004U) /* Input buffer is enabled. */
/* APIBCn3 enable and disable the input buffer in input port mode. (APIBCn3) */
#define PORT_APIBCn3_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn3_INPUT_BUFFER_ENABLE         (0x0008U) /* Input buffer is enabled. */
/* APIBCn4 enable and disable the input buffer in input port mode. (APIBCn4) */
#define PORT_APIBCn4_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn4_INPUT_BUFFER_ENABLE         (0x0010U) /* Input buffer is enabled. */
/* APIBCn5 enable and disable the input buffer in input port mode. (APIBCn5) */
#define PORT_APIBCn5_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn5_INPUT_BUFFER_ENABLE         (0x0020U) /* Input buffer is enabled. */
/* APIBCn6 enable and disable the input buffer in input port mode. (APIBCn6) */
#define PORT_APIBCn6_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn6_INPUT_BUFFER_ENABLE         (0x0040U) /* Input buffer is enabled. */
/* APIBCn7 enable and disable the input buffer in input port mode. (APIBCn7) */
#define PORT_APIBCn7_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn7_INPUT_BUFFER_ENABLE         (0x0080U) /* Input buffer is enabled. */
/* APIBCn8 enable and disable the input buffer in input port mode. (APIBCn8) */
#define PORT_APIBCn8_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn8_INPUT_BUFFER_ENABLE         (0x0100U) /* Input buffer is enabled. */
/* APIBCn9 enable and disable the input buffer in input port mode. (APIBCn9) */
#define PORT_APIBCn9_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn9_INPUT_BUFFER_ENABLE         (0x0200U) /* Input buffer is enabled. */
/* APIBCn10 enable and disable the input buffer in input port mode. (APIBCn10) */
#define PORT_APIBCn10_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn10_INPUT_BUFFER_ENABLE        (0x0400U) /* Input buffer is enabled. */
/* APIBCn11 enable and disable the input buffer in input port mode. (APIBCn11) */
#define PORT_APIBCn11_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn11_INPUT_BUFFER_ENABLE        (0x0800U) /* Input buffer is enabled. */
/* APIBCn12 enable and disable the input buffer in input port mode. (APIBCn12) */
#define PORT_APIBCn12_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn12_INPUT_BUFFER_ENABLE        (0x1000U) /* Input buffer is enabled. */
/* APIBCn13 enable and disable the input buffer in input port mode. (APIBCn13) */
#define PORT_APIBCn13_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn13_INPUT_BUFFER_ENABLE        (0x2000U) /* Input buffer is enabled. */
/* APIBCn14 enable and disable the input buffer in input port mode. (APIBCn14) */
#define PORT_APIBCn14_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn14_INPUT_BUFFER_ENABLE        (0x4000U) /* Input buffer is enabled. */
/* APIBCn15 enable and disable the input buffer in input port mode. (APIBCn15) */
#define PORT_APIBCn15_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_APIBCn15_INPUT_BUFFER_ENABLE        (0x8000U) /* Input buffer is enabled. */

/*
    JTAG Port Input Buffer Control Register (JPIBCn)
*/
/* JPIBCn0 enable and disable the input buffer in input port mode. (JPIBCn0) */
#define PORT_JPIBCn0_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn0_INPUT_BUFFER_ENABLE         (0x01U) /* Input buffer is enabled. */
/* JPIBCn1 enable and disable the input buffer in input port mode. (JPIBCn1) */
#define PORT_JPIBCn1_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn1_INPUT_BUFFER_ENABLE         (0x02U) /* Input buffer is enabled. */
/* JPIBCn2 enable and disable the input buffer in input port mode. (JPIBCn2) */
#define PORT_JPIBCn2_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn2_INPUT_BUFFER_ENABLE         (0x04U) /* Input buffer is enabled. */
/* JPIBCn3 enable and disable the input buffer in input port mode. (JPIBCn3) */
#define PORT_JPIBCn3_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn3_INPUT_BUFFER_ENABLE         (0x08U) /* Input buffer is enabled. */
/* JPIBCn4 enable and disable the input buffer in input port mode. (JPIBCn4) */
#define PORT_JPIBCn4_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn4_INPUT_BUFFER_ENABLE         (0x10U) /* Input buffer is enabled. */
/* JPIBCn5 enable and disable the input buffer in input port mode. (JPIBCn5) */
#define PORT_JPIBCn5_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn5_INPUT_BUFFER_ENABLE         (0x20U) /* Input buffer is enabled. */
/* JPIBCn6 enable and disable the input buffer in input port mode. (JPIBCn6) */
#define PORT_JPIBCn6_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn6_INPUT_BUFFER_ENABLE         (0x40U) /* Input buffer is enabled. */
/* JPIBCn7 enable and disable the input buffer in input port mode. (JPIBCn7) */
#define PORT_JPIBCn7_INPUT_BUFFER_DISABLE        (0x00U) /* Input buffer is disabled. */
#define PORT_JPIBCn7_INPUT_BUFFER_ENABLE         (0x80U) /* Input buffer is enabled. */

/*
    Input Port Input Buffer Control Register (IPIBCn)
*/
/* IPIBCn0 enable and disable the input buffer in input port mode. (IPIBCn0) */
#define PORT_IPIBCn0_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn0_INPUT_BUFFER_ENABLE         (0x0001U) /* Input buffer is enabled. */
/* IPIBCn1 enable and disable the input buffer in input port mode. (IPIBCn1) */
#define PORT_IPIBCn1_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn1_INPUT_BUFFER_ENABLE         (0x0002U) /* Input buffer is enabled. */
/* IPIBCn2 enable and disable the input buffer in input port mode. (IPIBCn2) */
#define PORT_IPIBCn2_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn2_INPUT_BUFFER_ENABLE         (0x0004U) /* Input buffer is enabled. */
/* IPIBCn3 enable and disable the input buffer in input port mode. (IPIBCn3) */
#define PORT_IPIBCn3_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn3_INPUT_BUFFER_ENABLE         (0x0008U) /* Input buffer is enabled. */
/* IPIBCn4 enable and disable the input buffer in input port mode. (IPIBCn4) */
#define PORT_IPIBCn4_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn4_INPUT_BUFFER_ENABLE         (0x0010U) /* Input buffer is enabled. */
/* IPIBCn5 enable and disable the input buffer in input port mode. (IPIBCn5) */
#define PORT_IPIBCn5_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn5_INPUT_BUFFER_ENABLE         (0x0020U) /* Input buffer is enabled. */
/* IPIBCn6 enable and disable the input buffer in input port mode. (IPIBCn6) */
#define PORT_IPIBCn6_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn6_INPUT_BUFFER_ENABLE         (0x0040U) /* Input buffer is enabled. */
/* IPIBCn7 enable and disable the input buffer in input port mode. (IPIBCn7) */
#define PORT_IPIBCn7_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn7_INPUT_BUFFER_ENABLE         (0x0080U) /* Input buffer is enabled. */
/* IPIBCn8 enable and disable the input buffer in input port mode. (IPIBCn8) */
#define PORT_IPIBCn8_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn8_INPUT_BUFFER_ENABLE         (0x0100U) /* Input buffer is enabled. */
/* IPIBCn9 enable and disable the input buffer in input port mode. (IPIBCn9) */
#define PORT_IPIBCn9_INPUT_BUFFER_DISABLE        (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn9_INPUT_BUFFER_ENABLE         (0x0200U) /* Input buffer is enabled. */
/* IPIBCn10 enable and disable the input buffer in input port mode. (IPIBCn10) */
#define PORT_IPIBCn10_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn10_INPUT_BUFFER_ENABLE        (0x0400U) /* Input buffer is enabled. */
/* IPIBCn11 enable and disable the input buffer in input port mode. (IPIBCn11) */
#define PORT_IPIBCn11_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn11_INPUT_BUFFER_ENABLE        (0x0800U) /* Input buffer is enabled. */
/* IPIBCn12 enable and disable the input buffer in input port mode. (IPIBCn12) */
#define PORT_IPIBCn12_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn12_INPUT_BUFFER_ENABLE        (0x1000U) /* Input buffer is enabled. */
/* IPIBCn13 enable and disable the input buffer in input port mode. (IPIBCn13) */
#define PORT_IPIBCn13_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn13_INPUT_BUFFER_ENABLE        (0x2000U) /* Input buffer is enabled. */
/* IPIBCn14 enable and disable the input buffer in input port mode. (IPIBCn14) */
#define PORT_IPIBCn14_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn14_INPUT_BUFFER_ENABLE        (0x4000U) /* Input buffer is enabled. */
/* IPIBCn15 enable and disable the input buffer in input port mode. (IPIBCn15) */
#define PORT_IPIBCn15_INPUT_BUFFER_DISABLE       (0x0000U) /* Input buffer is disabled. */
#define PORT_IPIBCn15_INPUT_BUFFER_ENABLE        (0x8000U) /* Input buffer is enabled. */

/*
    Port Bidirection Control Register (PBDCn)
*/
/* PBDCn0 enables/disables bidirectional mode of the corresponding pin (PBDCn0) */
#define PORT_PBDCn0_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn0_MODE_ENABLE                  (0x0001U) /* Bidirectional mode enabled */
/* PBDCn1 enables/disables bidirectional mode of the corresponding pin (PBDCn1) */
#define PORT_PBDCn1_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn1_MODE_ENABLE                  (0x0002U) /* Bidirectional mode enabled */
/* PBDCn2 enables/disables bidirectional mode of the corresponding pin (PBDCn2) */
#define PORT_PBDCn2_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn2_MODE_ENABLE                  (0x0004U) /* Bidirectional mode enabled */
/* PBDCn3 enables/disables bidirectional mode of the corresponding pin (PBDCn3) */
#define PORT_PBDCn3_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn3_MODE_ENABLE                  (0x0008U) /* Bidirectional mode enabled */
/* PBDCn4 enables/disables bidirectional mode of the corresponding pin (PBDCn4) */
#define PORT_PBDCn4_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn4_MODE_ENABLE                  (0x0010U) /* Bidirectional mode enabled */
/* PBDCn5 enables/disables bidirectional mode of the corresponding pin (PBDCn5) */
#define PORT_PBDCn5_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn5_MODE_ENABLE                  (0x0020U) /* Bidirectional mode enabled */
/* PBDCn6 enables/disables bidirectional mode of the corresponding pin (PBDCn6) */
#define PORT_PBDCn6_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn6_MODE_ENABLE                  (0x0040U) /* Bidirectional mode enabled */
/* PBDCn7 enables/disables bidirectional mode of the corresponding pin (PBDCn7) */
#define PORT_PBDCn7_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn7_MODE_ENABLE                  (0x0080U) /* Bidirectional mode enabled */
/* PBDCn8 enables/disables bidirectional mode of the corresponding pin (PBDCn8) */
#define PORT_PBDCn8_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn8_MODE_ENABLE                  (0x0100U) /* Bidirectional mode enabled */
/* PBDCn9 enables/disables bidirectional mode of the corresponding pin (PBDCn9) */
#define PORT_PBDCn9_MODE_DISABLED                (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn9_MODE_ENABLE                  (0x0200U) /* Bidirectional mode enabled */
/* PBDCn10 enables/disables bidirectional mode of the corresponding pin (PBDCn10) */
#define PORT_PBDCn10_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn10_MODE_ENABLE                 (0x0400U) /* Bidirectional mode enabled */
/* PBDCn11 enables/disables bidirectional mode of the corresponding pin (PBDCn11) */
#define PORT_PBDCn11_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn11_MODE_ENABLE                 (0x0800U) /* Bidirectional mode enabled */
/* PBDCn12 enables/disables bidirectional mode of the corresponding pin (PBDCn12) */
#define PORT_PBDCn12_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn12_MODE_ENABLE                 (0x1000U) /* Bidirectional mode enabled */
/* PBDCn13 enables/disables bidirectional mode of the corresponding pin (PBDCn13) */
#define PORT_PBDCn13_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn13_MODE_ENABLE                 (0x2000U) /* Bidirectional mode enabled */
/* PBDCn14 enables/disables bidirectional mode of the corresponding pin (PBDCn14) */
#define PORT_PBDCn14_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn14_MODE_ENABLE                 (0x4000U) /* Bidirectional mode enabled */
/* PBDCn15 enables/disables bidirectional mode of the corresponding pin (PBDCn15) */
#define PORT_PBDCn15_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_PBDCn15_MODE_ENABLE                 (0x8000U) /* Bidirectional mode enabled */

/*
    Analog Port Bidirection Control Register (APBDCn)
*/
/* APBDCn0 enables/disables bidirectional mode of the corresponding pin (APBDCn0) */
#define PORT_APBDCn0_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn0_MODE_ENABLE                 (0x0001U) /* Bidirectional mode enabled */
/* APBDCn1 enables/disables bidirectional mode of the corresponding pin (APBDCn1) */
#define PORT_APBDCn1_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn1_MODE_ENABLE                 (0x0002U) /* Bidirectional mode enabled */
/* APBDCn2 enables/disables bidirectional mode of the corresponding pin (APBDCn2) */
#define PORT_APBDCn2_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn2_MODE_ENABLE                 (0x0004U) /* Bidirectional mode enabled */
/* APBDCn3 enables/disables bidirectional mode of the corresponding pin (APBDCn3) */
#define PORT_APBDCn3_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn3_MODE_ENABLE                 (0x0008U) /* Bidirectional mode enabled */
/* APBDCn4 enables/disables bidirectional mode of the corresponding pin (APBDCn4) */
#define PORT_APBDCn4_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn4_MODE_ENABLE                 (0x0010U) /* Bidirectional mode enabled */
/* APBDCn5 enables/disables bidirectional mode of the corresponding pin (APBDCn5) */
#define PORT_APBDCn5_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn5_MODE_ENABLE                 (0x0020U) /* Bidirectional mode enabled */
/* APBDCn6 enables/disables bidirectional mode of the corresponding pin (APBDCn6) */
#define PORT_APBDCn6_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn6_MODE_ENABLE                 (0x0040U) /* Bidirectional mode enabled */
/* APBDCn7 enables/disables bidirectional mode of the corresponding pin (APBDCn7) */
#define PORT_APBDCn7_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn7_MODE_ENABLE                 (0x0080U) /* Bidirectional mode enabled */
/* APBDCn8 enables/disables bidirectional mode of the corresponding pin (APBDCn8) */
#define PORT_APBDCn8_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn8_MODE_ENABLE                 (0x0100U) /* Bidirectional mode enabled */
/* APBDCn9 enables/disables bidirectional mode of the corresponding pin (APBDCn9) */
#define PORT_APBDCn9_MODE_DISABLED               (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn9_MODE_ENABLE                 (0x0200U) /* Bidirectional mode enabled */
/* APBDCn10 enables/disables bidirectional mode of the corresponding pin (APBDCn10) */
#define PORT_APBDCn10_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn10_MODE_ENABLE                (0x0400U) /* Bidirectional mode enabled */
/* APBDCn11 enables/disables bidirectional mode of the corresponding pin (APBDCn11) */
#define PORT_APBDCn11_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn11_MODE_ENABLE                (0x0800U) /* Bidirectional mode enabled */
/* APBDCn12 enables/disables bidirectional mode of the corresponding pin (APBDCn12) */
#define PORT_APBDCn12_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn12_MODE_ENABLE                (0x1000U) /* Bidirectional mode enabled */
/* APBDCn13 enables/disables bidirectional mode of the corresponding pin (APBDCn13) */
#define PORT_APBDCn13_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn13_MODE_ENABLE                (0x2000U) /* Bidirectional mode enabled */
/* APBDCn14 enables/disables bidirectional mode of the corresponding pin (APBDCn14) */
#define PORT_APBDCn14_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn14_MODE_ENABLE                (0x4000U) /* Bidirectional mode enabled */
/* APBDCn15 enables/disables bidirectional mode of the corresponding pin (APBDCn15) */
#define PORT_APBDCn15_MODE_DISABLED              (0x0000U) /* Bidirectional mode disabled */
#define PORT_APBDCn15_MODE_ENABLE                (0x8000U) /* Bidirectional mode enabled */

/*
    JTAG Port Bidirection Control Register (JPBDCn)
*/
/* JPBDCn0 enables/disables bidirectional mode of the corresponding pin (JPBDCn0) */
#define PORT_JPBDCn0_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn0_MODE_ENABLE                 (0x01U) /* Bidirectional mode enabled */
/* JPBDCn1 enables/disables bidirectional mode of the corresponding pin (JPBDCn1) */
#define PORT_JPBDCn1_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn1_MODE_ENABLE                 (0x02U) /* Bidirectional mode enabled */
/* JPBDCn2 enables/disables bidirectional mode of the corresponding pin (JPBDCn2) */
#define PORT_JPBDCn2_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn2_MODE_ENABLE                 (0x04U) /* Bidirectional mode enabled */
/* JPBDCn3 enables/disables bidirectional mode of the corresponding pin (JPBDCn3) */
#define PORT_JPBDCn3_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn3_MODE_ENABLE                 (0x08U) /* Bidirectional mode enabled */
/* JPBDCn4 enables/disables bidirectional mode of the corresponding pin (JPBDCn4) */
#define PORT_JPBDCn4_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn4_MODE_ENABLE                 (0x10U) /* Bidirectional mode enabled */
/* JPBDCn5 enables/disables bidirectional mode of the corresponding pin (JPBDCn5) */
#define PORT_JPBDCn5_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn5_MODE_ENABLE                 (0x20U) /* Bidirectional mode enabled */
/* JPBDCn6 enables/disables bidirectional mode of the corresponding pin (JPBDCn6) */
#define PORT_JPBDCn6_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn6_MODE_ENABLE                 (0x40U) /* Bidirectional mode enabled */
/* JPBDCn7 enables/disables bidirectional mode of the corresponding pin (JPBDCn7) */
#define PORT_JPBDCn7_MODE_DISABLED               (0x00U) /* Bidirectional mode disabled */
#define PORT_JPBDCn7_MODE_ENABLE                 (0x80U) /* Bidirectional mode enabled */

/*
    Port NOT Register (PNOTn / APNOTn / JPNOT0)
*/
/* PNOTn0 specifies if Pn.Pn_0 is inverted (PNOTn0) */
#define PORT_PNOTn0_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn0_INVERTED_ENABLE              (0x0001U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn1 specifies if Pn.Pn_0 is inverted (PNOTn1) */
#define PORT_PNOTn1_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn1_INVERTED_ENABLE              (0x0002U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn2 specifies if Pn.Pn_0 is inverted (PNOTn2) */
#define PORT_PNOTn2_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn2_INVERTED_ENABLE              (0x0004U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn3 specifies if Pn.Pn_0 is inverted (PNOTn3) */
#define PORT_PNOTn3_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn3_INVERTED_ENABLE              (0x0008U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn4 specifies if Pn.Pn_0 is inverted (PNOTn4) */
#define PORT_PNOTn4_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn4_INVERTED_ENABLE              (0x0010U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn5 specifies if Pn.Pn_0 is inverted (PNOTn5) */
#define PORT_PNOTn5_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn5_INVERTED_ENABLE              (0x0020U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn6 specifies if Pn.Pn_0 is inverted (PNOTn6) */
#define PORT_PNOTn6_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn6_INVERTED_ENABLE              (0x0040U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn7 specifies if Pn.Pn_0 is inverted (PNOTn7) */
#define PORT_PNOTn7_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn7_INVERTED_ENABLE              (0x0080U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn8 specifies if Pn.Pn_0 is inverted (PNOTn8) */
#define PORT_PNOTn8_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn8_INVERTED_ENABLE              (0x0100U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn9 specifies if Pn.Pn_0 is inverted (PNOTn9) */
#define PORT_PNOTn9_INVERTED_DISABLE             (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn9_INVERTED_ENABLE              (0x0200U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn10 specifies if Pn.Pn_0 is inverted (PNOTn10) */
#define PORT_PNOTn10_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn10_INVERTED_ENABLE             (0x0400U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn11 specifies if Pn.Pn_0 is inverted (PNOTn11) */
#define PORT_PNOTn11_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn11_INVERTED_ENABLE             (0x0800U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn12 specifies if Pn.Pn_0 is inverted (PNOTn12) */
#define PORT_PNOTn12_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn12_INVERTED_ENABLE             (0x1000U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn13 specifies if Pn.Pn_0 is inverted (PNOTn13) */
#define PORT_PNOTn13_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn13_INVERTED_ENABLE             (0x2000U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn14 specifies if Pn.Pn_0 is inverted (PNOTn14) */
#define PORT_PNOTn14_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn14_INVERTED_ENABLE             (0x4000U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */
/* PNOTn15 specifies if Pn.Pn_0 is inverted (PNOTn15) */
#define PORT_PNOTn15_INVERTED_DISABLE            (0x0000U) /* Pn.Pn_m is not inverted (Pn_m to Pn_m) */
#define PORT_PNOTn15_INVERTED_ENABLE             (0x8000U) /* Pn.Pn_m is inverted (~Pn_m to Pn_m) */

/*
    Port Register (Pn)
*/
/* Pn0 sets the output level of pin Pn_m (Pn0) */
#define PORT_Pn0_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn0_OUTPUT_HIGH                     (0x0001U) /* Outputs high level */
/* Pn1 sets the output level of pin Pn_m (Pn1) */
#define PORT_Pn1_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn1_OUTPUT_HIGH                     (0x0002U) /* Outputs high level */
/* Pn2 sets the output level of pin Pn_m (Pn2) */
#define PORT_Pn2_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn2_OUTPUT_HIGH                     (0x0004U) /* Outputs high level */
/* Pn3 sets the output level of pin Pn_m (Pn3) */
#define PORT_Pn3_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn3_OUTPUT_HIGH                     (0x0008U) /* Outputs high level */
/* Pn4 sets the output level of pin Pn_m (Pn4) */
#define PORT_Pn4_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn4_OUTPUT_HIGH                     (0x0010U) /* Outputs high level */
/* Pn5 sets the output level of pin Pn_m (Pn5) */
#define PORT_Pn5_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn5_OUTPUT_HIGH                     (0x0020U) /* Outputs high level */
/* Pn6 sets the output level of pin Pn_m (Pn6) */
#define PORT_Pn6_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn6_OUTPUT_HIGH                     (0x0040U) /* Outputs high level */
/* Pn7 sets the output level of pin Pn_m (Pn7) */
#define PORT_Pn7_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn7_OUTPUT_HIGH                     (0x0080U) /* Outputs high level */
/* Pn8 sets the output level of pin Pn_m (Pn8) */
#define PORT_Pn8_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn8_OUTPUT_HIGH                     (0x0100U) /* Outputs high level */
/* Pn9 sets the output level of pin Pn_m (Pn9) */
#define PORT_Pn9_OUTPUT_LOW                      (0x0000U) /* Outputs low level */
#define PORT_Pn9_OUTPUT_HIGH                     (0x0200U) /* Outputs high level */
/* Pn10 sets the output level of pin Pn_m (Pn10) */
#define PORT_Pn10_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn10_OUTPUT_HIGH                    (0x0400U) /* Outputs high level */
/* Pn11 sets the output level of pin Pn_m (Pn11) */
#define PORT_Pn11_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn11_OUTPUT_HIGH                    (0x0800U) /* Outputs high level */
/* Pn12 sets the output level of pin Pn_m (Pn12) */
#define PORT_Pn12_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn12_OUTPUT_HIGH                    (0x1000U) /* Outputs high level */
/* Pn13 sets the output level of pin Pn_m (Pn13) */
#define PORT_Pn13_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn13_OUTPUT_HIGH                    (0x2000U) /* Outputs high level */
/* Pn14 sets the output level of pin Pn_m (Pn14) */
#define PORT_Pn14_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn14_OUTPUT_HIGH                    (0x4000U) /* Outputs high level */
/* Pn15 sets the output level of pin Pn_m (Pn15) */
#define PORT_Pn15_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_Pn15_OUTPUT_HIGH                    (0x8000U) /* Outputs high level */

/*
    Analog Port Register (APn)
*/
/* Pn0 sets the output level of pin Pn_m (APn0) */
#define PORT_APn0_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn0_OUTPUT_HIGH                    (0x0001U) /* Outputs high level */
/* Pn1 sets the output level of pin Pn_m (APn1) */
#define PORT_APn1_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn1_OUTPUT_HIGH                    (0x0002U) /* Outputs high level */
/* APn2 sets the output level of pin Pn_m (APn2) */
#define PORT_APn2_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn2_OUTPUT_HIGH                    (0x0004U) /* Outputs high level */
/* APn3 sets the output level of pin Pn_m (APn3) */
#define PORT_APn3_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn3_OUTPUT_HIGH                    (0x0008U) /* Outputs high level */
/* APn4 sets the output level of pin Pn_m (APn4) */
#define PORT_APn4_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn4_OUTPUT_HIGH                    (0x0010U) /* Outputs high level */
/* APn5 sets the output level of pin Pn_m (APn5) */
#define PORT_APn5_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn5_OUTPUT_HIGH                    (0x0020U) /* Outputs high level */
/* APn6 sets the output level of pin Pn_m (APn6) */
#define PORT_APn6_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn6_OUTPUT_HIGH                    (0x0040U) /* Outputs high level */
/* APn7 sets the output level of pin Pn_m (APn7) */
#define PORT_APn7_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn7_OUTPUT_HIGH                    (0x0080U) /* Outputs high level */
/* APn8 sets the output level of pin Pn_m (APn8) */
#define PORT_APn8_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn8_OUTPUT_HIGH                    (0x0100U) /* Outputs high level */
/* APn9 sets the output level of pin Pn_m (APn9) */
#define PORT_APn9_OUTPUT_LOW                     (0x0000U) /* Outputs low level */
#define PORT_APn9_OUTPUT_HIGH                    (0x0200U) /* Outputs high level */
/* APn10 sets the output level of pin Pn_m (APn10) */
#define PORT_APn10_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn10_OUTPUT_HIGH                   (0x0400U) /* Outputs high level */
/* APn11 sets the output level of pin Pn_m (APn11) */
#define PORT_APn11_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn11_OUTPUT_HIGH                   (0x0800U) /* Outputs high level */
/* APn12 sets the output level of pin Pn_m (APn12) */
#define PORT_APn12_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn12_OUTPUT_HIGH                   (0x1000U) /* Outputs high level */
/* APn13 sets the output level of pin Pn_m (APn13) */
#define PORT_APn13_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn13_OUTPUT_HIGH                   (0x2000U) /* Outputs high level */
/* APn14 sets the output level of pin Pn_m (APn14) */
#define PORT_APn14_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn14_OUTPUT_HIGH                   (0x4000U) /* Outputs high level */
/* APn15 sets the output level of pin Pn_m (APn15) */
#define PORT_APn15_OUTPUT_LOW                    (0x0000U) /* Outputs low level */
#define PORT_APn15_OUTPUT_HIGH                   (0x8000U) /* Outputs high level */

/*
    JTAG Port Register (JPn)
*/
/* Pn0 sets the output level of pin Pn_m (JPn0) */
#define PORT_JPn0_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn0_OUTPUT_HIGH                    (0x01U) /* Outputs high level */
/* Pn1 sets the output level of pin Pn_m (JPn1) */
#define PORT_JPn1_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn1_OUTPUT_HIGH                    (0x02U) /* Outputs high level */
/* JPn2 sets the output level of pin Pn_m (JPn2) */
#define PORT_JPn2_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn2_OUTPUT_HIGH                    (0x04U) /* Outputs high level */
/* JPn3 sets the output level of pin Pn_m (JPn3) */
#define PORT_JPn3_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn3_OUTPUT_HIGH                    (0x08U) /* Outputs high level */
/* JPn4 sets the output level of pin Pn_m (JPn4) */
#define PORT_JPn4_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn4_OUTPUT_HIGH                    (0x10U) /* Outputs high level */
/* JPn5 sets the output level of pin Pn_m (JPn5) */
#define PORT_JPn5_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn5_OUTPUT_HIGH                    (0x20U) /* Outputs high level */
/* JPn6 sets the output level of pin Pn_m (JPn6) */
#define PORT_JPn6_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn6_OUTPUT_HIGH                    (0x40U) /* Outputs high level */
/* JPn7 sets the output level of pin Pn_m (JPn7) */
#define PORT_JPn7_OUTPUT_LOW                     (0x00U) /* Outputs low level */
#define PORT_JPn7_OUTPUT_HIGH                    (0x80U) /* Outputs high level */

/*
    Pull-up Option Register (PUn)
*/
/* PUn0 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn0) */
#define PORT_PUn0_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn0_PULLUP_ON                      (0x0001U) /* An internal pull-up resistor connected */
/* PUn1 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn1) */
#define PORT_PUn1_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn1_PULLUP_ON                      (0x0002U) /* An internal pull-up resistor connected */
/* PUn2 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn2) */
#define PORT_PUn2_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn2_PULLUP_ON                      (0x0004U) /* An internal pull-up resistor connected */
/* PUn3 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn3) */
#define PORT_PUn3_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn3_PULLUP_ON                      (0x0008U) /* An internal pull-up resistor connected */
/* PUn4 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn4) */
#define PORT_PUn4_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn4_PULLUP_ON                      (0x0010U) /* An internal pull-up resistor connected */
/* PUn5 specifies whether an internal pull-up resistor is connected to the corresponding pin (PUn5) */
#define PORT_PUn5_PULLUP_OFF                     (0x0000U) /* No internal pull-up resistor connected */
#define PORT_PUn5_PULLUP_ON                      (0x0020U) /* An internal pull-up resistor connected */
/* PUn6 pin on-chip pull-up resistor selection (PUn6) */
#define PORT_PUn6_PULLUP_OFF                     (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn6_PULLUP_ON                      (0x0040U) /* pull-up resistor connected */
/* PUn7 pin on-chip pull-up resistor selection (PUn7) */
#define PORT_PUn7_PULLUP_OFF                     (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn7_PULLUP_ON                      (0x0080U) /* pull-up resistor connected */
/* PUn8 pin on-chip pull-up resistor selection (PUn8) */
#define PORT_PUn8_PULLUP_OFF                     (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn8_PULLUP_ON                      (0x0100U) /* pull-up resistor connected */
/* PUn9 pin on-chip pull-up resistor selection (PUn9) */
#define PORT_PUn9_PULLUP_OFF                     (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn9_PULLUP_ON                      (0x0200U) /* pull-up resistor connected */
/* PUn10 pin on-chip pull-up resistor selection (PUn10) */
#define PORT_PUn10_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn10_PULLUP_ON                     (0x0400U) /* pull-up resistor connected */
/* PUn11 pin on-chip pull-up resistor selection (PUn11) */
#define PORT_PUn11_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn11_PULLUP_ON                     (0x0800U) /* pull-up resistor connected */
/* PUn12 pin on-chip pull-up resistor selection (PUn12) */
#define PORT_PUn12_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn12_PULLUP_ON                     (0x1000U) /* pull-up resistor connected */
/* PUn13 pin on-chip pull-up resistor selection (PUn13) */
#define PORT_PUn13_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn13_PULLUP_ON                     (0x2000U) /* pull-up resistor connected */
/* PUn14 pin on-chip pull-up resistor selection (PUn14) */
#define PORT_PUn14_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn14_PULLUP_ON                     (0x4000U) /* pull-up resistor connected */
/* PUn15 pin on-chip pull-up resistor selection (PUn15) */
#define PORT_PUn15_PULLUP_OFF                    (0x0000U) /* pull-up resistor not connected */
#define PORT_PUn15_PULLUP_ON                     (0x8000U) /* pull-up resistor connected */

/*
    Pull-up Option Register (JPUn)
*/
/* JPUn0 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn0) */
#define PORT_JPUn0_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn0_PULLUP_ON                     (0x0001U) /* An internal pull-up resistor connected */
/* JPUn1 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn1) */
#define PORT_JPUn1_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn1_PULLUP_ON                     (0x0002U) /* An internal pull-up resistor connected */
/* JPUn2 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn2) */
#define PORT_JPUn2_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn2_PULLUP_ON                     (0x0004U) /* An internal pull-up resistor connected */
/* JPUn3 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn3) */
#define PORT_JPUn3_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn3_PULLUP_ON                     (0x0008U) /* An internal pull-up resistor connected */
/* JPUn4 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn4) */
#define PORT_JPUn4_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn4_PULLUP_ON                     (0x0010U) /* An internal pull-up resistor connected */
/* JPUn5 specifies whether an internal pull-up resistor is connected to the corresponding pin (JPUn5) */
#define PORT_JPUn5_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn5_PULLUP_ON                     (0x0020U) /* An internal pull-up resistor connected */
/* JPUn6 pin on-chip pull-up resistor selection (JPUn6) */
#define PORT_JPUn6_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn6_PULLUP_ON                     (0x0040U) /* An internal pull-up resistor connected */
/* JPUn7 pin on-chip pull-up resistor selection (JPUn7) */
#define PORT_JPUn7_PULLUP_OFF                    (0x0000U) /* No internal pull-up resistor connected */
#define PORT_JPUn7_PULLUP_ON                     (0x0080U) /* An internal pull-up resistor connected */

/*
    Pull-down Option Register (PDn)
*/
/* PDn0 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn0) */
#define PORT_PDn0_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn0_PULLDOWN_ON                    (0x0001U) /* An internal pull-down resistor connected */
/* PDn1 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn1) */
#define PORT_PDn1_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn1_PULLDOWN_ON                    (0x0002U) /* An internal pull-down resistor connected */
/* PDn2 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn2) */
#define PORT_PDn2_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn2_PULLDOWN_ON                    (0x0004U) /* An internal pull-down resistor connected */
/* PDn3 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn3) */
#define PORT_PDn3_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn3_PULLDOWN_ON                    (0x0008U) /* An internal pull-down resistor connected */
/* PDn4 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn4) */
#define PORT_PDn4_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn4_PULLDOWN_ON                    (0x0010U) /* An internal pull-down resistor connected */
/* PDn5 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn5) */
#define PORT_PDn5_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn5_PULLDOWN_ON                    (0x0020U) /* An internal pull-down resistor connected */
/* PDn6 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn6) */
#define PORT_PDn6_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn6_PULLDOWN_ON                    (0x0040U) /* An internal pull-down resistor connected */
/* PDn7 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn7) */
#define PORT_PDn7_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn7_PULLDOWN_ON                    (0x0080U) /* An internal pull-down resistor connected */
/* PDn8 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn8) */
#define PORT_PDn8_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn8_PULLDOWN_ON                    (0x0100U) /* An internal pull-down resistor connected */
/* PDn9 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn9) */
#define PORT_PDn9_PULLDOWN_OFF                   (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn9_PULLDOWN_ON                    (0x0200U) /* An internal pull-down resistor connected */
/* PDn10 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn10) */
#define PORT_PDn10_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn10_PULLDOWN_ON                   (0x0400U) /* An internal pull-down resistor connected */
/* PDn11 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn11) */
#define PORT_PDn11_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn11_PULLDOWN_ON                   (0x0800U) /* An internal pull-down resistor connected */
/* PDn12 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn12) */
#define PORT_PDn12_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn12_PULLDOWN_ON                   (0x1000U) /* An internal pull-down resistor connected */
/* PDn13 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn13) */
#define PORT_PDn13_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn13_PULLDOWN_ON                   (0x2000U) /* An internal pull-down resistor connected */
/* PDn14 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn14) */
#define PORT_PDn14_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn14_PULLDOWN_ON                   (0x4000U) /* An internal pull-down resistor connected */
/* PDn15 specifies whether to connect an internal pull-down resistor to the corresponding pin (PDn15) */
#define PORT_PDn15_PULLDOWN_OFF                  (0x0000U) /* No internal pull-down resistor connected */
#define PORT_PDn15_PULLDOWN_ON                   (0x8000U) /* An internal pull-down resistor connected */

/*
    Pull-down Option Register (JPDn)
*/
/* JPDn0 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn0) */
#define PORT_JPDn0_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn0_PULLDOWN_ON                   (0x01U) /* An internal pull-down resistor connected */
/* JPDn1 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn1) */
#define PORT_JPDn1_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn1_PULLDOWN_ON                   (0x02U) /* An internal pull-down resistor connected */
/* JPDn2 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn2) */
#define PORT_JPDn2_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn2_PULLDOWN_ON                   (0x04U) /* An internal pull-down resistor connected */
/* JPDn3 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn3) */
#define PORT_JPDn3_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn3_PULLDOWN_ON                   (0x08U) /* An internal pull-down resistor connected */
/* JPDn4 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn4) */
#define PORT_JPDn4_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn4_PULLDOWN_ON                   (0x10U) /* An internal pull-down resistor connected */
/* JPDn5 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn5) */
#define PORT_JPDn5_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn5_PULLDOWN_ON                   (0x20U) /* An internal pull-down resistor connected */
/* JPDn6 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn6) */
#define PORT_JPDn6_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn6_PULLDOWN_ON                   (0x40U) /* An internal pull-down resistor connected */
/* JPDn7 specifies whether to connect an internal pull-down resistor to the corresponding pin (JPDn7) */
#define PORT_JPDn7_PULLDOWN_OFF                  (0x00U) /* No internal pull-down resistor connected */
#define PORT_JPDn7_PULLDOWN_ON                   (0x80U) /* An internal pull-down resistor connected */

/*
    Port Drive Strength Control Register (PDSCn)
*/
/* PDSCn0 specifies the port drive strength of the output buffer of the port pin (PDSCn0) */
#define PORT_PDSCn0_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn0_FAST_MODE_SELECT             (0x00000001UL) /* High drive strength */
/* PDSCn1 specifies the port drive strength of the output buffer of the port pin (PDSCn1) */
#define PORT_PDSCn1_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn1_FAST_MODE_SELECT             (0x00000002UL) /* High drive strength */
/* PDSCn2 specifies the port drive strength of the output buffer of the port pin (PDSCn2) */
#define PORT_PDSCn2_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn2_FAST_MODE_SELECT             (0x00000004UL) /* High drive strength */
/* PDSCn3 specifies the port drive strength of the output buffer of the port pin (PDSCn3) */
#define PORT_PDSCn3_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn3_FAST_MODE_SELECT             (0x00000008UL) /* High drive strength */
/* PDSCn4 specifies the port drive strength of the output buffer of the port pin (PDSCn4) */
#define PORT_PDSCn4_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn4_FAST_MODE_SELECT             (0x00000010UL) /* High drive strength */
/* PDSCn5 specifies the port drive strength of the output buffer of the port pin (PDSCn5) */
#define PORT_PDSCn5_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn5_FAST_MODE_SELECT             (0x00000020UL) /* High drive strength */
/* PDSCn6 specifies the port drive strength of the output buffer of the port pin (PDSCn6) */
#define PORT_PDSCn6_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn6_FAST_MODE_SELECT             (0x00000040UL) /* High drive strength */
/* PDSCn7 specifies the port drive strength of the output buffer of the port pin (PDSCn7) */
#define PORT_PDSCn7_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn7_FAST_MODE_SELECT             (0x00000080UL) /* High drive strength */
/* PDSCn8 specifies the port drive strength of the output buffer of the port pin (PDSCn8) */
#define PORT_PDSCn8_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn8_FAST_MODE_SELECT             (0x00000100UL) /* High drive strength */
/* PDSCn9 specifies the port drive strength of the output buffer of the port pin (PDSCn9) */
#define PORT_PDSCn9_SLOW_MODE_SELECT             (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn9_FAST_MODE_SELECT             (0x00000200UL) /* High drive strength */
/* PDSCn10 specifies the port drive strength of the output buffer of the port pin (PDSCn10) */
#define PORT_PDSCn10_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn10_FAST_MODE_SELECT            (0x00000400UL) /* High drive strength */
/* PDSCn11 specifies the port drive strength of the output buffer of the port pin (PDSCn11) */
#define PORT_PDSCn11_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn11_FAST_MODE_SELECT            (0x00000800UL) /* High drive strength */
/* PDSCn12 specifies the port drive strength of the output buffer of the port pin (PDSCn12) */
#define PORT_PDSCn12_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn12_FAST_MODE_SELECT            (0x00001000UL) /* High drive strength */
/* PDSCn13 specifies the port drive strength of the output buffer of the port pin (PDSCn13) */
#define PORT_PDSCn13_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn13_FAST_MODE_SELECT            (0x00002000UL) /* High drive strength */
/* PDSCn14 specifies the port drive strength of the output buffer of the port pin (PDSCn14) */
#define PORT_PDSCn14_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn14_FAST_MODE_SELECT            (0x00004000UL) /* High drive strength */
/* PDSCn15 specifies the port drive strength of the output buffer of the port pin (PDSCn15) */
#define PORT_PDSCn15_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_PDSCn15_FAST_MODE_SELECT            (0x00008000UL) /* High drive strength */

/*
    JTAG Port Drive Strength Control Register (JPDSCn)
*/
/* JPDSCn0 specifies the port drive strength of the output buffer of the port pin (JPDSCn0) */
#define PORT_JPDSCn0_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn0_FAST_MODE_SELECT            (0x00000001UL) /* High drive strength */
/* JPDSCn1 specifies the port drive strength of the output buffer of the port pin (JPDSCn1) */
#define PORT_JPDSCn1_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn1_FAST_MODE_SELECT            (0x00000002UL) /* High drive strength */
/* JPDSCn2 specifies the port drive strength of the output buffer of the port pin (JPDSCn2) */
#define PORT_JPDSCn2_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn2_FAST_MODE_SELECT            (0x00000004UL) /* High drive strength */
/* JPDSCn3 specifies the port drive strength of the output buffer of the port pin (JPDSCn3) */
#define PORT_JPDSCn3_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn3_FAST_MODE_SELECT            (0x00000008UL) /* High drive strength */
/* JPDSCn4 specifies the port drive strength of the output buffer of the port pin (JPDSCn4) */
#define PORT_JPDSCn4_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn4_FAST_MODE_SELECT            (0x00000010UL) /* High drive strength */
/* JPDSCn5 specifies the port drive strength of the output buffer of the port pin (JPDSCn5) */
#define PORT_JPDSCn5_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn5_FAST_MODE_SELECT            (0x00000020UL) /* High drive strength */
/* JPDSCn6 specifies the port drive strength of the output buffer of the port pin (JPDSCn6) */
#define PORT_JPDSCn6_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn6_FAST_MODE_SELECT            (0x00000040UL) /* High drive strength */
/* JPDSCn7 specifies the port drive strength of the output buffer of the port pin (JPDSCn7) */
#define PORT_JPDSCn7_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn7_FAST_MODE_SELECT            (0x00000080UL) /* High drive strength */
/* JPDSCn8 specifies the port drive strength of the output buffer of the port pin (JPDSCn8) */
#define PORT_JPDSCn8_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn8_FAST_MODE_SELECT            (0x00000100UL) /* High drive strength */
/* JPDSCn9 specifies the port drive strength of the output buffer of the port pin (JPDSCn9) */
#define PORT_JPDSCn9_SLOW_MODE_SELECT            (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn9_FAST_MODE_SELECT            (0x00000200UL) /* High drive strength */
/* JPDSCn10 specifies the port drive strength of the output buffer of the port pin (JPDSCn10) */
#define PORT_JPDSCn10_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn10_FAST_MODE_SELECT           (0x00000400UL) /* High drive strength */
/* JPDSCn11 specifies the port drive strength of the output buffer of the port pin (JPDSCn11) */
#define PORT_JPDSCn11_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn11_FAST_MODE_SELECT           (0x00000800UL) /* High drive strength */
/* JPDSCn12 specifies the port drive strength of the output buffer of the port pin (JPDSCn12) */
#define PORT_JPDSCn12_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn12_FAST_MODE_SELECT           (0x00001000UL) /* High drive strength */
/* JPDSCn13 specifies the port drive strength of the output buffer of the port pin (JPDSCn13) */
#define PORT_JPDSCn13_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn13_FAST_MODE_SELECT           (0x00002000UL) /* High drive strength */
/* JPDSCn14 specifies the port drive strength of the output buffer of the port pin (JPDSCn14) */
#define PORT_JPDSCn14_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn14_FAST_MODE_SELECT           (0x00004000UL) /* High drive strength */
/* JPDSCn15 specifies the port drive strength of the output buffer of the port pin (JPDSCn15) */
#define PORT_JPDSCn15_SLOW_MODE_SELECT           (0x00000000UL) /* Low drive strength */
#define PORT_JPDSCn15_FAST_MODE_SELECT           (0x00008000UL) /* High drive strength */

/*
    Port Open Drain Control Register (PODCn)
*/
/* PODCn0 specifies the output buffer function (PODCn0) */
#define PORT_PODCn0_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn0_OPEN_DRAIN                   (0x00000001UL) /* Open-drain */
/* PODCn1 specifies the output buffer function (PODCn1) */
#define PORT_PODCn1_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn1_OPEN_DRAIN                   (0x00000002UL) /* Open-drain */
/* PODCn2 specifies the output buffer function (PODCn2) */
#define PORT_PODCn2_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn2_OPEN_DRAIN                   (0x00000004UL) /* Open-drain */
/* PODCn3 specifies the output buffer function (PODCn3) */
#define PORT_PODCn3_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn3_OPEN_DRAIN                   (0x00000008UL) /* Open-drain */
/* PODCn4 specifies the output buffer function (PODCn4) */
#define PORT_PODCn4_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn4_OPEN_DRAIN                   (0x00000010UL) /* Open-drain */
/* PODCn5 specifies the output buffer function (PODCn5) */
#define PORT_PODCn5_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn5_OPEN_DRAIN                   (0x00000020UL) /* Open-drain */
/* PODCn6 specifies the output buffer function (PODCn6) */
#define PORT_PODCn6_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn6_OPEN_DRAIN                   (0x00000040UL) /* Open-drain */
/* PODCn7 specifies the output buffer function (PODCn7) */
#define PORT_PODCn7_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn7_OPEN_DRAIN                   (0x00000080UL) /* Open-drain */
/* PODCn8 specifies the output buffer function (PODCn8) */
#define PORT_PODCn8_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn8_OPEN_DRAIN                   (0x00000100UL) /* Open-drain */
/* PODCn9 specifies the output buffer function (PODCn9) */
#define PORT_PODCn9_PUSH_PULL                    (0x00000000UL) /* Push-pull */
#define PORT_PODCn9_OPEN_DRAIN                   (0x00000200UL) /* Open-drain */
/* PODCn10 specifies the output buffer function (PODCn10) */
#define PORT_PODCn10_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn10_OPEN_DRAIN                  (0x00000400UL) /* Open-drain */
/* PODCn11 specifies the output buffer function (PODCn11) */
#define PORT_PODCn11_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn11_OPEN_DRAIN                  (0x00000800UL) /* Open-drain */
/* PODCn12 specifies the output buffer function (PODCn12) */
#define PORT_PODCn12_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn12_OPEN_DRAIN                  (0x00001000UL) /* Open-drain */
/* PODCn13 specifies the output buffer function (PODCn13) */
#define PORT_PODCn13_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn13_OPEN_DRAIN                  (0x00002000UL) /* Open-drain */
/* PODCn14 specifies the output buffer function (PODCn14) */
#define PORT_PODCn14_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn14_OPEN_DRAIN                  (0x00004000UL) /* Open-drain */
/* PODCn15 specifies the output buffer function (PODCn15) */
#define PORT_PODCn15_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_PODCn15_OPEN_DRAIN                  (0x00008000UL) /* Open-drain */

/*
    JTAG Port Open Drain Control Register (JPODCn)
*/
/* JPODCn0 specifies the output buffer function (JPODCn0) */
#define PORT_JPODCn0_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn0_OPEN_DRAIN                  (0x00000001UL) /* Open-drain */
/* JPODCn1 specifies the output buffer function (JPODCn1) */
#define PORT_JPODCn1_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn1_OPEN_DRAIN                  (0x00000002UL) /* Open-drain */
/* JPODCn2 specifies the output buffer function (JPODCn2) */
#define PORT_JPODCn2_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn2_OPEN_DRAIN                  (0x00000004UL) /* Open-drain */
/* JPODCn3 specifies the output buffer function (JPODCn3) */
#define PORT_JPODCn3_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn3_OPEN_DRAIN                  (0x00000008UL) /* Open-drain */
/* JPODCn4 specifies the output buffer function (JPODCn4) */
#define PORT_JPODCn4_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn4_OPEN_DRAIN                  (0x00000010UL) /* Open-drain */
/* JPODCn5 specifies the output buffer function (JPODCn5) */
#define PORT_JPODCn5_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn5_OPEN_DRAIN                  (0x00000020UL) /* Open-drain */
/* JPODCn6 specifies the output buffer function (JPODCn6) */
#define PORT_JPODCn6_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn6_OPEN_DRAIN                  (0x00000040UL) /* Open-drain */
/* JPODCn7 specifies the output buffer function (JPODCn7) */
#define PORT_JPODCn7_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn7_OPEN_DRAIN                  (0x00000080UL) /* Open-drain */
/* JPODCn8 specifies the output buffer function (JPODCn8) */
#define PORT_JPODCn8_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn8_OPEN_DRAIN                  (0x00000100UL) /* Open-drain */
/* JPODCn9 specifies the output buffer function (JPODCn9) */
#define PORT_JPODCn9_PUSH_PULL                   (0x00000000UL) /* Push-pull */
#define PORT_JPODCn9_OPEN_DRAIN                  (0x00000200UL) /* Open-drain */
/* JPODCn10 specifies the output buffer function (JPODCn10) */
#define PORT_JPODCn10_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn10_OPEN_DRAIN                 (0x00000400UL) /* Open-drain */
/* JPODCn11 specifies the output buffer function (JPODCn11) */
#define PORT_JPODCn11_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn11_OPEN_DRAIN                 (0x00000800UL) /* Open-drain */
/* JPODCn12 specifies the output buffer function (JPODCn12) */
#define PORT_JPODCn12_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn12_OPEN_DRAIN                 (0x00001000UL) /* Open-drain */
/* JPODCn13 specifies the output buffer function (JPODCn13) */
#define PORT_JPODCn13_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn13_OPEN_DRAIN                 (0x00002000UL) /* Open-drain */
/* JPODCn14 specifies the output buffer function (JPODCn14) */
#define PORT_JPODCn14_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn14_OPEN_DRAIN                 (0x00004000UL) /* Open-drain */
/* JPODCn15 specifies the output buffer function (JPODCn15) */
#define PORT_JPODCn15_PUSH_PULL                  (0x00000000UL) /* Push-pull */
#define PORT_JPODCn15_OPEN_DRAIN                 (0x00008000UL) /* Open-drain */

/*
    Port Input Buffer Selection Register (PISn)
*/
/* PISn0 specifies the input buffer characteristic (PISn0) */
#define PORT_PISn0_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn0_TYPE_SHMT4                    (0x0001U) /* Type 2 (SHMT4) */
/* PISn1 specifies the input buffer characteristic (PISn1) */
#define PORT_PISn1_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn1_TYPE_SHMT4                    (0x0002U) /* Type 2 (SHMT4) */
/* PISn2 specifies the input buffer characteristic (PISn2) */
#define PORT_PISn2_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn2_TYPE_SHMT4                    (0x0004U) /* Type 2 (SHMT4) */
/* PISn3 specifies the input buffer characteristic (PISn3) */
#define PORT_PISn3_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn3_TYPE_SHMT4                    (0x0008U) /* Type 2 (SHMT4) */
/* PISn4 specifies the input buffer characteristic (PISn4) */
#define PORT_PISn4_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn4_TYPE_SHMT4                    (0x0010U) /* Type 2 (SHMT4) */
/* PISn5 specifies the input buffer characteristic (PISn5) */
#define PORT_PISn5_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn5_TYPE_SHMT4                    (0x0020U) /* Type 2 (SHMT4) */
/* PISn6 specifies the input buffer characteristic (PISn6) */
#define PORT_PISn6_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn6_TYPE_SHMT4                    (0x0040U) /* Type 2 (SHMT4) */
/* PISn7 specifies the input buffer characteristic (PISn7) */
#define PORT_PISn7_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn7_TYPE_SHMT4                    (0x0080U) /* Type 2 (SHMT4) */
/* PISn8 specifies the input buffer characteristic (PISn8) */
#define PORT_PISn8_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn8_TYPE_SHMT4                    (0x0100U) /* Type 2 (SHMT4) */
/* PISn9 specifies the input buffer characteristic (PISn9) */
#define PORT_PISn9_TYPE_SHMT1                    (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn9_TYPE_SHMT4                    (0x0200U) /* Type 2 (SHMT4) */
/* PISn10 specifies the input buffer characteristic (PISn10) */
#define PORT_PISn10_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn10_TYPE_SHMT4                   (0x0400U) /* Type 2 (SHMT4) */
/* PISn11 specifies the input buffer characteristic (PISn11) */
#define PORT_PISn11_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn11_TYPE_SHMT4                   (0x0800U) /* Type 2 (SHMT4) */
/* PISn12 specifies the input buffer characteristic (PISn12) */
#define PORT_PISn12_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn12_TYPE_SHMT4                   (0x1000U) /* Type 2 (SHMT4) */
/* PISn13 specifies the input buffer characteristic (PISn13) */
#define PORT_PISn13_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn13_TYPE_SHMT4                   (0x2000U) /* Type 2 (SHMT4) */
/* PISn14 specifies the input buffer characteristic (PISn14) */
#define PORT_PISn14_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn14_TYPE_SHMT4                   (0x4000U) /* Type 2 (SHMT4) */
/* PISn15 specifies the input buffer characteristic (PISn15) */
#define PORT_PISn15_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_PISn15_TYPE_SHMT4                   (0x8000U) /* Type 2 (SHMT4) */

/*
    JTAG Port Input Buffer Selection Register (JPISn)
*/
/* JPISn0 specifies the input buffer characteristic (JPISn0) */
#define PORT_JPISn0_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn0_TYPE_SHMT4                   (0x0001U) /* Type 2 (SHMT4) */
/* JPISn1 specifies the input buffer characteristic (JPISn1) */
#define PORT_JPISn1_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn1_TYPE_SHMT4                   (0x0002U) /* Type 2 (SHMT4) */
/* JPISn2 specifies the input buffer characteristic (JPISn2) */
#define PORT_JPISn2_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn2_TYPE_SHMT4                   (0x0004U) /* Type 2 (SHMT4) */
/* JPISn3 specifies the input buffer characteristic (JPISn3) */
#define PORT_JPISn3_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn3_TYPE_SHMT4                   (0x0008U) /* Type 2 (SHMT4) */
/* JPISn4 specifies the input buffer characteristic (JPISn4) */
#define PORT_JPISn4_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn4_TYPE_SHMT4                   (0x0010U) /* Type 2 (SHMT4) */
/* JPISn5 specifies the input buffer characteristic (JPISn5) */
#define PORT_JPISn5_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn5_TYPE_SHMT4                   (0x0020U) /* Type 2 (SHMT4) */
/* JPISn6 specifies the input buffer characteristic (JPISn6) */
#define PORT_JPISn6_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn6_TYPE_SHMT4                   (0x0040U) /* Type 2 (SHMT4) */
/* JPISn7 specifies the input buffer characteristic (JPISn7) */
#define PORT_JPISn7_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn7_TYPE_SHMT4                   (0x0080U) /* Type 2 (SHMT4) */
/* JPISn8 specifies the input buffer characteristic (JPISn8) */
#define PORT_JPISn8_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn8_TYPE_SHMT4                   (0x0100U) /* Type 2 (SHMT4) */
/* JPISn9 specifies the input buffer characteristic (JPISn9) */
#define PORT_JPISn9_TYPE_SHMT1                   (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn9_TYPE_SHMT4                   (0x0200U) /* Type 2 (SHMT4) */
/* JPISn10 specifies the input buffer characteristic (JPISn10) */
#define PORT_JPISn10_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn10_TYPE_SHMT4                  (0x0400U) /* Type 2 (SHMT4) */
/* JPISn11 specifies the input buffer characteristic (JPISn11) */
#define PORT_JPISn11_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn11_TYPE_SHMT4                  (0x0800U) /* Type 2 (SHMT4) */
/* JPISn12 specifies the input buffer characteristic (JPISn12) */
#define PORT_JPISn12_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn12_TYPE_SHMT4                  (0x1000U) /* Type 2 (SHMT4) */
/* JPISn13 specifies the input buffer characteristic (JPISn13) */
#define PORT_JPISn13_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn13_TYPE_SHMT4                  (0x2000U) /* Type 2 (SHMT4) */
/* JPISn14 specifies the input buffer characteristic (JPISn14) */
#define PORT_JPISn14_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn14_TYPE_SHMT4                  (0x4000U) /* Type 2 (SHMT4) */
/* JPISn15 specifies the input buffer characteristic (JPISn15) */
#define PORT_JPISn15_TYPE_SHMT1                  (0x0000U) /* Type 1 (SHMT1) */
#define PORT_JPISn15_TYPE_SHMT4                  (0x8000U) /* Type 2 (SHMT4) */

/*
    JTAG Port Input Buffer Selection Advanced Register (JPISAn)
*/
/* JPISAn0 specifies the input buffer characteristic (JPISAn0) */
#define PORT_JPISAn0_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn0_TYPE_TTL                    (0x01U) /* Type 5 (TTL) */
/* JPISAn1 specifies the input buffer characteristic (JPISAn1) */
#define PORT_JPISAn1_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn1_TYPE_TTL                    (0x02U) /* Type 5 (TTL) */
/* JPISAn2 specifies the input buffer characteristic (JPISAn2) */
#define PORT_JPISAn2_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn2_TYPE_TTL                    (0x04U) /* Type 5 (TTL) */
/* JPISAn3 specifies the input buffer characteristic (JPISAn3) */
#define PORT_JPISAn3_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn3_TYPE_TTL                    (0x08U) /* Type 5 (TTL) */
/* JPISAn4 specifies the input buffer characteristic (JPISAn4) */
#define PORT_JPISAn4_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn4_TYPE_TTL                    (0x10U) /* Type 5 (TTL) */
/* JPISAn5 specifies the input buffer characteristic (JPISAn5) */
#define PORT_JPISAn5_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn5_TYPE_TTL                    (0x20U) /* Type 5 (TTL) */
/* JPISAn6 specifies the input buffer characteristic (JPISAn6) */
#define PORT_JPISAn6_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn6_TYPE_TTL                    (0x40U) /* Type 5 (TTL) */
/* JPISAn7 specifies the input buffer characteristic (JPISAn7) */
#define PORT_JPISAn7_TYPE_SHMT1_OR_SHMT4         (0x00U) /* Type 2 (SHMT4) */
#define PORT_JPISAn7_TYPE_TTL                    (0x80U) /* Type 5 (TTL) */

/*
    Port Input Buffer Selection Advanced Register (PISAn)
*/
/* PISAn0 specifies the input buffer characteristic (PISAn0) */
#define PORT_PISAn0_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn0_TYPE_TTL                     (0x0001U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn1) */
#define PORT_PISAn1_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn1_TYPE_TTL                     (0x0002U) /* Type 5 (TTL) */
/* PISAn2 specifies the input buffer characteristic (PISAn2) */
#define PORT_PISAn2_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn2_TYPE_TTL                     (0x0004U) /* Type 5 (TTL) */
/* PISAn3 specifies the input buffer characteristic (PISAn3) */
#define PORT_PISAn3_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn3_TYPE_TTL                     (0x0008U) /* Type 5 (TTL) */
/* PISAn4 specifies the input buffer characteristic (PISAn4) */
#define PORT_PISAn4_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn4_TYPE_TTL                     (0x0010U) /* Type 5 (TTL) */
/* PISAn5 specifies the input buffer characteristic (PISAn5) */
#define PORT_PISAn5_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn5_TYPE_TTL                     (0x0020U) /* Type 5 (TTL) */
/* PISAn6 specifies the input buffer characteristic (PISAn6) */
#define PORT_PISAn6_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn6_TYPE_TTL                     (0x0040U) /* Type 5 (TTL) */
/* PISAn7 specifies the input buffer characteristic (PISAn7) */
#define PORT_PISAn7_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn7_TYPE_TTL                     (0x0080U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn8) */
#define PORT_PISAn8_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn8_TYPE_TTL                     (0x0100U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn9) */
#define PORT_PISAn9_TYPE_SHMT1_OR_SHMT4          (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn9_TYPE_TTL                     (0x0200U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn10) */
#define PORT_PISAn10_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn10_TYPE_TTL                    (0x0400U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn11) */
#define PORT_PISAn11_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn11_TYPE_TTL                    (0x0800U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn12) */
#define PORT_PISAn12_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn12_TYPE_TTL                    (0x1000U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn13) */
#define PORT_PISAn13_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn13_TYPE_TTL                    (0x2000U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn14) */
#define PORT_PISAn14_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn14_TYPE_TTL                    (0x4000U) /* Type 5 (TTL) */
/* PISAn1 specifies the input buffer characteristic (PISAn15) */
#define PORT_PISAn15_TYPE_SHMT1_OR_SHMT4         (0x0000U) /* Type 2 (SHMT4) */
#define PORT_PISAn15_TYPE_TTL                    (0x8000U) /* Type 5 (TTL) */

#define PORT_PM_INIT                             (0xFFFFU) /* Port mode init */
#define PORT_JPM_INIT                            (0xFFU)   /* JTAG Port mode init */
#define PORT_APM_INIT                            (0xFFFFU) /* Analog Port mode init */
#define PORT_PMC_INIT                            (0x0000U) /* PMC init */
#define PORT_JPMC_INIT                           (0x00U)   /* JTAG PMC init */
#define PORT_PBDC_INIT                           (0x0000U) /* PBDC init */
#define PORT_JPBDC_INIT                          (0x00U)   /* JTAG PBDC init */
#define PORT_APBDC_INIT                          (0x0000U) /* Analog PBDC init */
#define PORT_PIPC_INIT                           (0x0000U) /* PIPC init */
#define PORT_PIBC_INIT                           (0x0000U) /* PIBC init */
#define PORT_JPIBC_INIT                          (0x00U)   /* JTAG PIBC init */
#define PORT_APIBC_INIT                          (0x0000U) /* Analog PIBC init */
#define PORT_IPIBC_INIT                          (0x0000U) /* Input PIBC init */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define PORT_PM1_DEFAULT_VALUE                   (0x00C0U) /* PM1 default value */
#define PORT_PM2_DEFAULT_VALUE                   (0xFF80U) /* PM2 default value */
#define PORT_PM8_DEFAULT_VALUE                   (0xE000U) /* PM8 default value */
#define PORT_PM9_DEFAULT_VALUE                   (0xFFE0U) /* PM9 default value */
#define PORT_PM10_DEFAULT_VALUE                  (0x0000U) /* PM10 default value */
#define PORT_PM11_DEFAULT_VALUE                  (0x6000U) /* PM11 default value */
#define PORT_PM18_DEFAULT_VALUE                  (0xFF00U) /* PM18 default value */
#define PORT_PM20_DEFAULT_VALUE                  (0xFFC0U) /* PM20 default value */
#define PORT_PIS1_DEFAULT_VALUE                  (0x00C0U) /* PIS1 default value */
#define PORT_PIS2_DEFAULT_VALUE                  (0xFF80U) /* PIS2 default value */
#define PORT_PIS8_DEFAULT_VALUE                  (0xE000U) /* PIS8 default value */
#define PORT_PIS9_DEFAULT_VALUE                  (0xFFE0U) /* PIS9 default value */
#define PORT_PIS10_DEFAULT_VALUE                 (0x0000U) /* PIS10 default value */
#define PORT_PIS11_DEFAULT_VALUE                 (0x6000U) /* PIS11 default value */
#define PORT_PIS18_DEFAULT_VALUE                 (0xFF00U) /* PIS18 default value */
#define PORT_PIS20_DEFAULT_VALUE                 (0xFFC0U) /* PIS20 default value */

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/

#endif // MCU_PORT_CONFIG_H

/*--------------------------- End McuPortConfig.h -----------------------------*/
