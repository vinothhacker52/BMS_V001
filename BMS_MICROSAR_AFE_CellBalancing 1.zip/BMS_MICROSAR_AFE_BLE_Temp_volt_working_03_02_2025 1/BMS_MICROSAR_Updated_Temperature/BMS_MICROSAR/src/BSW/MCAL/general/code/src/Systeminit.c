/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                   
** File: Systeminit.c
**
** Description:
** This file implements system initializing function.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/


/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/

//#include "SystemCommonIncludes.h"
#include "SystemClock.h"
#include "McuPortConfig.h"
#include "McuPin.h"
#include "SystemGpio.h"
#include "SystemPwm.h"
#include "SystemAdc.h"
#include "SystemCan.h"
#include "SystemAfe.h"
#include "SystemOstim0.h"
#include "SystemClma.h"
#include "SystemDefaultConfig.h"
#include "McuUart0.h"
#include "McuTaud0Ch14.h"
#include "SystemBle.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
static void CreateClock(void);
static void CreatePort(void);
static void CreateTimers(void);
static void SystemCommonStart(void);
void SystemStart (void);
extern void Task1Ms(void);
// <Add any functions whose "scope" is limited to this module here>
/*-----------------------------------------------------------------------------
** Function: Systeminit()
**
** Description:
** This function initializes System
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/

void Systeminit(void)
{    
    uint8_t clockInitStatus;
	McuClmaId sysClmaId;
	clockInitStatus = SystemClockInit();//ecual clock
	SystemPwmConfig pPwmConfig;
	
	pPwmConfig.frequency = 1000.0f;
	pPwmConfig.PwmCh1.pwmOutputLevel = TAUJ_CH1_NEGATIVE;
	pPwmConfig.PwmCh1.dutyCycle = 50;
	
	McuPinInit();
	
	if(clockInitStatus == NORMAL_CLOCK_INIT_SUCCESS)
	{

	        SystemCommonConfig();
		McuCanInit();
		SystemPwmInit(&pPwmConfig);
		SystemOstimInit(&Task1Ms,1);
		SystemUartInit();
		SystemClmaInit(sysClmaId);
		SystemClmaControl(sysClmaId, CLMA_0);
		SystemAdc0Init();//AP0_14 & AP0_15 will be configured
		McuTaud0Ch14Init(); //100uS Timer
		SystemBleInit();
		SystemStart();
	}


}

void SystemStart (void){

        McuTaud0Ch14_Start(); 
        SystemOstimStart();
	SystemAdc0Start();
	SystemPwmStart();	
}

/*-----------------------------------------------------------------------------
** Function: CreateNormalClma()
**
** Description:
** This function initializes all the CLMA
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void CreateNormalClma(void)//in normal clock init call this API in main()
{
	SystemClmaInit(CLMA_0);
	SystemClmaInit(CLMA_1);
	SystemClmaInit(CLMA_3);
}/*-----------------------End SystemCsih0Create()----------------------------*/
/*-----------------------------------------------------------------------------
** Function: CreateReducedClma()
**
** Description:
** This function initializes all the CLMA except CLMA2 becuase CLMA2 should not
**  be enable in reduced mode
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void CreateReducedClma(void)//if pll not working call this API in main()
{
	SystemClmaInit(CLMA_0);
	SystemClmaInit(CLMA_1);
	SystemClmaInit(CLMA_3);
}/*-----------------------End SystemCsih0Create()----------------------------*/
/*-----------------------------------------------------------------------------
** Function: StartNormalClma()
**
** Description:
** This function enables all the CLMA
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void StartNormalClma(void)
{
	SystemClmaControl(CLMA_0, ENABLE_CLMA);
	SystemClmaControl(CLMA_1, ENABLE_CLMA);
	SystemClmaControl(CLMA_3, ENABLE_CLMA);
}/*-----------------------End SystemCsih0Create()----------------------------*/
/*-----------------------------------------------------------------------------
** Function: StartReducedClma()
**
** Description:
** This function Enables all the CLMA except CLMA2, becuase CLMA2 should not
**  be enable in reduced mode
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void StartReducedClma(void)
{
	SystemClmaControl(CLMA_0, ENABLE_CLMA);
	SystemClmaControl(CLMA_1, ENABLE_CLMA);
	SystemClmaControl(CLMA_3, ENABLE_CLMA);
}/*-----------------------End SystemCsih0Create()----------------------------*/


/*--------------------------- End Systeminit.c -----------------------------*/
