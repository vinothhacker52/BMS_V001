#include "retention.h"
//#pragma ghs startdata
#pragma ghs section bss =".rbss"

McuClockStatusRet clkStatusRet = MCU_CLOCK_INIT_DONE;

uint8_t ClmaRetryCount ;

uint8_t Clma0ResetCount ;
uint8_t Clma1ResetCount ;
//uint8_t Clma2ResetCount ;
uint8_t Clma3ResetCount ;

uint8_t Watchdog0ResetCount;
uint8_t Watchdog1ResetCount;
uint8_t Watchdog2ResetCount;

uint8_t MainOscErrorcount;
uint8_t HscOscErrorcount;
uint8_t PLLnErrorcount;
uint8_t NormalClockActivationFailureCount;
uint8_t ReducedClockActivationFailureCount;

_Bool safeStateFlag ; 
_Bool safeModeFlag ;

#pragma ghs section bss = default
//#pragma ghs enddata

