#ifndef MCU_RETENTION_H
#define MCU_RETENTION_H

#include "McuMacroDriver.h"
#include "McuTypedefs.h"	
//#pragma ghs startdata
#pragma ghs section bss =".rbss"
typedef enum MCU_RET_CLOCK_STATUS
{
    MCU_CLOCK_INIT_DONE = 0,
    MCU_MAIN_OSC_ERROR,
    MCU_HSC_OSC_ERROR,
    MCU_PLL0_ERROR,
    MCU_PLL1_ERROR,
    MCU_CPU_ERROR
    
}McuClockStatusRet;

extern uint8_t ClmaRetryCount;

extern uint8_t Clma0ResetCount;
extern uint8_t Clma1ResetCount;
//extern uint8_t Clma2ResetCount;
extern uint8_t Clma3ResetCount;

extern uint8_t Watchdog0ResetCount;
extern uint8_t Watchdog1ResetCount;
extern uint8_t Watchdog2ResetCount;

extern uint8_t MainOscErrorcount;
extern uint8_t HscOscErrorcount;
extern uint8_t PLLnErrorcount;
extern uint8_t NormalClockActivationFailureCount;
extern uint8_t ReducedClockActivationFailureCount;

extern _Bool safeStateFlag ;
extern _Bool safeModeFlag ;

extern McuClockStatusRet clkStatusRet;

#pragma ghs section bss = default
//#pragma ghs enddata
#endif //(RETENTION_H)
