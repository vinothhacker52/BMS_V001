#ifndef MCU_TYPEDEF_H
#define MCU_TYPEDEF_H
	typedef signed char           int8_t;
	typedef unsigned char         uint8_t;
	typedef signed short          int16_t;
	typedef unsigned short        uint16_t;
	typedef signed long           int32_t;
	typedef unsigned long         uint32_t;
	typedef signed long long      int64_t;
	typedef unsigned long long    uint64_t;
	typedef unsigned short        MD_STATUS;

	#define _NULL				0
	#define NULL_VOID_FUNC_PTR (VoidFuncPtr)_NULL
	
	#define TIMER_COUNT_OFFSET	1U
	
	typedef void (*VoidFuncPtr)(void);
#endif
