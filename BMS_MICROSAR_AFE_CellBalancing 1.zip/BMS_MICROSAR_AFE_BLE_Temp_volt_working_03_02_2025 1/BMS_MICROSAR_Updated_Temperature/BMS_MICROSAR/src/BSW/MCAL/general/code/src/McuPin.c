/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                   
** File: McuPin.c
**
** Description:
** This source file initializes the pins.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/* Files : McuPin.c & McuPin.h
 * 
 * V1.0 	:  07-Mar-2025  : Initial Version
 * V1.1 	:  21-Mar-2025  : No Changes.
 * V1.2 	:  10-Apr-2025  : No Changes.
 * V1.3		:  15-Apr-2025	: No Changes.
 * V1.4		:  22-Apr-2025	: No Changes.
 * V1.5		:  15-May-2025  : The following changes were made :
 *					1. Changed the name of the file from "Pin.c" to "McuPin.c".
 *					2. Changed the name of the function "R_Pins_Create" to "McuPinInit".
 * V1.6		: 03-Jun-2025	: No changes.
 * V1.7		: 10-Jun-2025	: No changes.
 * V1.8		: 18-Jun-2025	: No changes.
 */

/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "dr7f701690.dvf.h" 
#include "McuPin.h"
#include "McuMacroDriver.h" 
#include "McuPortConfig.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Function: McuPinInit()
**
** Description:
** This function initializes the pins.
**
** Arguments:
** None.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuPinInit(void)
{



#if 0

/* Set RLIN30RX(P0_3) pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT3;
    PORT.PBDC0 &= PORT_CLEAR_BIT3;
    PORT.PM0 |= PORT_SET_BIT3;
    PORT.PMC0 &= PORT_CLEAR_BIT3;
    PORT.PIPC0 &= PORT_CLEAR_BIT3;
    PORT.PFC0 &= PORT_CLEAR_BIT3;
    PORT.PFCE0 |= PORT_SET_BIT3;
    PORT.PFCAE0 |= PORT_SET_BIT3;
    PORT.PMC0 |= PORT_SET_BIT3;

    /* Set RLIN30TX(P0_2) pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT2;
    PORT.PBDC0 &= PORT_CLEAR_BIT2;
    PORT.PM0 |= PORT_SET_BIT2;
    PORT.PMC0 &= PORT_CLEAR_BIT2;
    PORT.PIPC0 &= PORT_CLEAR_BIT2;
    PORT.PFC0 |= PORT_SET_BIT2;
    PORT.PFCE0 &= PORT_CLEAR_BIT2;
    PORT.PFCAE0 &= PORT_CLEAR_BIT2;
    PORT.PMC0 |= PORT_SET_BIT2;
    PORT.PM0 &= PORT_CLEAR_BIT2;

    /* Set RLIN31RX(P0_4) pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT4;
    PORT.PBDC0 &= PORT_CLEAR_BIT4;
    PORT.PM0 |= PORT_SET_BIT4;
    PORT.PMC0 &= PORT_CLEAR_BIT4;
    PORT.PFC0 &= PORT_CLEAR_BIT4;
    PORT.PFCE0 |= PORT_SET_BIT4;
    PORT.PFCAE0 |= PORT_SET_BIT4;
    PORT.PMC0 |= PORT_SET_BIT4;

    /* Set RLIN31TX(P0_5) pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT5;
    PORT.PBDC0 &= PORT_CLEAR_BIT5;
    PORT.PM0 |= PORT_SET_BIT5;
    PORT.PMC0 &= PORT_CLEAR_BIT5;
    PORT.PIPC0 &= PORT_CLEAR_BIT5;
    PORT.PFC0 &= PORT_CLEAR_BIT5;
    PORT.PFCE0 &= PORT_CLEAR_BIT5;
    PORT.PFCAE0 &= PORT_CLEAR_BIT5;
    PORT.PMC0 |= PORT_SET_BIT5;
    PORT.PM0 &= PORT_CLEAR_BIT5;
    /* Synchronization processing */
#endif

    //g_cg_sync_read = PORT.PM0;

    __syncp();

 
   
   
}/*--------------------------- End McuPinInit () -----------------------*/

/*--------------------------- End McuOstm0.c -----------------------------*/

