/*-----------------------------------------------------------------------------
**                           
** File: McuTauj0Ch0.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of the McuTauj0Ch0 module.
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "McuMacroDriver.h"
#include "McuTaujPrivate.h"
#include "McuTauj0Ch0.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
// uint32_t clockTimeOut;
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
** Function: McuTauj0Ch0Init
**
** Description:
** Initializes timer Tauj0 channel 0
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuTauj0Ch0Init(void)
{
    volatile uint32_t g_cg_sync_read;
    /* Disable channel 0 counter operation */
    TAUJ0.TT |= TAUJ_CHANNEL0_COUNTER_STOP;
    /* Disable INTTAUJ0I0 operation and clear request */
    INTC2.ICTAUJ0I0.BIT.MKTAUJ0I0 = INT_PROCESSING_DISABLED;
    INTC2.ICTAUJ0I0.BIT.RFTAUJ0I0 = INT_REQUEST_NOT_OCCUR;
    /* Set INTTAUJ0I0 setting */
    INTC2.ICTAUJ0I0.BIT.TBTAUJ0I0 = INT_TABLE_VECTOR;
    INTC2.ICTAUJ0I0.UINT16 &= INT_PRIORITY_LOWEST;
    TAUJ0.TPS &= TAUJ_CK0_PRS_CLEAR;
    TAUJ0.TPS |= TAUJ_CK0_PRE_PCLK_0;
    /* Set channel 0 setting */
    TAUJ0.CMOR0 = 	TAUJ_SELECTION_CK0 | TAUJ_COUNT_CLOCK_PCLK | TAUJ_INDEPENDENT_CHANNEL | 
			TAUJ_START_TRIGGER_SOFTWARE | TAUJ_OVERFLOW_AUTO_CLEAR | TAUJ_INTERVAL_TIMER_MODE | 
			TAUJ_START_INT_NOT_GENERATED;
    /* Set compare match register */
    TAUJ0.CMUR0 = TAUJ_INPUT_EDGE_UNUSED;
    TAUJ0.CDR0 	= TAUJ00_COMPARE_VALUE;
    /* Set output mode setting */
    TAUJ0.TOE |= TAUJ_CHANNEL0_ENABLES_OUTPUT_MODE;
    TAUJ0.TOM &= TAUJ_CHANNEL0_INDEPENDENT_OPERATION;
    TAUJ0.TOC &= TAUJ_CHANNEL0_OPERATION_MODE1;
    TAUJ0.TOL &= TAUJ_CHANNEL0_POSITIVE_LOGIC;
    /* Synchronization processing */
    g_cg_sync_read = TAUJ0.TPS;
    __syncp();
    /* Set TAUJ0O0 pin */
    JTAG.JPIBC0 &= JPORT_CLEAR_BIT1;
    JTAG.JPBDC0 &= JPORT_CLEAR_BIT1;
    JTAG.JPM0 	|= JPORT_SET_BIT1;
    JTAG.JPMC0 	&= JPORT_CLEAR_BIT1;
    JTAG.JPFC0 	|= JPORT_SET_BIT1;
    JTAG.JPFCE0 &= JPORT_CLEAR_BIT1;
    JTAG.JPMC0 	|= JPORT_SET_BIT1;
    JTAG.JPM0 	&= JPORT_CLEAR_BIT1;

}/*--------------------------- End McuTauj0Ch0Init () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuTauj0Ch0Start
**
** Description:
** Initializes timer Tauj0 channel 0
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuTauj0Ch0Start(void)
{
    /* Clear INTTAUJ0I0 request and enable operation */
    INTC2.ICTAUJ0I0.BIT.RFTAUJ0I0 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICTAUJ0I0.BIT.MKTAUJ0I0 = INT_PROCESSING_ENABLED;
    /* Enable channel 0 counter operation */
    TAUJ0.TS |= TAUJ_CHANNEL0_COUNTER_START;
}/*--------------------------- End McuTauj0Ch0Start () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuTauj0Ch0Stop
**
** Description:
** Initializes timer Tauj0 channel 0
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuTauj0Ch0Stop(void)
{
    volatile uint32_t g_cg_sync_read;
    /* Disable channel 0 counter operation */
    TAUJ0.TT |= TAUJ_CHANNEL0_COUNTER_STOP;
    /* Disable INTTAUJ0I0 operation and clear request */
    INTC2.ICTAUJ0I0.BIT.MKTAUJ0I0 = INT_PROCESSING_DISABLED;
    INTC2.ICTAUJ0I0.BIT.RFTAUJ0I0 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = TAUJ0.TT;
    __syncp();
}/*--------------------------- End McuTauj0Ch0Stop () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: r_Config_TAUJ0_0_interrupt
**
** Description:
** ISR for the timer interrupt
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
#pragma ghs interrupt(enabled)
 __interrupt void McuTauj0Ch0Interrupt(void)
{
    clockTimeOut = 1;
}/*--------------------------- End McuTauj0Ch0Interrupt () -----------------------*/

/*--------------------------- End McuTauj0Ch0.c -----------------------------*/
