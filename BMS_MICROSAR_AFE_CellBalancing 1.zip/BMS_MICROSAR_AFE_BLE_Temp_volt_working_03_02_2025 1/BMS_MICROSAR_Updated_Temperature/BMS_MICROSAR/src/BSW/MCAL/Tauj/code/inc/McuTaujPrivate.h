/***********************************************************************************************************************
* File Name        : McuTaujPrivate.h
* Version          : 1.0.11
* Device(s)        : R7F701709
* Description      : General header file for TAUJ peripheral.
***********************************************************************************************************************/

#ifndef MCU_TAUJ_PRIVATE_H
#define MCU_TAUJ_PRIVATE_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
/*
    TAUJTTINm Input Signal Selection Register (SELB_TAUJ0I)
*/
/* Selection of  channel 3 input signal (SELB_TAUJ0I1,SELB_TAUJ0I3) */
#define TAUJ0_CHANNEL3_INPUT_TAUJ0I3                   (0x00U) /* Port TAUJ0I3 */
#define TAUJ0_CHANNEL3_INPUT_RTCA0OUT                  (0x02U) /* Timer input-RTCA0OUT */
#define TAUJ0_CHANNEL3_INPUT_TAUJ1OUT0                 (0x0AU) /* Timer input-TAUJ1 TAUJTTOUT0*/
#define TAUJ0_CHANNEL3_INPUT_CLEAR                     (0xF5U) /* Channel3 input clear */
/* Selection of  channel 2 input signal (SELB_TAUJ0I0,SELB_TAUJ0I2) */
#define TAUJ0_CHANNEL2_INPUT_TAUJ0I2                   (0x00U) /* Port TAUJ0I2 */
#define TAUJ0_CHANNEL2_INPUT_RTCA0OUT                  (0x01U) /* Timer input-RTCA0OUT */
#define TAUJ0_CHANNEL2_INPUT_TAUJ1OUT0                 (0x05U) /* Timer input-TAUJ1 TAUJTTOUT0*/
#define TAUJ0_CHANNEL2_INPUT_CLEAR                     (0xFAU) /* Channel2 input clear */
/*
    TAUJTTINm Input Signal Selection Register (SELB_TAUJ2I)
*/
/* Selection of  channel 3 input signal (SELB_TAUJ2I1) */
#define TAUJ2_CHANNEL3_INPUT_TAUJ2I3                   (0xFDU) /* Port TAUJ2I3 */
#define TAUJ2_CHANNEL3_INPUT_TAUJ3OUT0                 (0x02U) /* TAUJ3 TAUJTTOUT0*/
/* Selection of  channel 2 input signal (SELB_TAUJ2I0) */
#define TAUJ2_CHANNEL2_INPUT_TAUJ2I2                   (0xFEU) /* Port TAUJ2I2 */
#define TAUJ2_CHANNEL2_INPUT_TAUJ3OUT0                 (0x01U) /* TAUJ3 TAUJTTOUT0*/

/*
    TAUJn Prescaler Clock Select Register (TAUJnTPS)
*/
/* Operating mode selection (TAUJnPRS3[3-0]) */
#define TAUJ_CK3_PRE_PCLK_0                            (0x0000U) /* CK3_PRE - PCLK/2^0 */
#define TAUJ_CK3_PRE_PCLK_1                            (0x1000U) /* CK3_PRE - PCLK/2^1 */
#define TAUJ_CK3_PRE_PCLK_2                            (0x2000U) /* CK3_PRE - PCLK/2^2 */
#define TAUJ_CK3_PRE_PCLK_3                            (0x3000U) /* CK3_PRE - PCLK/2^3 */
#define TAUJ_CK3_PRE_PCLK_4                            (0x4000U) /* CK3_PRE - PCLK/2^4 */
#define TAUJ_CK3_PRE_PCLK_5                            (0x5000U) /* CK3_PRE - PCLK/2^5 */
#define TAUJ_CK3_PRE_PCLK_6                            (0x6000U) /* CK3_PRE - PCLK/2^6 */
#define TAUJ_CK3_PRE_PCLK_7                            (0x7000U) /* CK3_PRE - PCLK/2^7 */
#define TAUJ_CK3_PRE_PCLK_8                            (0x8000U) /* CK3_PRE - PCLK/2^8 */
#define TAUJ_CK3_PRE_PCLK_9                            (0x9000U) /* CK3_PRE - PCLK/2^9 */
#define TAUJ_CK3_PRE_PCLK_10                           (0xA000U) /* CK3_PRE - PCLK/2^10 */
#define TAUJ_CK3_PRE_PCLK_11                           (0xB000U) /* CK3_PRE - PCLK/2^11 */
#define TAUJ_CK3_PRE_PCLK_12                           (0xC000U) /* CK3_PRE - PCLK/2^12 */
#define TAUJ_CK3_PRE_PCLK_13                           (0xD000U) /* CK3_PRE - PCLK/2^13 */
#define TAUJ_CK3_PRE_PCLK_14                           (0xE000U) /* CK3_PRE - PCLK/2^14 */
#define TAUJ_CK3_PRE_PCLK_15                           (0xF000U) /* CK3_PRE - PCLK/2^15 */
#define TAUJ_CK3_PRS_CLEAR                             (0x0FFFU) /* CK30_PRE - clear */
/* Operating mode selection (TAUJnPRS2[3-0]) */
#define TAUJ_CK2_PRE_PCLK_0                            (0x0000U) /* CK2_PRE - PCLK/2^0 */
#define TAUJ_CK2_PRE_PCLK_1                            (0x0100U) /* CK2_PRE - PCLK/2^1 */
#define TAUJ_CK2_PRE_PCLK_2                            (0x0200U) /* CK2_PRE - PCLK/2^2 */
#define TAUJ_CK2_PRE_PCLK_3                            (0x0300U) /* CK2_PRE - PCLK/2^3 */
#define TAUJ_CK2_PRE_PCLK_4                            (0x0400U) /* CK2_PRE - PCLK/2^4 */
#define TAUJ_CK2_PRE_PCLK_5                            (0x0500U) /* CK2_PRE - PCLK/2^5 */
#define TAUJ_CK2_PRE_PCLK_6                            (0x0600U) /* CK2_PRE - PCLK/2^6 */
#define TAUJ_CK2_PRE_PCLK_7                            (0x0700U) /* CK2_PRE - PCLK/2^7 */
#define TAUJ_CK2_PRE_PCLK_8                            (0x0800U) /* CK2_PRE - PCLK/2^8 */
#define TAUJ_CK2_PRE_PCLK_9                            (0x0900U) /* CK2_PRE - PCLK/2^9 */
#define TAUJ_CK2_PRE_PCLK_10                           (0x0A00U) /* CK2_PRE - PCLK/2^10 */
#define TAUJ_CK2_PRE_PCLK_11                           (0x0B00U) /* CK2_PRE - PCLK/2^11 */
#define TAUJ_CK2_PRE_PCLK_12                           (0x0C00U) /* CK2_PRE - PCLK/2^12 */
#define TAUJ_CK2_PRE_PCLK_13                           (0x0D00U) /* CK2_PRE - PCLK/2^13 */
#define TAUJ_CK2_PRE_PCLK_14                           (0x0E00U) /* CK2_PRE - PCLK/2^14 */
#define TAUJ_CK2_PRE_PCLK_15                           (0x0F00U) /* CK2_PRE - PCLK/2^15 */
#define TAUJ_CK2_PRS_CLEAR                             (0xF0FFU) /* CK2_PRE - clear */
/* Operating mode selection (TAUJnPRS1[3-0]) */
#define TAUJ_CK1_PRE_PCLK_0                            (0x0000U) /* CK1_PRE - PCLK/2^0 */
#define TAUJ_CK1_PRE_PCLK_1                            (0x0010U) /* CK1_PRE - PCLK/2^1 */
#define TAUJ_CK1_PRE_PCLK_2                            (0x0020U) /* CK1_PRE - PCLK/2^2 */
#define TAUJ_CK1_PRE_PCLK_3                            (0x0030U) /* CK1_PRE - PCLK/2^3 */
#define TAUJ_CK1_PRE_PCLK_4                            (0x0040U) /* CK1_PRE - PCLK/2^4 */
#define TAUJ_CK1_PRE_PCLK_5                            (0x0050U) /* CK1_PRE - PCLK/2^5 */
#define TAUJ_CK1_PRE_PCLK_6                            (0x0060U) /* CK1_PRE - PCLK/2^6 */
#define TAUJ_CK1_PRE_PCLK_7                            (0x0070U) /* CK1_PRE - PCLK/2^7 */
#define TAUJ_CK1_PRE_PCLK_8                            (0x0080U) /* CK1_PRE - PCLK/2^8 */
#define TAUJ_CK1_PRE_PCLK_9                            (0x0090U) /* CK1_PRE - PCLK/2^9 */
#define TAUJ_CK1_PRE_PCLK_10                           (0x00A0U) /* CK1_PRE - PCLK/2^10 */
#define TAUJ_CK1_PRE_PCLK_11                           (0x00B0U) /* CK1_PRE - PCLK/2^11 */
#define TAUJ_CK1_PRE_PCLK_12                           (0x00C0U) /* CK1_PRE - PCLK/2^12 */
#define TAUJ_CK1_PRE_PCLK_13                           (0x00D0U) /* CK1_PRE - PCLK/2^13 */
#define TAUJ_CK1_PRE_PCLK_14                           (0x00E0U) /* CK1_PRE - PCLK/2^14 */
#define TAUJ_CK1_PRE_PCLK_15                           (0x00F0U) /* CK1_PRE - PCLK/2^15 */
#define TAUJ_CK1_PRS_CLEAR                             (0xFF0FU) /* CK1_PRE - clear */
/* Operating mode selection (TAUJnPRS0[3-0]) */
#define TAUJ_CK0_PRE_PCLK_0                            (0x0000U) /* CK0_PRE - PCLK/2^0 */
#define TAUJ_CK0_PRE_PCLK_1                            (0x0001U) /* CK0_PRE - PCLK/2^1 */
#define TAUJ_CK0_PRE_PCLK_2                            (0x0002U) /* CK0_PRE - PCLK/2^2 */
#define TAUJ_CK0_PRE_PCLK_3                            (0x0003U) /* CK0_PRE - PCLK/2^3 */
#define TAUJ_CK0_PRE_PCLK_4                            (0x0004U) /* CK0_PRE - PCLK/2^4 */
#define TAUJ_CK0_PRE_PCLK_5                            (0x0005U) /* CK0_PRE - PCLK/2^5 */
#define TAUJ_CK0_PRE_PCLK_6                            (0x0006U) /* CK0_PRE - PCLK/2^6 */
#define TAUJ_CK0_PRE_PCLK_7                            (0x0007U) /* CK0_PRE - PCLK/2^7 */
#define TAUJ_CK0_PRE_PCLK_8                            (0x0008U) /* CK0_PRE - PCLK/2^8 */
#define TAUJ_CK0_PRE_PCLK_9                            (0x0009U) /* CK0_PRE - PCLK/2^9 */
#define TAUJ_CK0_PRE_PCLK_10                           (0x000AU) /* CK0_PRE - PCLK/2^10 */
#define TAUJ_CK0_PRE_PCLK_11                           (0x000BU) /* CK0_PRE - PCLK/2^11 */
#define TAUJ_CK0_PRE_PCLK_12                           (0x000CU) /* CK0_PRE - PCLK/2^12 */
#define TAUJ_CK0_PRE_PCLK_13                           (0x000DU) /* CK0_PRE - PCLK/2^13 */
#define TAUJ_CK0_PRE_PCLK_14                           (0x000EU) /* CK0_PRE - PCLK/2^14 */
#define TAUJ_CK0_PRE_PCLK_15                           (0x000FU) /* CK0_PRE - PCLK/2^15 */
#define TAUJ_CK0_PRS_CLEAR                             (0xFFF0U) /* CK0_PRE - clear */

/*
    TAUJnChannel Mode OS Register (TAUJnCMORn)
*/
/* Selection of operation clock (TAUJnCKS[1-0]) */
#define TAUJ_SELECTION_CK0                             (0x0000U) /* CK0 */
#define TAUJ_SELECTION_CK1                             (0x4000U) /* CK1 */
#define TAUJ_SELECTION_CK2                             (0x8000U) /* CK2 */
#define TAUJ_SELECTION_CK3                             (0xC000U) /* CK3 */
/* Selects a count clock for TAUJnCNTn counter (TAUJnCCS[1-0]) */
#define TAUJ_COUNT_CLOCK_PCLK                          (0x0000U) /* Operation clock specified */
/* A master channel or slave channel (TAUJnMAS) */
#define TAUJ_INDEPENDENT_CHANNEL                       (0x0000U) /* Slave */
#define TAUJ_SLAVE_CHANNEL                             (0x0000U) /* Slave */
#define TAUJ_MASTER_CHANNEL                            (0x0800U) /* Master */
/* Selects an external start trigger (TAUJnSTS[2-0]) */
#define TAUJ_START_TRIGGER_SOFTWARE                    (0x0000U) /* Software trigger */
#define TAUJ_START_TRIGGER_VALID_EDGE                  (0x0100U) /* Valid edge of TAUJTTINn input signal */
#define TAUJ_START_STOP_TRIGGER_VALID_EDGE             (0x0200U) /* The reverse edge is used */
#define TAUJ_START_TRIGGER_MASTER_INT                  (0x0400U) /* INT of master channel */
/* Specifies the timing for updating capture register (TAUJnCOS[1-0]) */
#define TAUJ_OVERFLOW_AUTO_CLEAR                       (0x0000U) /* TAUJTTINm and TAUJnOVF update */
#define TAUJ_OVERFLOW_MANUAL_CLEAR                     (0x0040U) /* TAUJTTINm and TAUJnOVF is set */
#define TAUJ_OVERFLOW_COUNT_STOP                       (0x0080U) /* TAUJnOVF is not set */
#define TAUJ_OVERFLOW_COUNT_STOP_MANUAL_CLEAR          (0x00C0U) /* TAUJnOVF is set */
/* Specifies an operating mode (TAUJnMD[4-1]) */
#define TAUJ_INTERVAL_TIMER_MODE                       (0x0000U) /* Interval timer mode */
#define TAUJ_CAPTURE_MODE                              (0x0004U) /* Capture mode */
#define TAUJ_ONE_COUNT_MODE                            (0x0008U) /* One-count mode */
#define TAUJ_CAPTURE_ONE_COUNT_MODE                    (0x000CU) /* Capture and one-count mode */
#define TAUJ_COUNT_CAPTURE_MODE                        (0x0016U) /* Count capture mode  */
#define TAUJ_GATE_COUNT_MODE                           (0x0018U) /* Gate count mode */
#define TAUJ_CAPTURE_AND_GATE_COUNT_MODE               (0x001AU) /* Capture and gate count mode  */
/* Role of TAUJnMD0 Bit (TAUJnMD0) */
#define TAUJ_START_INT_NOT_GENERATED                   (0x0000U) /* INTTAUJnIm is not generated */
#define TAUJ_START_TRIGGER_DISABLE                     (0x0000U) /* Disables detection. */
#define TAUJ_START_INT_GENERATED                       (0x0001U) /* INTTAUJnIm is generated */
#define TAUJ_START_TRIGGER_ENABLE                      (0x0001U) /* Enables detection. */

/*
    TAUJnChannel Mode User Register (TAUJnCMURn)
*/
/* Specifies a valid edge of TAUJTTINn input signal (TAUJnTIS[1-0]) */
#define TAUJ_INPUT_EDGE_UNUSED                         (0x00U) /* Unused falling edge */
#define TAUJ_INPUT_EDGE_FALLING                        (0x00U) /* Falling edge */
#define TAUJ_INPUT_EDGE_RISING                         (0x01U) /* Rising edge */
#define TAUJ_INPUT_EDGE_BOTH_MEASURE_LOW               (0x02U) /* Detection of rising and falling edges (selects low width measurement) */
#define TAUJ_INPUT_EDGE_BOTH_MEASURE_HIGH              (0x03U) /* Detection of rising and falling edges (selects high width measurement) */

/*
    TAUJnChannel Start Trigger Register (TAUJnTS)
*/
/* Enables the counter operation of channel 3 (TAUJnTS3) */
#define TAUJ_CHANNEL3_COUNTER_START                    (0x08U) /* Enables the counter operation */
/* Enables the counter operation of channel 2 (TAUJnTS2) */
#define TAUJ_CHANNEL2_COUNTER_START                    (0x04U) /* Enables the counter operation */
/* Enables the counter operation of channel 1 (TAUJnTS1) */
#define TAUJ_CHANNEL1_COUNTER_START                    (0x02U) /* Enables the counter operation */
/* Enables the counter operation of channel 0 (TAUJnTS0) */
#define TAUJ_CHANNEL0_COUNTER_START                    (0x01U) /* Enables the counter operation */

/*
    TAUJnChannel Stop Trigger Register (TAUJnTT)
*/
/* Stops the counter operation of channel 3 (TAUJnTT3) */
#define TAUJ_CHANNEL3_COUNTER_STOP                     (0x08U) /* Stops the counter operation and resets TAUJnTE.TAUJnTEm */
/* Stops the counter operation of channel 2 (TAUJnTT2) */
#define TAUJ_CHANNEL2_COUNTER_STOP                     (0x04U) /* Stops the counter operation and resets TAUJnTE.TAUJnTEm */
/* Stops the counter operation of channel 1 (TAUJnTT1) */
#define TAUJ_CHANNEL1_COUNTER_STOP                     (0x02U) /* Stops the counter operation and resets TAUJnTE.TAUJnTEm */
/* Stops the counter operation of channel 0 (TAUJnTT0) */
#define TAUJ_CHANNEL0_COUNTER_STOP                     (0x01U) /* Stops the counter operation and resets TAUJnTE.TAUJnTEm */

/*
    TAUJnChannel Reload Data Enable Register (TAUJnRDE)    
*/
/* Enables/disables simultaneous rewrite of the data register of channel  (TAUJnRDE3) */
#define TAUJ_CHANNEL3_DISABLES_SIMULT_REWRITE_MODE     (0xFFF7U) /* Disables simultaneous rewrite */
#define TAUJ_CHANNEL3_ENABLES_SIMULT_REWRITE_MODE      (0x0008U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel  (TAUJnRDE2) */
#define TAUJ_CHANNEL2_DISABLES_SIMULT_REWRITE_MODE     (0xFFFBU) /* Disables simultaneous rewrite */
#define TAUJ_CHANNEL2_ENABLES_SIMULT_REWRITE_MODE      (0x0004U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel  (TAUJnRDE1) */
#define TAUJ_CHANNEL1_DISABLES_SIMULT_REWRITE_MODE     (0xFFFDU) /* Disables simultaneous rewrite */
#define TAUJ_CHANNEL1_ENABLES_SIMULT_REWRITE_MODE      (0x0002U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel  (TAUJnRDE0) */
#define TAUJ_CHANNEL0_DISABLES_SIMULT_REWRITE_MODE     (0xFFFEU) /* Disables simultaneous rewrite */
#define TAUJ_CHANNEL0_ENABLES_SIMULT_REWRITE_MODE     (0x0001U) /* Enables simultaneous rewrite */

/*
    TAUJnChannel Reload Data Mode Register (TAUJnRDM)
*/
/*Selects when the signal that triggers simultaneous rewrite is generated(TAUJnRDM3) */
#define TAUJ_CHANNEL3_MASTER_START_RELOAD_MODE         (0xFFF7U) /* When the master channel counter starts counting */
#define TAUJ_CHANNEL3_TOP_CYC_RELOAD_MODE              (0x0008U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated(TAUJnRDM2) */
#define TAUJ_CHANNEL2_MASTER_START_RELOAD_MODE         (0xFFFBU) /* When the master channel counter starts counting */
#define TAUJ_CHANNEL2_TOP_CYC_RELOAD_MODE              (0x0004U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated(TAUJnRDM1) */
#define TAUJ_CHANNEL1_MASTER_START_RELOAD_MODE         (0xFFFDU) /* When the master channel counter starts counting */
#define TAUJ_CHANNEL1_TOP_CYC_RELOAD_MODE              (0x0002U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated(TAUJnRDM0) */
#define TAUJ_CHANNEL0_MASTER_START_RELOAD_MODE         (0xFFFEU) /* When the master channel counter starts counting */
#define TAUJ_CHANNEL0_TOP_CYC_RELOAD_MODE              (0x0001U) /* At the top of a triangle wave cycle */

/*
    TAUJnChannel Reload Data Trigger Register (TAUJnRDT)
*/
/* Triggers the simultaneous rewrite enabling state (TAUJnRDT3) */
#define TAUJ_CHANNEL3_WAIT_TRIGGER_SIMULT_REWRITE      (0x0008U) /* The simultaneous rewrite trigger */
/* Triggers the simultaneous rewrite enabling state (TAUJnRDT2) */
#define TAUJ_CHANNEL2_WAIT_TRIGGER_SIMULT_REWRITE      (0x0004U) /* The simultaneous rewrite trigger */
/* Triggers the simultaneous rewrite enabling state (TAUJnRDT1) */
#define TAUJ_CHANNEL1_WAIT_TRIGGER_SIMULT_REWRITE      (0x0002U) /* The simultaneous rewrite trigger */
/* Triggers the simultaneous rewrite enabling state (TAUJnRDT0) */
#define TAUJ_CHANNEL0_WAIT_TRIGGER_SIMULT_REWRITE      (0x0001U) /* The simultaneous rewrite trigger */

/*
    TAUJnChannel Output Enable Register (TAUJnTOE)
*/
/* Enables/disables the independent channel output function (TAUJnTOE3) */
#define TAUJ_CHANNEL3_DISABLES_OUTPUT_MODE             (0xF7U) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL3_ENABLES_OUTPUT_MODE              (0x08U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJnTOE2) */
#define TAUJ_CHANNEL2_DISABLES_OUTPUT_MODE             (0xFBU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL2_ENABLES_OUTPUT_MODE              (0x04U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJnTOE1) */
#define TAUJ_CHANNEL1_DISABLES_OUTPUT_MODE             (0xFDU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL1_ENABLES_OUTPUT_MODE              (0x02U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJnTOE0) */
#define TAUJ_CHANNEL0_DISABLES_OUTPUT_MODE             (0xFEU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL0_ENABLES_OUTPUT_MODE              (0x01U) /* Enables the independent timer output function */

/*
    TAUJnChannel Output Register (TAUJnTO)
*/
/* Specifies and reads a TAUJTTOUTm level (TAUJnTO3) */
#define TAUJ_CHANNEL3_LOW_LEVEL                        (0xFFF7U) /*  Low level */
#define TAUJ_CHANNEL3_HIGH_LEVEL                       (0x0008U) /*  High level */
/* Specifies and reads a TAUJTTOUTm level (TAUJnTO2) */
#define TAUJ_CHANNEL2_LOW_LEVEL                        (0xFFFBU) /*  Low level */
#define TAUJ_CHANNEL2_HIGH_LEVEL                       (0x0004U) /*  High level */
/* Specifies and reads a TAUJTTOUTm level (TAUJnTO1) */
#define TAUJ_CHANNEL1_LOW_LEVEL                        (0xFFFDU) /*  Low level */
#define TAUJ_CHANNEL1_HIGH_LEVEL                       (0x0002U) /*  High level */
/* Specifies and reads a TAUJTTOUTm level (TAUJnTO0) */
#define TAUJ_CHANNEL0_LOW_LEVEL                        (0xFFFEU) /*  Low level */
#define TAUJ_CHANNEL0_HIGH_LEVEL                       (0x0001U) /*  High level */

/*
    TAUJnChannel Output Mode Register (TAUJnTOM)
*/
/* Specifies an output mode (TAUJnTOM3) */
#define TAUJ_CHANNEL3_INDEPENDENT_OPERATION            (0xF7U) /* Independent channel operation */
#define TAUJ_CHANNEL3_SYNCHRONOUS_OPERATION            (0x08U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJnTOM2) */
#define TAUJ_CHANNEL2_INDEPENDENT_OPERATION            (0xFBU) /* Independent channel operation */
#define TAUJ_CHANNEL2_SYNCHRONOUS_OPERATION            (0x04U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJnTOM1) */
#define TAUJ_CHANNEL1_INDEPENDENT_OPERATION            (0xFDU) /* Independent channel operation */
#define TAUJ_CHANNEL1_SYNCHRONOUS_OPERATION            (0x02U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJnTOM0) */
#define TAUJ_CHANNEL0_INDEPENDENT_OPERATION            (0xFEU) /* Independent channel operation */
#define TAUJ_CHANNEL0_SYNCHRONOUS_OPERATION            (0x01U) /* Synchronous channel operation */

/*
    TAUJn Channel Output Configuration Register (TAUJnTOC)
*/
/* Specifies the output mode (TAUJnTOC3) */
#define TAUJ_CHANNEL3_OPERATION_MODE1                  (0xF7U) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC2) */
#define TAUJ_CHANNEL2_OPERATION_MODE1                  (0xFBU) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC1) */
#define TAUJ_CHANNEL1_OPERATION_MODE1                  (0xFDU) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC0) */
#define TAUJ_CHANNEL0_OPERATION_MODE1                  (0xFEU) /* Operation mode 1 */

/*
    TAUJnChannel Output Level Register (TAUJnTOL)
*/
/* Specifies the output logic of channel 3 output bit (TAUJnTOL3) */
#define TAUJ_CHANNEL3_POSITIVE_LOGIC                   (0xF7U) /* Positive logic */
#define TAUJ_CHANNEL3_NEGATIVE_LOGIC                   (0x08U) /* Negative logic */
/* Specifies the output logic of channel 2 output bit (TAUJnTOL2) */
#define TAUJ_CHANNEL2_POSITIVE_LOGIC                   (0xFBU) /* Positive logic */
#define TAUJ_CHANNEL2_NEGATIVE_LOGIC                   (0x04U) /* Negative logic */
/* Specifies the output logic of channel 1 output bit (TAUJnTOL1) */
#define TAUJ_CHANNEL1_POSITIVE_LOGIC                   (0xFDU) /* Positive logic */
#define TAUJ_CHANNEL1_NEGATIVE_LOGIC                   (0x02U) /* Negative logic */
/* Specifies the output logic of channel 0 output bit (TAUJnTOL0) */
#define TAUJ_CHANNEL0_POSITIVE_LOGIC                   (0xFEU) /* Positive logic */
#define TAUJ_CHANNEL0_NEGATIVE_LOGIC                   (0x01U) /* Negative logic */

/*
    TAUJn Channel Status Clear Register(TAUJnCSCm)
*/
/* Clearing the overflow flag TAUJnCSRm.TAUJnOVF of channel m(TAUJnCLOV) */
#define TAUJ_OVERFLOW_FLAG_CLEAR                       (0x01U) /* Clears overflow flag */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define TAUJ_OVERFLOW_OCCURS                           (0x01U) /* Overflow occurs */
#define TAUJ_OVERFLOW_VALUE                            (0x100000000ULL) /* Overflow value */
#define TAUJ_FILTER_ENABLED                            (0x01U) /* Digital noise elimination enable control */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/

#endif	/* MCU_TAUJ_PRIVATE_H */
