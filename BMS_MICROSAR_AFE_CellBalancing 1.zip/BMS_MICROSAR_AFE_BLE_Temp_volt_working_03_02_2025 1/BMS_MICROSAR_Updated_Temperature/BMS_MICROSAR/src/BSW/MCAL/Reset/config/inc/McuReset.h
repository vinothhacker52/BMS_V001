/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                         
** File: McuReset.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for Mcu Reset Functions.
**---------------------------------------------------------------------------*/
#ifndef MCU_RESET_H
#define MCU_RESET_H


#include "McuTypedefs.h"	
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define	CLEAR_RESET_FLAG	0x4FFF		/* Macro to clear the bit in Reset Control Register */
#define SOFTWARE_RESET_TRIGGER	0x00000001UL	/* Trigger to assert a software reset */

typedef struct MCU_RESET_STATUS_BITS
{
    uint32_t swReset        	:1;	/*Software Reset Occurance*/
    uint32_t wdta0Reset     	:1;	/*Watchdog 0 Reset Occurance*/
    uint32_t wdta1Reset     	:1;	/*Watchdog 1 Reset Occurance*/
    uint32_t clma0Reset     	:1;	/*CLMA 0 Reset Occurance*/
    uint32_t clma1Reset     	:1;	/*CLMA 1 Reset Occurance*/
    uint32_t clma2Reset     	:1;	/*CLMA 2 Reset Occurance*/
    uint32_t lviReset       	:1;	/*Low Voltage Indicator(LVI) Reset Occurance*/
    uint32_t cvmReset       	:1;	/*Core Voltage Monitor(CVM) Reset Occurance*/
    uint32_t externalReset  	:1;	/*External Reset Occurance*/
    uint32_t powerUpReset   	:1;	/*Power-up Reset Occurance*/
    uint32_t DeepStop_reset  	:1;	/*Deep-Stop Reset Occurance*/
    uint32_t wdta2Reset     	:1;	/*Watchdog 2 Reset Occurance*/
    uint32_t res12          	:1;	/*Reserved*/
    uint32_t res13          	:1;	/*Reserved*/
    uint32_t clma3Reset     	:1;	/*CLMA 3 Reset Occurance*/
}McuResetStatusBits;

typedef union MCU_RESET_STATUS
{
    uint32_t		all;	/* Stores the whole value from the Reset Factor(RESF) Register */
    McuResetStatusBits	bit;	/* Used to get reset cause flag */
} McuResetStatus;
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern volatile McuResetStatus mcuResetStatus;
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void McuResetSoftware		(void);
extern void McuResetStatusCheck		(void);
extern void McuResetStatusClearAll	(void);
#endif // MCU_RESET_H

/*--------------------------- End McuReset.h -----------------------------*/
