/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                   
** File: McuReset.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of Mcu Reset Functions.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/* Files: McuEeset.c & McuReset.h
 *
 * V1.0 	:  07-Mar-2025  : Initial Version
 * V1.1 	:  21-Mar-2025  : None
 * V1.2 	:  10-Apr-2025  : Added this file
 * V1.3		:  15-Apr-2025	: No Changes.
 * V1.4		:  22-Apr-2025	: The following changes were made :
 *					1. Added a typedef union with a member "all" to store the data from the reset control register and another member
 *			   		   "bit" of type McuResetStatusBits to access the induvidual status bit values.
 *					2. An object of this type is declared and used to read and store value from the Reset Control Status
 *			   		   register.
 *					3. Renamed the function "ReadResetFactor (void)" to "McuResetStatusCheck (void)".
 *					4. Renamed the fucntion "ClearResetFlag (void)" to "McuResetStatusClearAll (void)" .
 * V1.5		:  14-May_2025	: No Changes.
 * V1.6		:  03-Jun-2025	: No Changes.
 * V1.7		:  13-Jun-2025	: No Changes.
 * V1.8		:  19-Jun-2025	: The Following changes are made:
 *					1. Changed the name of the function "McuSoftwareReset" to "McuResetSoftware"
 *
 */

/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuReset.h"
#include "McuMacroDriver.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/

/* 1. MISRA C RULE VIOLATION:                                             	*/
/* Message       : (MISRA_RESET:1) A project shall not contain dead code.	*/
/*		   Variable 'RESCTL' is rewritten later without an intermediate	*/
/*		   read.						     	*/
/* Rule          : MISRA-C:2012 Rule 2.2                                    	*/
/* Justification : The process to write to a protected register is being	*/
/*		   executed here which involves writting into the protected	*/
/*		   register thrice.						*/
/* Verification  : The conversion done here is tested manually and is 	     	*/
/*		   verified to have no negative impact.				*/
/* Reference     : Look for START Msg(MISRA_RESET:1) and                      	*/
/*                 END Msg(MISRA_RESET:1) tags in the code.                   	*/
/********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/
volatile McuResetStatus mcuResetStatus;
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Function: McuResetSoftware
**
** Description:
** This Function triggers a Software Reset
**
** Arguments:
** 
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuResetSoftware(void)
{
    do 
    {
        WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
	/* MISRA Violation: START Msg(MISRA_RESET:1)*/
        RESCTL.SWRESA	= SOFTWARE_RESET_TRIGGER;      
        RESCTL.SWRESA	= ~(SOFTWARE_RESET_TRIGGER);
        RESCTL.SWRESA	= SOFTWARE_RESET_TRIGGER;
	/* END Msg(MISRA_RESET:1)*/
    } while(WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);
}/*--------------------------- End McuResetSoftware () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuResetStatusCheck
**
** Description:
** Checks which type of resets occurred after the last power-on clear reset.
**
** Arguments:
** None
**
** Return values:
** Reset status
**---------------------------------------------------------------------------*/
void McuResetStatusCheck ( void )
{

    /* Gets the type of resets occurred after the last power-on clear reset.
       This is useful for general diagnostics or fault handling.
       Note - To ensure the latest reset status is obtained, always call this 
       function before using the status value*/
    mcuResetStatus.all = RESCTL.RESF;

}

/*-----------------------------------------------------------------------------
** Function: McuResetStatusClearAll
**
** Description:
** Clears all the reset flags
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/

void McuResetStatusClearAll(void)
{

    RESCTL.RESFC = CLEAR_RESET_FLAG;

}/*--------------------------- End  McuResetStatusClearAll() -----------------------*/

/*--------------------------- End McuReset.c -----------------------------*/
