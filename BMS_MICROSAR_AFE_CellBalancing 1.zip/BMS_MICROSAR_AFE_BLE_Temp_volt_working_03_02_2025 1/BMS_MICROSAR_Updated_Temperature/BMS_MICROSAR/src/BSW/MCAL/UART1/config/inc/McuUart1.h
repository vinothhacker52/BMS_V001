/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: McuUart1
.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for CAN module.
**---------------------------------------------------------------------------*/
#ifndef MCU_UART_1_H
#define MCU_UART_1_H

#include "McuTypedefs.h"
#include <stdbool.h>
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define UART1_BAUD_RATE_PRESCALER                 (0x01CEU)

#define UART_NORMAL_MODE 0U
#define UART_REPLY_FRAME_MODE 1U
#define UART_RESPONSE_MODE    2U


/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/

extern void McuUart1Init(void);
extern void McuUart1Start(void);
extern void McuUart1Stop(void);

extern MD_STATUS McuUart1Rx(void);
extern MD_STATUS McuUart1Tx(uint8_t * const sendBuffer, uint16_t sendNumber);



#endif /* MCU_UART_1_H */

/*--------------------------- End McuCan.h -----------------------------*/

