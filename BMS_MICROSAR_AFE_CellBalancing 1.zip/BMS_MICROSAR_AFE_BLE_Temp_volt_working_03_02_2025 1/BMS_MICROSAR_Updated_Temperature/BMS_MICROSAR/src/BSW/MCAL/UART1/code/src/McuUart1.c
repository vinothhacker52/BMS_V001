/*-----------------------------------------------------------------------------
**                           
** File: McuUart.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of the McuTauj3Ch1 module.
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include <string.h>
#include "McuUart1.h"
#include "McuUart1Private.h"
#include "McuMacroDriver.h"
#include "McuUserDefine.h"
#include "McuGpio.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/


/********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define UART_TX_TIMEOUT 1000000

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/


volatile uint8_t  receive1Buffer[50];
uint8_t rxCount1 = 0;
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

void McuUart1Init(void){

    volatile uint32_t g_cg_sync_read;
    McuGpioPinConfig lin1Rx;
    McuGpioPinConfig lin1Tx;
    /*For Bluetooth Init*/
#if 1
 /* Set LIN reset mode */
    RLN31.LCUC = UART_LIN_RESET_MODE_CAUSED;
    /* Disable ICRLIN31UR0 operation and clear request */
    INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN31UR1 operation and clear request */
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN31UR2 operation and clear request */
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    /* Set ICRLIN31UR0 table method */
    INTC2.ICRLIN31UR0.BIT.TBRLIN31UR0 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR0 priority */
    INTC2.ICRLIN31UR0.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN31UR1 table method */
    INTC2.ICRLIN31UR1.BIT.TBRLIN31UR1 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR1 priority */
    INTC2.ICRLIN31UR1.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN31UR2 table method */
    INTC2.ICRLIN31UR2.BIT.TBRLIN31UR2 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR2 priority */
    INTC2.ICRLIN31UR2.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set UART0 setting */
    RLN31.LWBR = UART_9_SAMPLING | UART_PRESCALER_CLOCK_SELECT_1;
    RLN31.LBRP01.UINT16 = UART1_BAUD_RATE_PRESCALER;
    RLN31.LMD = UART_NOISE_FILTER_DISABLED | UART_MODE_SELECT;
    RLN31.LEDE = UART_FRAMING_ERROR_DETECTED | UART_OVERRUN_ERROR_DETECTED;
    RLN31.LBFC = UART_TRANSMISSION_NORMAL | UART_RECEPTION_NORMAL | UART_PARITY_PROHIBITED | UART_STOP_BIT_1 | 
	UART_LSB | UART_LENGTH_8;
    RLN31.LCUC = UART_LIN_RESET_MODE_CANCELED;
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();
    /* Set RLIN30RX(P0_4) pin */
    lin1Rx.port                 = MCU_PORT_P0;          /* Set the port */
    lin1Rx.pin                  = MCU_PIN_4;                /* Set the pin */
    lin1Rx.alt                  = MCU_GPIO_ALT7;            /* Set the alternative function */
    lin1Rx.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    lin1Rx.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    lin1Rx.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    lin1Rx.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    lin1Rx.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    lin1Rx.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&lin1Rx);

    /* Set RLIN30TX(P0_5) pin */
    lin1Tx.port                 = MCU_PORT_P0;          /* Set the port */
    lin1Tx.pin                  = MCU_PIN_5;                /* Set the pin */
    lin1Tx.alt                  = MCU_GPIO_ALT1;            /* Set the alternative function */
    lin1Tx.dir                  = MCU_GPIO_OUTPUT;          /* Set input/output mode */
    lin1Tx.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    lin1Tx.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    lin1Tx.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    lin1Tx.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    lin1Tx.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;  /* Disabling bidirectional mode */
    McuGpioPortInit(&lin1Tx);
#endif 

}

/***********************************************************************************************************************
 * Function Name: McuUart1Start
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart1Start(void)
{
    /* Enable UART1 operation */
    RLN31.LUOER |= UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED;
    /* Clear ICRLIN30UR1 interrupt request and enable operation */
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    /* Clear ICRLIN30UR2 interrupt request and enable operation */
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
}


/***********************************************************************************************************************
 * Function Name: McuUart1Stop
 * Description  : This function stops the CSIH0 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart1Stop(void)
{
    volatile uint32_t g_cg_sync_read;
    /* Disable ICRLIN30UR1 operation */
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    /* Disable ICRLIN30UR2 operation */
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
    /* Disable UART0 operation */
    RLN31.LUOER &= (uint8_t) ~(UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED);
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();
    /* Clear ICRLIN30UR1 request */
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    /* Clear ICRLIN30UR2 request */
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();
}




/***********************************************************************************************************************
 * Function Name: McuUart1Tx
 * Description  : This function sends UART1 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart1Tx(uint8_t * const transmitBuffer, uint16_t dataLength)
{
    
    MD_STATUS status = MD_OK;
    if ((transmitBuffer == NULL) ||(dataLength == 0U))
    {
        return MD_ARGERROR;
    }
    for (uint8_t i = 0U; i < dataLength; i++)
    {
        uint32_t timeout = UART_TX_TIMEOUT;
        while (((RLN31.LST & UART_TRANSMISSION_OPERATED) != 0U) && (timeout > 0UL))
        {
            timeout--;
        }
        if (timeout == 0UL)
        {
            return MD_ERROR;
        }    
        RLN31.LUTDR.UINT16 = (uint8_t)transmitBuffer[i];
    }

    return (status);
}

/***********************************************************************************************************************
 * Function Name: McuUart1Rx
 * Description  : This function receives UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart1Rx(void)
{
    uint8_t byte = (uint8_t)(RLN31.LURDR.UINT16 & 0xFF);
    receive1Buffer[rxCount1] = byte;
    rxCount1++;
    if(rxCount1 == 50)
	rxCount1 = 0;
}


/***********************************************************************************************************************
 * Function Name: McuUart1RxRdResponse
 * Description  : This function Receives UART0 data.
 * Arguments    : None
 * Return Value : None
 ********************rxC***************************************************************************************************/


