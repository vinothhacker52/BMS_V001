/*-----------------------------------------------------------------------------
**                             ? 2025 Ashok Leyland                           
** File: McuPwm.c
**
** Description:
** This source file defines the functions, macros, and variables related
** to the operation of the MCAL layer of the PWM Module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/


/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuPwm.h"
#include "McuPwmPrivate.h"
#include "McuGpio.h"
#include "McuMacroDriver.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/

/********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
static void McuPwmSetOutputMode	(
				    uint16_t pwmChannelEnable,
				    uint16_t pwmChannelOutputMode, 
				    uint16_t pwmChannelOutputConfig,
				    uint16_t channelOutLogic, 
				    uint16_t deadTimeControl,
				    uint16_t deadTimerPhase
				);
// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: McuPwmInit()
**
** Description:
** This function initializes the PWM in the MCAL layer.
**
** Arguments:
** 1. pMcuPwmConfig : pointer to structure 
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuPwmInit(McuPwmConfig *pMcuPwmConfig)
{
    volatile uint32_t g_cg_sync_read;
    McuGpioPinConfig pwmChannel1Pin;
    /* Disable channel counter operation */
    McuPwmStop();
      /* Disable channel counter operation */
    TAUJ1.TT |= (TAUJ_CHANNEL1_COUNTER_STOP | TAUJ_CHANNEL0_COUNTER_STOP);
    /* Disable INTTAUJ1I0 operation and clear request */
    INTC2.ICTAUJ1I0.BIT.MKTAUJ1I0 = INT_PROCESSING_DISABLED;
    INTC2.ICTAUJ1I0.BIT.RFTAUJ1I0 = INT_REQUEST_NOT_OCCUR;
    /* Disable INTTAUJ1I1 operation and clear request */
    INTC2.ICTAUJ1I1.BIT.MKTAUJ1I1 = INT_PROCESSING_DISABLED;
    INTC2.ICTAUJ1I1.BIT.RFTAUJ1I1 = INT_REQUEST_NOT_OCCUR;
    TAUJ1.TPS &= TAUJ_CK0_PRS_CLEAR;
    TAUJ1.TPS |= TAUJ_CK0_PRE_PCLK_0;
    /* Set channel 0 setting */
    TAUJ1.CMOR0 = TAUJ_SELECTION_CK0 | TAUJ_COUNT_CLOCK_PCLK | TAUJ_MASTER_CHANNEL | TAUJ_START_TRIGGER_SOFTWARE | 
                  TAUJ_OVERFLOW_AUTO_CLEAR | TAUJ_INTERVAL_TIMER_MODE | TAUJ_START_INT_GENERATED;
    /* Set compare match register */
    TAUJ1.CMUR0 = TAUJ_INPUT_EDGE_UNUSED;
    TAUJ1.CDR0 = TAUJ1_CHANNEL0_COMPARE_VALUE;
    /* Set output mode setting */
    TAUJ1.TOE &= TAUJ_CHANNEL0_DISABLES_OUTPUT_MODE;
    /* Set channel 1 setting */
    TAUJ1.CMOR1 = TAUJ_SELECTION_CK0 | TAUJ_COUNT_CLOCK_PCLK | TAUJ_SLAVE_CHANNEL | 
                  TAUJ_START_TRIGGER_MASTER_INT | TAUJ_OVERFLOW_AUTO_CLEAR | TAUJ_ONE_COUNT_MODE | 
                  TAUJ_START_TRIGGER_ENABLE;
    /* Set compare match register */
    TAUJ1.CMUR1 = TAUJ_INPUT_EDGE_UNUSED;
    TAUJ1.CDR1 = TAUJ1_CHANNEL1_COMPARE_VALUE;
    /* Set output mode setting */
    TAUJ1.TOE |= TAUJ_CHANNEL1_ENABLES_OUTPUT_MODE;
    TAUJ1.TOM |= TAUJ_CHANNEL1_SYNCHRONOUS_OPERATION;
    TAUJ1.TOC &= TAUJ_CHANNEL1_OPERATION_MODE1;
    TAUJ1.TOL &= TAUJ_CHANNEL1_POSITIVE_LOGIC;
    
  
    /* Set output mode setting */
    /* !!!! Pay Attention To The Macros While Making Any Changes In The Code To Prevent Unintensional Behaviour !!!! */
    McuPwmSetOutputMode(PWM_CHANNEL1_ENABLES_OUTPUT_MODE,
			PWM_CHANNEL1_SYNCHRONOUS_OUTPUT_MODE,
			PWM_CHANNEL1_OPERATION_MODE1,
			(uint16_t)pMcuPwmConfig->channel1.activeOutputLevel, 
			PWM_CHANNEL1_DISABLE_DEAD_TIME_OPERATE, 
			PWM_CHANNEL1_POSITIVE_PHASE_PERIOD);
    /* Synchronization processing */
    g_cg_sync_read = TAUJ1.TPS;
    __syncp();
    /* Set TAUJ1O1 pin */		/* Configuring port 11, pin 3 to operate as Taub1 channel 1 output */
    pwmChannel1Pin.port 				= MCU_PORT_P9; 			/* Set the port */
    pwmChannel1Pin.pin 				= MCU_PIN_3;				/* Set the pin */
    pwmChannel1Pin.alt 				= MCU_GPIO_ALT3;			/* Set the alternative function */
    pwmChannel1Pin.dir 				= MCU_GPIO_OUTPUT;			/* Set input/output mode */
    pwmChannel1Pin.portControl			= MCU_GPIO_SW_CONTROL;			/* I/O direction is controlled by portmode register */
    pwmChannel1Pin.pinOutputMode		= MCU_GPIO_PUSH_PULL;			/* Set pin mode (Push-Pull or Open Drain)*/	
    pwmChannel1Pin.driveStrength 		= MCU_GPIO_LOW_DRIVE_STRENGTH;		/* Set drive strength*/
    pwmChannel1Pin.inputResistorConfig	= MCU_GPIO_FLOATING;			/* Set input resister as neither Pull-up nor Pull-down */
    pwmChannel1Pin.biDirectionControl	= MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    /* MISRA Violation: START Msg(MISRA_PWM:1) */
    McuGpioPortInit(&pwmChannel1Pin);
    /* END Msg(MISRA_PWM:1) */
      
}/*--------------------------- End McuPwmInit() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: McuPwmStart()
**
** Description:
** Function to start PWM in the MCAL layer.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuPwmStart(void)
{
    /* Enable channel counter operation */
    TAUJ1.TS |= (TAUJ_CHANNEL1_COUNTER_START | TAUJ_CHANNEL0_COUNTER_START);


}/*--------------------------- End McuPwmStart() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: McuPwmStop()
**
** Description:
** Function to stop PWM in the MCAL layer.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuPwmStop(void)
{
    volatile uint32_t g_cg_sync_read;
    /* Disable channel counter operation */
      TAUJ1.TT |= (TAUJ_CHANNEL1_COUNTER_STOP | TAUJ_CHANNEL0_COUNTER_STOP);
    /* Synchronization processing */
    g_cg_sync_read = TAUJ1.TT;
    __syncp();
}/*--------------------------- End McuPwmStop() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuPwmSetOutputMode()
**
** Description:
** Function to configure the output mode setting of timer channels
**
** Arguments:
** 1. pwmChannelEnable		: enables or disables independent channel output mode.
** 2. pwmChannelOutputMode	: specify output mode of each channel.
** 3. pwmChannelOutputConfig	: specify output mode of each channel.
** 4. channelOutLogic		: specify the output logic of channel output bit.
** 5. deadTimeControl		: enables or disables dead time operation for each channel.
** 6. deadTimerPhase		: selects the phase period to which dead time is added.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuPwmSetOutputMode(
	uint16_t pwmChannelEnable,
	uint16_t pwmChannelOutputMode, 
	uint16_t pwmChannelOutputConfig,
	uint16_t channelOutLogic, 
	uint16_t deadTimeControl,
	uint16_t deadTimerPhase
	)
{
    /* Channel Output mode setting */	
    /* 
     -> Enable or disable independent channel output mode.
     -> Set the output mode of the channel.
     -> Set the output logic of the channel.
     -> Enable or diable the dead time operation.
     -> Sets the phase period to which dead time is added.

     Nb:- bitwise |= is used to set the bit and &= is used to clear the bit.
     !!!! Pay Attention To The Bitwise Operations While Making Any Changes In The Code To Prevent Unintensional Behaviour !!!!
     */
    TAUJ1.TOE |= pwmChannelEnable;			
    TAUJ1.TOM |= pwmChannelOutputMode;		
    TAUJ1.TOC &= pwmChannelOutputConfig;		
    TAUJ1.TOL &= channelOutLogic;			
/*    TAUJ1.TDE &= deadTimeControl;			
 -     TAUJ1.TDL &= deadTimerPhase;			*/

}/*--------------------------- End McuPwmSetOutputMode() -----------------------*/



/*--------------------------- End McuPwm.c -----------------------------*/
