/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: McalPwm.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for PWM Module.
**---------------------------------------------------------------------------*/
#ifndef MCU_PWM_H
#define MCU_PWM_H

#include "McuTypedefs.h"	
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/* TAUJn Channel Output Level Register (TAUJnTOL) */
typedef enum MCU_PWM_SLAVE_CHANNEL_OUTPUT_LEVEL			/* Configuring the active output level of the channel */
{
    /* Specifies the output logic of channel 7 output bit (TAUJnTOL7) */
    PWM_CHANNEL7_POSITIVE_LOGIC            =           (0xFF7FU), /* Positive logic */
    PWM_CHANNEL7_NEGATIVE_LOGIC            =           (0x0080U), /* Negative logic */
    /* Specifies the output logic of channel 5 output bit (TAUJnTOL5) */
    PWM_CHANNEL5_POSITIVE_LOGIC            =           (0xFFDFU), /* Positive logic */
    PWM_CHANNEL5_NEGATIVE_LOGIC            =           (0x0020U), /* Negative logic */
    /* Specifies the output logic of channel 3 output bit (TAUJnTOL3) */
    PWM_CHANNEL3_POSITIVE_LOGIC            =           (0xFFF7U), /* Positive logic */
    PWM_CHANNEL3_NEGATIVE_LOGIC            =           (0x0008U), /* Negative logic */
    /* Specifies the output logic of channel 1 output bit (TAUJnTOL1) */
    PWM_CHANNEL1_POSITIVE_LOGIC            =           (0xFFFDU), /* Positive logic */
    PWM_CHANNEL1_NEGATIVE_LOGIC            =           (0x0002U), /* Negative logic */
    /* Specifies the output logic of channel 0 output bit (TAUJnTOL0) */
    PWM_CHANNEL0_POSITIVE_LOGIC            =          (0xFFFEU), /* Positive logic */
    PWM_CHANNEL0_NEGATIVE_LOGIC            =          (0x0001U) /* Negative logic */
}McuPwmOutputLogic;

/*Structure to store the channel configuration*/
typedef struct MCU_PWM_CONFIG_CHANNEL
{
    McuPwmOutputLogic activeOutputLevel;
    uint16_t cmpValue;		/*Channel compare value*/
}McuPwmChannelConfig;

/*Structure to store the PWM configuration*/
typedef struct MCU_PWM_CONFIG_STRUCT
{
    uint16_t masterCmpValue;	/*Master channel compare value*/
    McuPwmChannelConfig channel1;	/*Channel 1 configuration*/
}McuPwmConfig;
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/ 
extern void McuPwmInit		(McuPwmConfig *pMcuPwmConfig);
extern void McuPwmStart		(void);
extern void McuPwmStop		(void);
#endif //MCU_PWM_H

/*--------------------------- End Mcupwm.h -----------------------------*/
