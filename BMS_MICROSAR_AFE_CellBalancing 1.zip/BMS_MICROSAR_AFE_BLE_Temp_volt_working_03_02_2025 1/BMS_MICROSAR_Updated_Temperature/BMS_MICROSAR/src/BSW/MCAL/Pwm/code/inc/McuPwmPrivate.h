/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: McuPwmPrivates.h
**
** Description:
** Header file containing private macros for PWM module configuration.
**---------------------------------------------------------------------------*/
#ifndef MCU_PWM_PRIVATE_H
#define MCU_PWM_PRIVATE_H

#include "McuMacroDriver.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018, 2022 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : r_cg_tauj.h
* Version          : 1.0.111
* Device(s)        : R7F701690
* Description      : General header file for TAUJ peripheral.
***********************************************************************************************************************/

#ifndef TAUJ_H
#define TAUJ_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
/*
    TAUJTTINm Input Signal Selection Register (SELB_TAUJ0I)
*/
/* Selection of  channel 3 input signal (SELB_TAUJ0I1,SELB_TAUJ0I3) */
#define TAUJ0_CHANNEL3_INPUT_TAUJ0I3                   (0x00U) /* Port TAUJ0I3 */
#define TAUJ0_CHANNEL3_INPUT_RTCA0OUT                  (0x02U) /* Timer Input-RTCA0OUT */
#define TAUJ0_CHANNEL3_INPUT_TAUJ1OUT0                 (0x0AU) /* Timer Input-TAUJ1 TAUJTTOUT0*/
#define TAUJ0_CHANNEL3_INPUT_CLEAR                     (0xF5U) /* Channel3 input clear */
/* Selection of  channel 2 input signal (SELB_TAUJ0I0,SELB_TAUJ0I2) */
#define TAUJ0_CHANNEL2_INPUT_TAUJ0I2                   (0x00U) /* Port TAUJ0I2 */
#define TAUJ0_CHANNEL2_INPUT_RTCA0OUT                  (0x01U) /* Timer Input-RTCA0OUT */
#define TAUJ0_CHANNEL2_INPUT_TAUJ1OUT0                 (0x05U) /* Timer Input-TAUJ1 TAUJTTOUT0*/
#define TAUJ0_CHANNEL2_INPUT_CLEAR                     (0xFAU) /* Channel2 input clear */
/*
    TAUJTTINm Input Signal Selection Register (SELB_TAUJ2I)
*/
/* Selection of  channel 3 input signal (SELB_TAUJ2I1) */
#define TAUJ2_CHANNEL3_INPUT_TAUJ2I3                   (0xFDU) /* Port TAUJ2I3 */
#define TAUJ2_CHANNEL3_INPUT_TAUJ3OUT0                 (0x02U) /* TAUJ3 TAUJTTOUT0*/
/* Selection of  channel 2 input signal (SELB_TAUJ2I0) */
#define TAUJ2_CHANNEL2_INPUT_TAUJ2I2                   (0xFEU) /* Port TAUJ2I2 */
#define TAUJ2_CHANNEL2_INPUT_TAUJ3OUT0                 (0x01U) /* TAUJ3 TAUJTTOUT0*/

/*
    TAUJn Prescaler Clock Select Register (TAUJnTPS)
*/
/* Operating mode selection (TAUJnPRS3[3-0]) */
#define TAUJ_CK3_PRE_PCLK_0                            (0x0000U) /* CK3_PRE - PCLK/2^0 */
#define TAUJ_CK3_PRE_PCLK_1                            (0x1000U) /* CK3_PRE - PCLK/2^1 */
#define TAUJ_CK3_PRE_PCLK_2                            (0x2000U) /* CK3_PRE - PCLK/2^2 */
#define TAUJ_CK3_PRE_PCLK_3                            (0x3000U) /* CK3_PRE - PCLK/2^3 */
#define TAUJ_CK3_PRE_PCLK_4                            (0x4000U) /* CK3_PRE - PCLK/2^4 */
#define TAUJ_CK3_PRE_PCLK_5                            (0x5000U) /* CK3_PRE - PCLK/2^5 */
#define TAUJ_CK3_PRE_PCLK_6                            (0x6000U) /* CK3_PRE - PCLK/2^6 */
#define TAUJ_CK3_PRE_PCLK_7                            (0x7000U) /* CK3_PRE - PCLK/2^7 */
#define TAUJ_CK3_PRE_PCLK_8                            (0x8000U) /* CK3_PRE - PCLK/2^8 */
#define TAUJ_CK3_PRE_PCLK_9                            (0x9000U) /* CK3_PRE - PCLK/2^9 */
#define TAUJ_CK3_PRE_PCLK_10                           (0xA000U) /* CK3_PRE - PCLK/2^10 */
#define TAUJ_CK3_PRE_PCLK_11                           (0xB000U) /* CK3_PRE - PCLK/2^11 */
#define TAUJ_CK3_PRE_PCLK_12                           (0xC000U) /* CK3_PRE - PCLK/2^12 */
#define TAUJ_CK3_PRE_PCLK_13                           (0xD000U) /* CK3_PRE - PCLK/2^13 */
#define TAUJ_CK3_PRE_PCLK_14                           (0xE000U) /* CK3_PRE - PCLK/2^14 */
#define TAUJ_CK3_PRE_PCLK_15                           (0xF000U) /* CK3_PRE - PCLK/2^15 */
#define TAUJ_CK3_PRS_CLEAR                             (0x0FFFU) /* CK30_PRE - clear */
/* Operating mode selection (TAUJnPRS2[3-0]) */
#define TAUJ_CK2_PRE_PCLK_0                            (0x0000U) /* CK2_PRE - PCLK/2^0 */
#define TAUJ_CK2_PRE_PCLK_1                            (0x0100U) /* CK2_PRE - PCLK/2^1 */
#define TAUJ_CK2_PRE_PCLK_2                            (0x0200U) /* CK2_PRE - PCLK/2^2 */
#define TAUJ_CK2_PRE_PCLK_3                            (0x0300U) /* CK2_PRE - PCLK/2^3 */
#define TAUJ_CK2_PRE_PCLK_4                            (0x0400U) /* CK2_PRE - PCLK/2^4 */
#define TAUJ_CK2_PRE_PCLK_5                            (0x0500U) /* CK2_PRE - PCLK/2^5 */
#define TAUJ_CK2_PRE_PCLK_6                            (0x0600U) /* CK2_PRE - PCLK/2^6 */
#define TAUJ_CK2_PRE_PCLK_7                            (0x0700U) /* CK2_PRE - PCLK/2^7 */
#define TAUJ_CK2_PRE_PCLK_8                            (0x0800U) /* CK2_PRE - PCLK/2^8 */
#define TAUJ_CK2_PRE_PCLK_9                            (0x0900U) /* CK2_PRE - PCLK/2^9 */
#define TAUJ_CK2_PRE_PCLK_10                           (0x0A00U) /* CK2_PRE - PCLK/2^10 */
#define TAUJ_CK2_PRE_PCLK_11                           (0x0B00U) /* CK2_PRE - PCLK/2^11 */
#define TAUJ_CK2_PRE_PCLK_12                           (0x0C00U) /* CK2_PRE - PCLK/2^12 */
#define TAUJ_CK2_PRE_PCLK_13                           (0x0D00U) /* CK2_PRE - PCLK/2^13 */
#define TAUJ_CK2_PRE_PCLK_14                           (0x0E00U) /* CK2_PRE - PCLK/2^14 */
#define TAUJ_CK2_PRE_PCLK_15                           (0x0F00U) /* CK2_PRE - PCLK/2^15 */
#define TAUJ_CK2_PRS_CLEAR                             (0xF0FFU) /* CK2_PRE - clear */
/* Operating mode selection (TAUJnPRS1[3-0]) */
#define TAUJ_CK1_PRE_PCLK_0                            (0x0000U) /* CK1_PRE - PCLK/2^0 */
#define TAUJ_CK1_PRE_PCLK_1                            (0x0010U) /* CK1_PRE - PCLK/2^1 */
#define TAUJ_CK1_PRE_PCLK_2                            (0x0020U) /* CK1_PRE - PCLK/2^2 */
#define TAUJ_CK1_PRE_PCLK_3                            (0x0030U) /* CK1_PRE - PCLK/2^3 */
#define TAUJ_CK1_PRE_PCLK_4                            (0x0040U) /* CK1_PRE - PCLK/2^4 */
#define TAUJ_CK1_PRE_PCLK_5                            (0x0050U) /* CK1_PRE - PCLK/2^5 */
#define TAUJ_CK1_PRE_PCLK_6                            (0x0060U) /* CK1_PRE - PCLK/2^6 */
#define TAUJ_CK1_PRE_PCLK_7                            (0x0070U) /* CK1_PRE - PCLK/2^7 */
#define TAUJ_CK1_PRE_PCLK_8                            (0x0080U) /* CK1_PRE - PCLK/2^8 */
#define TAUJ_CK1_PRE_PCLK_9                            (0x0090U) /* CK1_PRE - PCLK/2^9 */
#define TAUJ_CK1_PRE_PCLK_10                           (0x00A0U) /* CK1_PRE - PCLK/2^10 */
#define TAUJ_CK1_PRE_PCLK_11                           (0x00B0U) /* CK1_PRE - PCLK/2^11 */
#define TAUJ_CK1_PRE_PCLK_12                           (0x00C0U) /* CK1_PRE - PCLK/2^12 */
#define TAUJ_CK1_PRE_PCLK_13                           (0x00D0U) /* CK1_PRE - PCLK/2^13 */
#define TAUJ_CK1_PRE_PCLK_14                           (0x00E0U) /* CK1_PRE - PCLK/2^14 */
#define TAUJ_CK1_PRE_PCLK_15                           (0x00F0U) /* CK1_PRE - PCLK/2^15 */
#define TAUJ_CK1_PRS_CLEAR                             (0xFF0FU) /* CK1_PRE - clear */
/* Operating mode selection (TAUJnPRS0[3-0]) */
#define TAUJ_CK0_PRE_PCLK_0                            (0x0000U) /* CK0_PRE - PCLK/2^0 */
#define TAUJ_CK0_PRE_PCLK_1                            (0x0001U) /* CK0_PRE - PCLK/2^1 */
#define TAUJ_CK0_PRE_PCLK_2                            (0x0002U) /* CK0_PRE - PCLK/2^2 */
#define TAUJ_CK0_PRE_PCLK_3                            (0x0003U) /* CK0_PRE - PCLK/2^3 */
#define TAUJ_CK0_PRE_PCLK_4                            (0x0004U) /* CK0_PRE - PCLK/2^4 */
#define TAUJ_CK0_PRE_PCLK_5                            (0x0005U) /* CK0_PRE - PCLK/2^5 */
#define TAUJ_CK0_PRE_PCLK_6                            (0x0006U) /* CK0_PRE - PCLK/2^6 */
#define TAUJ_CK0_PRE_PCLK_7                            (0x0007U) /* CK0_PRE - PCLK/2^7 */
#define TAUJ_CK0_PRE_PCLK_8                            (0x0008U) /* CK0_PRE - PCLK/2^8 */
#define TAUJ_CK0_PRE_PCLK_9                            (0x0009U) /* CK0_PRE - PCLK/2^9 */
#define TAUJ_CK0_PRE_PCLK_10                           (0x000AU) /* CK0_PRE - PCLK/2^10 */
#define TAUJ_CK0_PRE_PCLK_11                           (0x000BU) /* CK0_PRE - PCLK/2^11 */
#define TAUJ_CK0_PRE_PCLK_12                           (0x000CU) /* CK0_PRE - PCLK/2^12 */
#define TAUJ_CK0_PRE_PCLK_13                           (0x000DU) /* CK0_PRE - PCLK/2^13 */
#define TAUJ_CK0_PRE_PCLK_14                           (0x000EU) /* CK0_PRE - PCLK/2^14 */
#define TAUJ_CK0_PRE_PCLK_15                           (0x000FU) /* CK0_PRE - PCLK/2^15 */
#define TAUJ_CK0_PRS_CLEAR                             (0xFFF0U) /* CK0_PRE - clear */

/*
    TAUJm Channel Mode OS Register (TAUJmCMORn)
*/
/* Selection of operation clock (TAUJmCKS[1-0]) */
#define TAUJ_SELECTION_CK0                             (0x0000U) /* CK0 */
#define TAUJ_SELECTION_CK1                             (0x4000U) /* CK1 */
#define TAUJ_SELECTION_CK2                             (0x8000U) /* CK2 */
#define TAUJ_SELECTION_CK3                             (0xC000U) /* CK3 */
/* Selects a count clock for TAUJmCNTn counter (TAUJmCCS[1-0]) */
#define TAUJ_COUNT_CLOCK_PCLK                          (0x0000U) /* Operation clock specified by TAUJmCMORn.TAUJmCKS[1:0] */
/* A mster channel or slave channel (TAUJmMAS) */
#define TAUJ_INDEPENDENT_CHANNEL                       (0x0000U) /* Slave */
#define TAUJ_SLAVE_CHANNEL                             (0x0000U) /* Slave */
#define TAUJ_MASTER_CHANNEL                            (0x0800U) /* Master */
/* Selects an external start trigger (TAUJmSTS[2-0]) */
#define TAUJ_START_TRIGGER_SOFTWARE                    (0x0000U) /* Software trigger */
#define TAUJ_START_TRIGGER_VALID_EDGE                  (0x0100U) /* Valid edge of TAUJTTINn input signal */
#define TAUJ_START_STOP_TRIGGER_VALID_EDGE             (0x0200U) /* Valid edge of TAUJTTINn input signal is used as a start trigger */
#define TAUJ_START_TRIGGER_MASTER_INT                  (0x0400U) /* INT of master channel */
/* Specifies the timing for updating capture register (TAUJmCOS[1-0]) */
#define TAUJ_OVERFLOW_AUTO_CLEAR                       (0x0000U) /* TAUJmCDRn update upon detection of edge of TAUJTTINm and TAUJnOVF update */
#define TAUJ_OVERFLOW_MANUAL_CLEAR                     (0x0040U) /* TAUJmCDRn update upon detection of edge of TAUJTTINm and TAUJnOVF is set */
#define TAUJ_OVERFLOW_COUNT_STOP                       (0x0080U) /* TAUJmCDRn update upon detection of edge of TAUJTTINm and TAUJnOVF is not set */
#define TAUJ_OVERFLOW_COUNT_STOP_MANUAL_CLEAR          (0x00C0U) /* TAUJmCDRn update upon detection of edge of TAUJTTINm and TAUJnOVF is set */
/* Specifies an operating mode (TAUJmMD[4-1]) */
#define TAUJ_INTERVAL_TIMER_MODE                       (0x0000U) /* Interval timer mode */
#define TAUJ_CAPTURE_MODE                              (0x0004U) /* Capture mode */
#define TAUJ_ONE_COUNT_MODE                            (0x0008U) /* One-count mode */
#define TAUJ_CAPTURE_ONE_COUNT_MODE                    (0x000CU) /* Capture and one-count mode */
#define TAUJ_COUNT_CAPTURE_MODE                        (0x0016U) /* Count capture mode  */
#define TAUJ_GATE_COUNT_MODE                           (0x0018U) /* Gate count mode */
#define TAUJ_CAPTURE_AND_GATE_COUNT_MODE               (0x001AU) /* Capture and gate count mode  */
/* Role of TAUJ0MD0 Bit (TAUJmMD0) */
#define TAUJ_START_INT_NOT_GENERATED                   (0x0000U) /* INTTAUJ0Im is not generated */
#define TAUJ_START_TRIGGER_DISABLE                     (0x0000U) /* Disables detection. */
#define TAUJ_START_INT_GENERATED                       (0x0001U) /* INTTAUJ0Im is generated */
#define TAUJ_START_TRIGGER_ENABLE                      (0x0001U) /* Enables detection. */

/*
    TAUJm Channel Mode User Register (TAUJmCMURn)
*/
/* Specifies a valid edge of TAUJTTINn input signal (TAUJmTIS[1-0]) */
#define TAUJ_INPUT_EDGE_FALLING                        (0x00U) /* Falling edge */
#define TAUJ_INPUT_EDGE_UNUSED                         (0x00U) /* Unused Falling edge */
#define TAUJ_INPUT_EDGE_RISING                         (0x01U) /* Rising edge */
#define TAUJ_INPUT_EDGE_BOTH_MEASURE_LOW               (0x02U) /* Detection of rising and falling edges (selects low width measurement) */
#define TAUJ_INPUT_EDGE_BOTH_MEASURE_HIGH              (0x03U) /* Detection of rising and falling edges (selects high width measurement) */

/*
    TAUJm Channel Start Trigger Register (TAUJmTS)
*/
/* Enables the counter operation of channel 3 (TAUJmTS3) */
#define TAUJ_CHANNEL3_COUNTER_START                    (0x08U) /* Enables the counter operation */
/* Enables the counter operation of channel 2 (TAUJmTS2) */
#define TAUJ_CHANNEL2_COUNTER_START                    (0x04U) /* Enables the counter operation */
/* Enables the counter operation of channel 1 (TAUJmTS1) */
#define TAUJ_CHANNEL1_COUNTER_START                    (0x02U) /* Enables the counter operation */
/* Enables the counter operation of channel 0 (TAUJmTS0) */
#define TAUJ_CHANNEL0_COUNTER_START                    (0x01U) /* Enables the counter operation */

/*
    TAUJm Channel Stop Trigger Register (TAUJmTT)
*/
/* Stops the counter operation of channel 3 (TAUJmTT3) */
#define TAUJ_CHANNEL3_COUNTER_STOP                     (0x08U) /* Stops the counter operation and resets TAUJmTE.TAUJmTEm */
/* Stops the counter operation of channel 2 (TAUJmTT2) */
#define TAUJ_CHANNEL2_COUNTER_STOP                     (0x04U) /* Stops the counter operation and resets TAUJmTE.TAUJmTEm */
/* Stops the counter operation of channel 1 (TAUJmTT1) */
#define TAUJ_CHANNEL1_COUNTER_STOP                     (0x02U) /* Stops the counter operation and resets TAUJmTE.TAUJmTEm */
/* Stops the counter operation of channel 0 (TAUJmTT0) */
#define TAUJ_CHANNEL0_COUNTER_STOP                     (0x01U) /* Stops the counter operation and resets TAUJmTE.TAUJmTEm */

/*
    TAUJm Channel Output Enable Register (TAUJmTOE)
*/
/* Enables/disables the independent channel output function (TAUJmTOE3) */
#define TAUJ_CHANNEL3_DISABLES_OUTPUT_MODE             (0xF7U) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL3_ENABLES_OUTPUT_MODE              (0x08U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJmTOE2) */
#define TAUJ_CHANNEL2_DISABLES_OUTPUT_MODE             (0xFBU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL2_ENABLES_OUTPUT_MODE              (0x04U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJmTOE1) */
#define TAUJ_CHANNEL1_DISABLES_OUTPUT_MODE             (0xFDU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL1_ENABLES_OUTPUT_MODE              (0x02U) /* Enables the independent timer output function */
/* Enables/disables the independent channel output function (TAUJmTOE0) */
#define TAUJ_CHANNEL0_DISABLES_OUTPUT_MODE             (0xFEU) /* Disables the independent timer output function (controlled by software) */
#define TAUJ_CHANNEL0_ENABLES_OUTPUT_MODE              (0x01U) /* Enables the independent timer output function */

/*
    TAUJm Channel Output Mode Register (TAUJmTOM)
*/
/* Specifies an output mode (TAUJmTOM3) */
#define TAUJ_CHANNEL3_INDEPENDENT_OPERATION            (0xF7U) /* Independent channel operation */
#define TAUJ_CHANNEL3_SYNCHRONOUS_OPERATION            (0x08U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJmTOM2) */
#define TAUJ_CHANNEL2_INDEPENDENT_OPERATION            (0xFBU) /* Independent channel operation */
#define TAUJ_CHANNEL2_SYNCHRONOUS_OPERATION            (0x04U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJmTOM1) */
#define TAUJ_CHANNEL1_INDEPENDENT_OPERATION            (0xFDU) /* Independent channel operation */
#define TAUJ_CHANNEL1_SYNCHRONOUS_OPERATION            (0x02U) /* Synchronous channel operation */
/* Specifies an output mode (TAUJmTOM0) */
#define TAUJ_CHANNEL0_INDEPENDENT_OPERATION            (0xFEU) /* Independent channel operation */
#define TAUJ_CHANNEL0_SYNCHRONOUS_OPERATION            (0x01U) /* Synchronous channel operation */

/*
    TAUJn Channel Output Configuration Register (TAUJnTOC)
*/
/* Specifies the output mode (TAUJnTOC3) */
#define TAUJ_CHANNEL3_OPERATION_MODE1                  (0xF7U) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC2) */
#define TAUJ_CHANNEL2_OPERATION_MODE1                  (0xFBU) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC1) */
#define TAUJ_CHANNEL1_OPERATION_MODE1                  (0xFDU) /* Operation mode 1 */
/* Specifies the output mode (TAUJnTOC0) */
#define TAUJ_CHANNEL0_OPERATION_MODE1                  (0xFEU) /* Operation mode 1 */

/*
    TAUJm Channel Output Level Register (TAUJmTOL)
*/
/* Specifies the output logic of channel 3 output bit (TAUJmTOL3) */
#define TAUJ_CHANNEL3_POSITIVE_LOGIC                   (0xF7U) /* Positive logic */
#define TAUJ_CHANNEL3_NEGATIVE_LOGIC                   (0x08U) /* Negative logic */
/* Specifies the output logic of channel 2 output bit (TAUJmTOL2) */
#define TAUJ_CHANNEL2_POSITIVE_LOGIC                   (0xFBU) /* Positive logic */
#define TAUJ_CHANNEL2_NEGATIVE_LOGIC                   (0x04U) /* Negative logic */
/* Specifies the output logic of channel 1 output bit (TAUJmTOL1) */
#define TAUJ_CHANNEL1_POSITIVE_LOGIC                   (0xFDU) /* Positive logic */
#define TAUJ_CHANNEL1_NEGATIVE_LOGIC                   (0x02U) /* Negative logic */
/* Specifies the output logic of channel 0 output bit (TAUJmTOL0) */
#define TAUJ_CHANNEL0_POSITIVE_LOGIC                   (0xFEU) /* Positive logic */
#define TAUJ_CHANNEL0_NEGATIVE_LOGIC                   (0x01U) /* Negative logic */

/*
    TAUJn Channel Status Clear Register(TAUJnCSCm)
*/
/* Clearing the overflow flag TAUJnCSRm.TAUJnOVF of channel m(TAUJnCLOV) */
#define TAUJ_OVERFLOW_FLAG_CLEAR                       (0x01U) /* Clears overflow flag */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define TAUJ_OVERFLOW_OCCURS                           (0x01U) /* Overflow occurs */
#define TAUJ_OVERFLOW_VALUE                            (0x100000000ULL) /* Overflow value */
#define TAUJ_FILTER_ENABLED                            (0x01U) /* Digital Noise Elimination Enable Control */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* Specifies a valid edge of TAUBTTINm input signal (TAUBnTIS[1-0]) */
#define PWM_INPUT_EDGE_UNUSED                             (0x00U) /* Unused Falling edge */
#define PWM_INPUT_EDGE_FALLING                            (0x00U) /* Falling edge */
#define PWM_INPUT_EDGE_RISING                             (0x01U) /* Rising edge */
#define PWM_INPUT_EDGE_BOTH_MEASURE_LOW                   (0x02U) /* Selects low width measurement */
#define PWM_INPUT_EDGE_BOTH_MEASURE_HIGH                  (0x03U) /* Selects high width measurement */

/*
    TAUBn Channel Start Trigger Register (TAUBnTS)
*/
/* Enables the counter operation of channel 7 (TAUBnTS07) */
#define PWM_CHANNEL7_COUNTER_START                        (0x0080U) /* Enables the counter operation */
/* Enables the counter operation of channel 5 (TAUBnTS05) */
#define PWM_CHANNEL5_COUNTER_START                        (0x0020U) /* Enables the counter operation */
/* Enables the counter operation of channel 3 (TAUBnTS03) */
#define PWM_CHANNEL3_COUNTER_START                        (0x0008U) /* Enables the counter operation */
/* Enables the counter operation of channel 1 (TAUBnTS01) */
#define PWM_CHANNEL1_COUNTER_START                        (0x0002U) /* Enables the counter operation */
/* Enables the counter operation of channel 0 (TAUBnTS00) */
#define PWM_CHANNEL0_COUNTER_START                        (0x0001U) /* Enables the counter operation */

/*
    TAUBn Channel Stop Trigger Register (TAUBnTT)
*/
/* Stops the counter operation of channel 7 (TAUBnTT7) */
#define PWM_CHANNEL7_COUNTER_STOP                         (0x0080U) /* Stops the counter operation */
/* Stops the counter operation of channel 5 (TAUBnTT5) */
#define PWM_CHANNEL5_COUNTER_STOP                         (0x0020U) /* Stops the counter operation */
/* Stops the counter operation of channel 3 (TAUBnTT3) */
#define PWM_CHANNEL3_COUNTER_STOP                         (0x0008U) /* Stops the counter operation */
/* Stops the counter operation of channel 1 (TAUBnTT1) */
#define PWM_CHANNEL1_COUNTER_STOP                         (0x0002U) /* Stops the counter operation */
/* Stops the counter operation of channel 0 (TAUBnTT0) */
#define PWM_CHANNEL0_COUNTER_STOP                         (0x0001U) /* Stops the counter operation */

/*
    TAUBn Channel Reload Data Enable Register (TAUBnRDE)
*/
/* Enables/disables simultaneous rewrite of the data register of channel 7 (TAUBnRDE7) */
#define PWM_CHANNEL7_DISABLES_REWRITE_MODE                (0xFF7FU) /* Disables simultaneous rewrite */
#define PWM_CHANNEL7_ENABLES_REWRITE_MODE                 (0x0080U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel 5 (TAUBnRDE5) */
#define PWM_CHANNEL5_DISABLES_REWRITE_MODE                (0xFFDFU) /* Disables simultaneous rewrite */
#define PWM_CHANNEL5_ENABLES_REWRITE_MODE                 (0x0020U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel 3 (TAUBnRDE3) */
#define PWM_CHANNEL3_DISABLES_REWRITE_MODE                (0xFFF7U) /* Disables simultaneous rewrite */
#define PWM_CHANNEL3_ENABLES_REWRITE_MODE                 (0x0008U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel 1 (TAUBnRDE1) */
#define PWM_CHANNEL1_DISABLES_REWRITE_MODE                (0xFFFDU) /* Disables simultaneous rewrite */
#define PWM_CHANNEL1_ENABLES_REWRITE_MODE                 (0x0002U) /* Enables simultaneous rewrite */
/* Enables/disables simultaneous rewrite of the data register of channel 0 (TAUBnRDE0) */
#define PWM_CHANNEL0_DISABLES_REWRITE_MODE                (0xFFFEU) /* Disables simultaneous rewrite */
#define PWM_CHANNEL0_ENABLES_REWRITE_MODE                (0x0001U) /* Enables simultaneous rewrite */

/*
    TAUBn Channel Reload Data Control Channel Select Register (TAUBnRDS)
*/
/* Specifies which channel is controlled for the simultaneous rewrite trigger (TAUBnRDS7) */
#define PWM_CHANNEL7_MASTER_REWRITE_CTRL                  (0xFF7FU) /* Master channel */
#define PWM_CHANNEL7_OTHER_REWRITE_CTRL                   (0x0080U) /* Another upper channel */
/* Specifies which channel is controlled for the simultaneous rewrite trigger (TAUBnRDS5) */
#define PWM_CHANNEL5_MASTER_REWRITE_CTRL                  (0xFFDFU) /* Master channel */
#define PWM_CHANNEL5_OTHER_REWRITE_CTRL                   (0x0020U) /* Another upper channel */
/* Specifies which channel is controlled for the simultaneous rewrite trigger (TAUBnRDS3) */
#define PWM_CHANNEL3_MASTER_REWRITE_CTRL                  (0xFFF7U) /* Master channel */
#define PWM_CHANNEL3_OTHER_REWRITE_CTRL                   (0x0008U) /* Another upper channel */
/* Specifies which channel is controlled for the simultaneous rewrite trigger (TAUBnRDS1) */
#define PWM_CHANNEL1_MASTER_REWRITE_CTRL                  (0xFFFDU) /* Master channel */
#define PWM_CHANNEL1_OTHER_REWRITE_CTRL                   (0x0002U) /* Another upper channel */
/* Specifies which channel is controlled for the simultaneous rewrite trigger (TAUBnRDS0) */
#define PWM_CHANNEL0_MASTER_REWRITE_CTRL                  (0xFFFEU) /* Master channel */
#define PWM_CHANNEL0_OTHER_REWRITE_CTRL                  (0x0001U) /* Another upper channel */

/*
    TAUBn Channel Reload Data Mode Register (TAUBnRDM)
*/
/*Selects when the signal that triggers simultaneous rewrite is generated (TAUBnRDM7) */
#define PWM_CHANNEL7_MASTER_START_RELOAD_MODE             (0xFF7FU) /* The master channel counter starts counting */
#define PWM_CHANNEL7_TOP_CYC_RELOAD_MODE                  (0x0080U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated (TAUBnRDM5) */
#define PWM_CHANNEL5_MASTER_START_RELOAD_MODE             (0xFFDFU) /* The master channel counter starts counting */
#define PWM_CHANNEL5_TOP_CYC_RELOAD_MODE                  (0x0020U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated (TAUBnRDM3) */
#define PWM_CHANNEL3_MASTER_START_RELOAD_MODE             (0xFFF7U) /* The master channel counter starts counting */
#define PWM_CHANNEL3_TOP_CYC_RELOAD_MODE                  (0x0008U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated (TAUBnRDM1) */
#define PWM_CHANNEL1_MASTER_START_RELOAD_MODE             (0xFFFDU) /* The master channel counter starts counting */
#define PWM_CHANNEL1_TOP_CYC_RELOAD_MODE                  (0x0002U) /* At the top of a triangle wave cycle */
/*Selects when the signal that triggers simultaneous rewrite is generated (TAUBnRDM0) */
#define PWM_CHANNEL0_MASTER_START_RELOAD_MODE             (0xFFFEU) /* The master channel counter starts counting */
#define PWM_CHANNEL0_TOP_CYC_RELOAD_MODE                  (0x0001U) /* At the top of a triangle wave cycle */

/*
    TAUBn Channel Reload Data Control Register(TAUBnRDC)
*/
/*Specifies whether the channel generates a simultaneous rewrite trigger signal or not (TAUBnRDC7) */
#define PWM_CHANNEL7_TRIGGER_REWRITE_CTRL                 (0xFF7FU) /* Does not operate as a simultaneous rewrite */
#define PWM_CHANNEL7_NOT_TRIGGER_REWRITE_CTRL             (0x0080U) /* Operates as a simultaneous rewrite */
/*Specifies whether the channel generates a simultaneous rewrite trigger signal or not (TAUBnRDC5) */
#define PWM_CHANNEL5_TRIGGER_REWRITE_CTRL                 (0xFFDFU) /* Does not operate as a simultaneous rewrite */
#define PWM_CHANNEL5_NOT_TRIGGER_REWRITE_CTRL             (0x0020U) /* Operates as a simultaneous rewrite */
/*Specifies whether the channel generates a simultaneous rewrite trigger signal or not (TAUBnRDC3) */
#define PWM_CHANNEL3_TRIGGER_REWRITE_CTRL                 (0xFFF7U) /* Does not operate as a simultaneous rewrite */
#define PWM_CHANNEL3_NOT_TRIGGER_REWRITE_CTRL             (0x0008U) /* Operates as a simultaneous rewrite */
/*Specifies whether the channel generates a simultaneous rewrite trigger signal or not (TAUBnRDC1) */
#define PWM_CHANNEL1_TRIGGER_REWRITE_CTRL                 (0xFFFDU) /* Does not operate as a simultaneous rewrite */
#define PWM_CHANNEL1_NOT_TRIGGER_REWRITE_CTRL             (0x0002U) /* Operates as a simultaneous rewrite */
/*Specifies whether the channel generates a simultaneous rewrite trigger signal or not (TAUBnRDC0) */
#define PWM_CHANNEL0_TRIGGER_REWRITE_CTRL                 (0xFFFEU) /* Does not operate as a simultaneous rewrite */
#define PWM_CHANNEL0_NOT_TRIGGER_REWRITE_CTRL            (0x0001U) /* Operates as a simultaneous rewrite */

/*
    TAUBn Channel Output Enable Register (TAUBnTOE)
*/
/* Enables/disables the independent channel output function (TAUBnTOE7) */
#define PWM_CHANNEL7_DISABLES_OUTPUT_MODE                 (0xFF7FU) /* Disables independent channel output mode */
#define PWM_CHANNEL7_ENABLES_OUTPUT_MODE                  (0x0080U) /* Enables independent channel output mode */
/* Enables/disables the independent channel output function (TAUBnTOE5) */
#define PWM_CHANNEL5_DISABLES_OUTPUT_MODE                 (0xFFDFU) /* Disables independent channel output mode */
#define PWM_CHANNEL5_ENABLES_OUTPUT_MODE                  (0x0020U) /* Enables independent channel output mode */
/* Enables/disables the independent channel output function (TAUBnTOE3) */
#define PWM_CHANNEL3_DISABLES_OUTPUT_MODE                 (0xFFF7U) /* Disables independent channel output mode */
#define PWM_CHANNEL3_ENABLES_OUTPUT_MODE                  (0x0008U) /* Enables independent channel output mode */
/* Enables/disables the independent channel output function (TAUBnTOE1) */
#define PWM_CHANNEL1_DISABLES_OUTPUT_MODE                 (0xFFFDU) /* Disables independent channel output mode */
#define PWM_CHANNEL1_ENABLES_OUTPUT_MODE                  (0x0002U) /* Enables independent channel output mode */
/* Enables/disables the independent channel output function (TAUBnTOE0) */
#define PWM_CHANNEL0_DISABLES_OUTPUT_MODE                 (0xFFFEU) /* Disables independent channel output mode */
#define PWM_CHANNEL0_ENABLES_OUTPUT_MODE                  (0x0001U) /* Enables independent channel output mode */

/*
    TAUBn Channel Output Register (TAUBnTO)
*/
/* Specifies/reads the level of TAUBTTOUTm (TAUBnTO7) */
#define PWM_CHANNEL7_LOW_LEVEL                            (0xFF7FU) /* Low level */
#define PWM_CHANNEL7_HIGH_LEVEL                           (0x0080U) /* High level */
/* Specifies/reads the level of TAUBTTOUTm (TAUBnTO5) */
#define PWM_CHANNEL5_LOW_LEVEL                            (0xFFDFU) /* Low level */
#define PWM_CHANNEL5_HIGH_LEVEL                           (0x0020U) /* High level */
/* Specifies/reads the level of TAUBTTOUTm (TAUBnTO3) */
#define PWM_CHANNEL3_LOW_LEVEL                            (0xFFF7U) /* Low level */
#define PWM_CHANNEL3_HIGH_LEVEL                           (0x0008U) /* High level */
/* Specifies/reads the level of TAUBTTOUTm (TAUBnTO1) */
#define PWM_CHANNEL1_LOW_LEVEL                            (0xFFFDU) /* Low level */
#define PWM_CHANNEL1_HIGH_LEVEL                           (0x0002U) /* High level */
/* Specifies/reads the level of TAUBTTOUTm (TAUBnTO0) */
#define PWM_CHANNEL0_LOW_LEVEL                            (0xFFFEU) /* Low level */
#define PWM_CHANNEL0_HIGH_LEVEL                           (0x0001U) /* High level */

/*
    TAUBn Channel Output Mode Register (TAUBnTOM)
*/
/* Specifies the channel output mode (TAUBnTOM7) */
#define PWM_CHANNEL7_INDEPENDENT_OUTPUT_MODE              (0xFF7FU) /* Independent channel output mode */
#define PWM_CHANNEL7_SYNCHRONOUS_OUTPUT_MODE              (0x0080U) /* Synchronous channel output mode */
/* Specifies the channel output mode (TAUBnTOM5) */
#define PWM_CHANNEL5_INDEPENDENT_OUTPUT_MODE              (0xFFDFU) /* Independent channel output mode */
#define PWM_CHANNEL5_SYNCHRONOUS_OUTPUT_MODE              (0x0020U) /* Synchronous channel output mode */
/* Specifies the channel output mode (TAUBnTOM3) */
#define PWM_CHANNEL3_INDEPENDENT_OUTPUT_MODE              (0xFFF7U) /* Independent channel output mode */
#define PWM_CHANNEL3_SYNCHRONOUS_OUTPUT_MODE              (0x0008U) /* Synchronous channel output mode */
/* Specifies the channel output mode (TAUBnTOM1) */
#define PWM_CHANNEL1_INDEPENDENT_OUTPUT_MODE              (0xFFFDU) /* Independent channel output mode */
#define PWM_CHANNEL1_SYNCHRONOUS_OUTPUT_MODE              (0x0002U) /* Synchronous channel output mode */
/* Specifies the channel output mode (TAUBnTOM0) */
#define PWM_CHANNEL0_INDEPENDENT_OUTPUT_MODE              (0xFFFEU) /* Independent channel output mode */
#define PWM_CHANNEL0_SYNCHRONOUS_OUTPUT_MODE              (0x0001U) /* Synchronous channel output mode */

/*
    TAUBn Channel Output Configuration Register (TAUBnTOC)
*/
/* Specifies the output mode (TAUBnTOC7) */
#define PWM_CHANNEL7_OPERATION_MODE1                      (0xFF7FU) /* Operation mode 1 */
#define PWM_CHANNEL7_OPERATION_MODE2                      (0x0080U) /* Operation mode 2 */
/* Specifies the output mode (TAUBnTOC5) */
#define PWM_CHANNEL5_OPERATION_MODE1                      (0xFFDFU) /* Operation mode 1 */
#define PWM_CHANNEL5_OPERATION_MODE2                      (0x0020U) /* Operation mode 2 */
/* Specifies the output mode (TAUBnTOC3) */
#define PWM_CHANNEL3_OPERATION_MODE1                      (0xFFF7U) /* Operation mode 1 */
#define PWM_CHANNEL3_OPERATION_MODE2                      (0x0008U) /* Operation mode 2 */
/* Specifies the output mode (TAUBnTOC1) */
#define PWM_CHANNEL1_OPERATION_MODE1                      (0xFFFDU) /* Operation mode 1 */
#define PWM_CHANNEL1_OPERATION_MODE2                      (0x0002U) /* Operation mode 2 */
/* Specifies the output mode (TAUBnTOC0) */
#define PWM_CHANNEL0_OPERATION_MODE1                      (0xFFFEU) /* Operation mode 1 */
#define PWM_CHANNEL0_OPERATION_MODE2                      (0x0001U) /* Operation mode 2 */


/*
    TAUBn Channel Dead Time Output Enable Register (TAUBnTDE)
*/
/* Enables/disables the dead time control operation of channel 7 (TAUBnTDE7) */
#define PWM_CHANNEL7_DISABLE_DEAD_TIME_OPERATE            (0xFF7FU) /* Disables dead time operation */
#define PWM_CHANNEL7_ENABLE_DEAD_TIME_OPERATE             (0x0080U) /* Enables dead time operation */
/* Enables/disables the dead time control operation of channel 5 (TAUBnTDE5) */
#define PWM_CHANNEL5_DISABLE_DEAD_TIME_OPERATE            (0xFFDFU) /* Disables dead time operation */
#define PWM_CHANNEL5_ENABLE_DEAD_TIME_OPERATE             (0x0020U) /* Enables dead time operation */
/* Enables/disables the dead time control operation of channel 3 (TAUBnTDE3) */
#define PWM_CHANNEL3_DISABLE_DEAD_TIME_OPERATE            (0xFFF7U) /* Disables dead time operation */
#define PWM_CHANNEL3_ENABLE_DEAD_TIME_OPERATE             (0x0008U) /* Enables dead time operation */
/* Enables/disables the dead time control operation of channel 1 (TAUBnTDE1) */
#define PWM_CHANNEL1_DISABLE_DEAD_TIME_OPERATE            (0xFFFDU) /* Disables dead time operation */
#define PWM_CHANNEL1_ENABLE_DEAD_TIME_OPERATE             (0x0002U) /* Enables dead time operation */
/* Enables/disables the dead time control operation of channel 0 (TAUBnTDE0) */
#define PWM_CHANNEL0_DISABLE_DEAD_TIME_OPERATE            (0xFFFEU) /* Disables dead time operation */
#define PWM_CHANNEL0_ENABLE_DEAD_TIME_OPERATE             (0x0001U) /* Enables dead time operation */

/*
    TAUBn Channel Dead Time Output Level Register (TAUBnTDL)
*/
/* Selects a phase in which dead time is added (TAUBnTDL7) */
#define PWM_CHANNEL7_POSITIVE_PHASE_PERIOD                (0xFF7FU) /* Positive phase period */
#define PWM_CHANNEL7_NEGATIVE_PHASE_PERIOD                (0x0080U) /* Negative phase period */
/* Selects a phase in which dead time is added (TAUBnTDL5) */
#define PWM_CHANNEL5_POSITIVE_PHASE_PERIOD                (0xFFDFU) /* Positive phase period */
#define PWM_CHANNEL5_NEGATIVE_PHASE_PERIOD                (0x0020U) /* Negative phase period */
/* Selects a phase in which dead time is added (TAUBnTDL3) */
#define PWM_CHANNEL3_POSITIVE_PHASE_PERIOD                (0xFFF7U) /* Positive phase period */
#define PWM_CHANNEL3_NEGATIVE_PHASE_PERIOD                (0x0008U) /* Negative phase period */
/* Selects a phase in which dead time is added (TAUBnTDL1) */
#define PWM_CHANNEL1_POSITIVE_PHASE_PERIOD                (0xFFFDU) /* Positive phase period */
#define PWM_CHANNEL1_NEGATIVE_PHASE_PERIOD                (0x0002U) /* Negative phase period */
/* Selects a phase in which dead time is added (TAUBnTDL0) */
#define PWM_CHANNEL0_POSITIVE_PHASE_PERIOD                (0xFFFEU) /* Positive phase period */
#define PWM_CHANNEL0_NEGATIVE_PHASE_PERIOD                (0x0001U) /* Negative phase period */

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
/* Start user code for function. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
#endif
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
#define TAUJ1_CHANNEL0_COMPARE_VALUE                              (0x0001387FUL) /* Data register for compare values */
#define TAUJ1_CHANNEL1_COMPARE_VALUE                              (0x00009C40UL) /* Data register for compare values */
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/ 

#endif //MCU_PWM_PRIVATE_H

/*--------------------------- End McuPwmPrivate.h -----------------------------*/

/*--------------------------- End McuClmaPrivate.h -----------------------------*/
