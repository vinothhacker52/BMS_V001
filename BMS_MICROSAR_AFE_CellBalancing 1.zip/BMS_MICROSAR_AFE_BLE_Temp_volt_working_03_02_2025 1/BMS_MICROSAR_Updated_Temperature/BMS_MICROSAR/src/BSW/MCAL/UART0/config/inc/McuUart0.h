/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: McuAdc.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for CAN module.
**---------------------------------------------------------------------------*/
#ifndef MCU_UART_H
#define MCU_UART_H

#include "McuTypedefs.h"
#include <stdbool.h>
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define UART0_BAUD_RATE_PRESCALER                 (0x0U)

#define UART_NORMAL_MODE 0U
#define UART_REPLY_FRAME_MODE 1U
#define UART_RESPONSE_MODE    2U

#define UART_TX_TIMEOUT 100000
#define UART_RX_TIMEOUT 40000

typedef union MCU_UART_DATA_16 {
    uint16_t data16Bit;
    struct {
        uint8_t data1; // LSB
        uint8_t data2; // MSB
    } bytes;
} McuUartData16;

typedef union MCU_UART_ID_FRAME{
    struct __attribute__((packed)) {
    uint8_t ID : 6;
    uint8_t Res : 1;
    uint8_t WR_Bit : 1;
    }McuUartIdFullFrame;
    
    uint8_t idFrame;
}McuUartIdFrame;

typedef struct MCU_UART_READ_MSG {
    
    uint8_t syncData;
    McuUartIdFrame   idData;
    uint8_t address;
    uint8_t crcData;
    
}McuUartReadMsg;

typedef struct MCU_UART_READ_RESPONE {
 
    McuUartIdFrame   idData;
    uint8_t address;
    McuUartData16    data;
     uint8_t crcData;
}McuUartReadResponse;

typedef struct MCU_UART_WRITE_RESPONE {
    uint8_t syncData;
    McuUartIdFrame   idData;
    uint8_t address;
    McuUartData16    data;
    uint8_t crcData;
    
}McuUartWriteMsg;

typedef union MCU_UART_REPLY_FRAME{
    struct __attribute__((packed)) {
    uint8_t CRC : 3;
    uint8_t Status : 3;
    uint8_t Res : 2;
    }McuUartReplayFullFrame;
    
    uint8_t replayFrame;
    
}McuUartReplyFrame;

typedef struct MCU_UART_BUFFER_STS{
    bool ReadResponse;
    bool ReplyFrame;
    bool readResFlag;
    bool readRepFlag;
}McuUartBufferSts;

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern McuUartReadResponse pReadRspnsePtr;
extern McuUartReplyFrame pReplyFramePtr;
extern McuUartBufferSts UartCommonBufferSts;
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/



extern void McuUart0Init(void);
extern void McuUart0Start(void);
extern void McuUart0Stop(void);

extern MD_STATUS McuUart0Tx(uint8_t * const transmitBuffer, uint16_t dataLength);
extern MD_STATUS McuUart0Rx(void);

extern MD_STATUS McuUart0RxRdResponse(void);
extern MD_STATUS McuUart0SndRdMsg(McuUartReadMsg *pReadMsgPtr);

extern MD_STATUS McuUart0SndWrMsg(McuUartWriteMsg *pWriteMsgPtr);
extern MD_STATUS McuUart0WrReply(void);
extern MD_STATUS McuUart0RplyFrmeRd(void);

#endif /* MCU_CAN_H */

/*--------------------------- End McuCan.h -----------------------------*/

