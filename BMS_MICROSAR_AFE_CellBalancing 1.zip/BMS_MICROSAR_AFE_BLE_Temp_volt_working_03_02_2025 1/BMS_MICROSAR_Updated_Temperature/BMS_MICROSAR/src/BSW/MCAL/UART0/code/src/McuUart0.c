/*-----------------------------------------------------------------------------
**                           
** File: McuUart.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of the McuTauj3Ch1 module.
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include <string.h>
#include "McuUart0.h"
#include "McuUart0Private.h"
#include "McuMacroDriver.h"
#include "McuUserDefine.h"
#include "McuGpio.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/


/********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

volatile uint32_t g_cg_sync_read;
volatile uint8_t  McuUartRxBuffer[5];
McuUartBufferSts UartCommonBufferSts;
McuUartReadResponse pReadRspnsePtr = {0};
McuUartReplyFrame pReplyFramePtr = {0};
uint8_t txReadMsg[4] = {0};
uint8_t txWriteMsg[6] = {0};
uint8_t rxCount = 0;
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

/***********************************************************************************************************************
 * Function Name: McuUart0Init
 * Description  : This function initializes the Config_UART0 module.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart0Init(void)
{
    McuGpioPinConfig lin0Rx;
    McuGpioPinConfig lin0Tx;
    /* Set LIN reset mode */
    RLN30.LCUC = UART_LIN_RESET_MODE_CAUSED;
    /* Disable ICRLIN30UR0 operation and clear request */
    INTC2.ICRLIN30UR0.BIT.MKRLIN30UR0 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN30UR0.BIT.RFRLIN30UR0 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN30UR1 operation and clear request */
    INTC2.ICRLIN30UR1.BIT.MKRLIN30UR1 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN30UR1.BIT.RFRLIN30UR1 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN30UR2 operation and clear request */
    INTC2.ICRLIN30UR2.BIT.MKRLIN30UR2 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN30UR2.BIT.RFRLIN30UR2 = INT_REQUEST_NOT_OCCUR;
    /* Set ICRLIN30UR0 table method */
    INTC2.ICRLIN30UR0.BIT.TBRLIN30UR0 = INT_TABLE_VECTOR;
    /* Set ICRLIN30UR0 priority */
    INTC2.ICRLIN30UR0.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN30UR1 table method */
    INTC2.ICRLIN30UR1.BIT.TBRLIN30UR1 = INT_TABLE_VECTOR;
    /* Set ICRLIN30UR1 priority */
    INTC2.ICRLIN30UR1.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN30UR2 table method */
    INTC2.ICRLIN30UR2.BIT.TBRLIN30UR2 = INT_TABLE_VECTOR;
    /* Set ICRLIN30UR2 priority */
    INTC2.ICRLIN30UR2.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set UART0 setting */
    RLN30.LWBR = UART_10_SAMPLING | UART_PRESCALER_CLOCK_SELECT_4;
    RLN30.LBRP01.UINT16 = UART0_BAUD_RATE_PRESCALER;
    RLN30.LMD = UART_NOISE_FILTER_DISABLED | UART_MODE_SELECT;
    RLN30.LEDE = UART_FRAMING_ERROR_DETECTED | UART_OVERRUN_ERROR_DETECTED;
    RLN30.LBFC = UART_TRANSMISSION_NORMAL | UART_RECEPTION_NORMAL | UART_PARITY_PROHIBITED | UART_STOP_BIT_1 | 
	UART_MSB | UART_LENGTH_8;
    RLN30.LCUC = UART_LIN_RESET_MODE_CANCELED;
    /* Synchronization processing */
    g_cg_sync_read = RLN30.LCUC;
    __syncp();
#if 1
    /* Set RLIN30RX(P0_3) pin */
    lin0Rx.port                 = MCU_PORT_P0;          /* Set the port */
    lin0Rx.pin                  = MCU_PIN_3;                /* Set the pin */
    lin0Rx.alt                  = MCU_GPIO_ALT7;            /* Set the alternative function */
    lin0Rx.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    lin0Rx.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    lin0Rx.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    lin0Rx.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    lin0Rx.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    lin0Rx.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&lin0Rx);

    /* Set RLIN30TX(P0_2) pin */
    lin0Tx.port                 = MCU_PORT_P0;          /* Set the port */
    lin0Tx.pin                  = MCU_PIN_2;                /* Set the pin */
    lin0Tx.alt                  = MCU_GPIO_ALT2;            /* Set the alternative function */
    lin0Tx.dir                  = MCU_GPIO_OUTPUT;          /* Set input/output mode */
    lin0Tx.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    lin0Tx.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    lin0Tx.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    lin0Tx.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    lin0Tx.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;  /* Disabling bidirectional mode */
    McuGpioPortInit(&lin0Tx);
#endif    
#if 0
    /* Set RLIN30RX pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT3;
    PORT.PBDC0 &= PORT_CLEAR_BIT3;
    PORT.PM0 |= PORT_SET_BIT3;
    PORT.PMC0 &= PORT_CLEAR_BIT3;
    PORT.PFC0 &= PORT_CLEAR_BIT3;
    PORT.PFCE0 |= PORT_SET_BIT3;
    PORT.PFCAE0 |= PORT_SET_BIT3;
    PORT.PMC0 |= PORT_SET_BIT3;
    /* Set RLIN30TX pin */
    PORT.PIBC0 &= PORT_CLEAR_BIT2;
    PORT.PBDC0 &= PORT_CLEAR_BIT2;
    PORT.PM0 |= PORT_SET_BIT2;
    PORT.PMC0 &= PORT_CLEAR_BIT2;
    PORT.PIPC0 &= PORT_CLEAR_BIT2;
    PORT.PFC0 |= PORT_SET_BIT2;
    PORT.PFCE0 &= PORT_CLEAR_BIT2;
    PORT.PFCAE0 &= PORT_CLEAR_BIT2;
    PORT.PMC0 |= PORT_SET_BIT2;
    PORT.PM0 &= PORT_CLEAR_BIT2;

#endif

}


/***********************************************************************************************************************
 * Function Name: McuUart0Start
 * Description  : This function starts the Config_UART0 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart0Start(void)
{
    /* Enable UART0 operation */
    RLN30.LUOER |= UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED;
    /* Clear ICRLIN30UR0 interrupt request and enable operation */
    INTC2.ICRLIN30UR0.BIT.RFRLIN30UR0 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN30UR0.BIT.MKRLIN30UR0 = INT_PROCESSING_DISABLED;
    /* Clear ICRLIN30UR1 interrupt request and enable operation */
    INTC2.ICRLIN30UR1.BIT.RFRLIN30UR1 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN30UR1.BIT.MKRLIN30UR1 = INT_PROCESSING_ENABLED;
    /* Clear ICRLIN30UR2 interrupt request and enable operation */
    INTC2.ICRLIN30UR2.BIT.RFRLIN30UR2 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN30UR2.BIT.MKRLIN30UR2 = INT_PROCESSING_DISABLED;
}


/***********************************************************************************************************************
 * Function Name: McuUart0Stop
 * Description  : This function stops the CSIH0 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart0Stop(void)
{
    /* Disable ICRLIN30UR0 operation */
    INTC2.ICRLIN30UR0.BIT.MKRLIN30UR0 = INT_PROCESSING_DISABLED;
    /* Disable ICRLIN30UR1 operation */
    INTC2.ICRLIN30UR1.BIT.MKRLIN30UR1 = INT_PROCESSING_DISABLED;
    /* Disable ICRLIN30UR2 operation */
    INTC2.ICRLIN30UR2.BIT.MKRLIN30UR2 = INT_PROCESSING_DISABLED;
    /* Disable UART0 operation */
    RLN30.LUOER &= (uint8_t) ~(UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED);
    /* Synchronization processing */
    g_cg_sync_read = RLN30.LCUC;
    __syncp();
    /* Clear ICRLIN30UR0 request */
    INTC2.ICRLIN30UR0.BIT.RFRLIN30UR0 = INT_REQUEST_NOT_OCCUR;
    /* Clear ICRLIN30UR1 request */
    INTC2.ICRLIN30UR1.BIT.RFRLIN30UR1 = INT_REQUEST_NOT_OCCUR;
    /* Clear ICRLIN30UR2 request */
    INTC2.ICRLIN30UR2.BIT.RFRLIN30UR2 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = RLN30.LCUC;
    __syncp();
}

/***********************************************************************************************************************
 * Function Name: McuUart0Tx
 * Description  : This function sends UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart0Tx(uint8_t * const transmitBuffer, uint16_t dataLength)
{
    /* Clear ICRLIN30UR1 interrupt request and disable operation */
    MD_STATUS status = MD_OK;
    uint32_t timeout = UART_TX_TIMEOUT;
    if ((transmitBuffer == NULL) || (dataLength == 0U))
    {
        return MD_ARGERROR;
    }
    for (uint8_t i = 0U; i < dataLength; i++)
    {
        
        while (((RLN30.LST & UART_TRANSMISSION_OPERATED) != 0U) && (timeout > 0UL))
        {
            timeout--;
        }
        if (timeout == 0UL)
        {
            return MD_ERROR;
        }    
        RLN30.LUTDR.UINT16 = (uint8_t)transmitBuffer[i];
    }
    timeout = UART_TX_TIMEOUT;
    while (((RLN30.LST & UART_TRANSMISSION_OPERATED) != 0U) && (timeout > 0UL));
    /* Clear ICRLIN30UR1 interrupt request and enable operation */
    return (status);
}

/***********************************************************************************************************************
 * Function Name: McuUart0Rx
 * Description  : This function receives UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
#pragma ghs interrupt
MD_STATUS McuUart0Rx(void)
{
    uint8_t byte = (uint8_t)(RLN30.LURDR.UINT16 & 0xFF);

    if(UartCommonBufferSts.readRepFlag == 1){
	McuUartRxBuffer[rxCount] = byte;
	rxCount++;
	if(rxCount == 7){
	rxCount = 0;
	McuUart0RplyFrmeRd();
	UartCommonBufferSts.readRepFlag = 0;
	}
    }
    if(UartCommonBufferSts.readResFlag == 1){	
	McuUartRxBuffer[rxCount] = byte;
	rxCount++;
        if(rxCount == 9){
	    rxCount = 0;
	    McuUart0RxRdResponse();
	    UartCommonBufferSts.readResFlag = 0;
	}
	
    }
    return MD_OK;
}

/***********************************************************************************************************************
 * Function Name: McuUart0SndRdMsg
 * Description  : This function sends UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
MD_STATUS McuUart0SndRdMsg(McuUartReadMsg *pReadMsgPtr){

    MD_STATUS status = MD_OK;

    static uint8_t ReadMsg[4];
    ReadMsg[0] = pReadMsgPtr->syncData;
    ReadMsg[1] = pReadMsgPtr->idData.idFrame;
    ReadMsg[2] = pReadMsgPtr->address;
    ReadMsg[3] = pReadMsgPtr->crcData;
    UartCommonBufferSts.readResFlag = 1;
    memcpy((uint8_t*)txReadMsg, (uint8_t*)ReadMsg, 4);
    
    status = McuUart0Tx(ReadMsg, 4);

    return status;

}
/***********************************************************************************************************************
 * Function Name: McuUart0SndWrMsg
 * Description  : This function sends UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
MD_STATUS McuUart0SndWrMsg(McuUartWriteMsg *pWriteMsgPtr){

    MD_STATUS status = MD_OK;

    static uint8_t WriteMsg[6];
    WriteMsg[0] = pWriteMsgPtr->syncData;
    WriteMsg[1] = pWriteMsgPtr->idData.idFrame;
    WriteMsg[2] = pWriteMsgPtr->address;
    WriteMsg[3] = pWriteMsgPtr->data.bytes.data2;
    WriteMsg[4] = pWriteMsgPtr->data.bytes.data1;
    WriteMsg[5] = pWriteMsgPtr->crcData;
    UartCommonBufferSts.readRepFlag = 1;
    memcpy((uint8_t*)txWriteMsg, (uint8_t*)WriteMsg, 6);
    
    status = McuUart0Tx(WriteMsg, 6);

    return status;

}
/***********************************************************************************************************************
 * Function Name: McuUart0RxRdResponse
 * Description  : This function Receives UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
MD_STATUS McuUart0RxRdResponse(void){

    MD_STATUS status = MD_OK;
    uint8_t ReadResponse[5];
    uint8_t ReadMsg[4];
    uint8_t errCount = 0;

    memcpy((uint8_t*)ReadMsg, (uint8_t*)McuUartRxBuffer, 4);
    for(int i = 0; i < 4; i++){
	if(ReadMsg[i] != txReadMsg[i])
	    errCount++;
    }
    if(errCount > 1)
	return 8;

    memcpy((uint8_t*)ReadResponse, (uint8_t*)McuUartRxBuffer + 4, 5);

    pReadRspnsePtr.idData.idFrame = ReadResponse[0];
    pReadRspnsePtr.address = ReadResponse[1];
    pReadRspnsePtr.data.bytes.data2 = ReadResponse[2];        //Swapping the Data for MSB first ,Big endian
    pReadRspnsePtr.data.bytes.data1 = ReadResponse[3];
    pReadRspnsePtr.crcData = ReadResponse[4];
    
    UartCommonBufferSts.ReadResponse = 1;
    return status;

}
/***********************************************************************************************************************
 * Function Name: McuUart0RxRdResponse
 * Description  : This function Receives UART0 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart0RplyFrmeRd(void){
    static uint8_t WriteMsg[6];
    uint8_t errCount = 0;
    memcpy((uint8_t*)WriteMsg, (uint8_t*)McuUartRxBuffer, 6);
    for(int i = 0; i < 6; i++){
	if(WriteMsg[i] != txWriteMsg[i])
	    errCount++;
    }
    if(errCount > 1)
	return 8;
    
    pReplyFramePtr.replayFrame = McuUartRxBuffer[6];
    UartCommonBufferSts.ReplyFrame = 1;
}
#if 0
/***********************************************************************************************************************
 * Function Name: McuUart1Init
 * Description  : This function initializes the Config_UART1 module.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart1Init(void)
{
    McuGpioPinConfig lin1Rx;
    McuGpioPinConfig lin1Tx;
    /* Set LIN reset mode */
    RLN31.LCUC = UART_LIN_RESET_MODE_CAUSED;
    /* Disable ICRLIN31UR0 operation and clear request */
    INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN31UR1 operation and clear request */
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    /* Disable ICRLIN31UR2 operation and clear request */
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    /* Set ICRLIN31UR0 table method */
    INTC2.ICRLIN31UR0.BIT.TBRLIN31UR0 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR0 priority */
    INTC2.ICRLIN31UR0.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN31UR1 table method */
    INTC2.ICRLIN31UR1.BIT.TBRLIN31UR1 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR1 priority */
    INTC2.ICRLIN31UR1.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set ICRLIN31UR2 table method */
    INTC2.ICRLIN31UR2.BIT.TBRLIN31UR2 = INT_TABLE_VECTOR;
    /* Set ICRLIN31UR2 priority */
    INTC2.ICRLIN31UR2.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set UART1 setting */
    RLN31.LWBR = UART_9_SAMPLING | UART_PRESCALER_CLOCK_SELECT_1;
    RLN31.LBRP01.UINT16 = _UART1_BAUD_RATE_PRESCALER;
    RLN31.LMD = UART_NOISE_FILTER_ENABLED | UART_MODE_SELECT;
    RLN31.LEDE = UART_FRAMING_ERROR_DETECTED | UART_OVERRUN_ERROR_DETECTED;
    RLN31.LBFC = UART_TRANSMISSION_NORMAL | UART_RECEPTION_NORMAL | UART_PARITY_PROHIBITED | UART_STOP_BIT_1 | 
	UART_LSB | UART_LENGTH_8;
    RLN31.LCUC = UART_LIN_RESET_MODE_CANCELED;
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();

    /* Set RLIN31RX(P0_4) pin */
    lin1Rx.port 	            = MCU_PORT_P0; 			/* Set the port */
    lin1Rx.pin 	             	= MCU_PIN_4;				/* Set the pin */
    lin1Rx.alt	 		        = MCU_GPIO_ALT1;			/* Set the alternative function */
    lin1Rx.dir 	            	= MCU_GPIO_INPUT;			/* Set input/output mode */
    lin1Rx.portControl	     	= MCU_GPIO_SW_CONTROL;			/* I/O direction is controlled by portmode register */
    lin1Rx.pinOutputMode     	= MCU_GPIO_OPEN_DRAIN;			/* Set pin mode (Push-Pull or Open Drain)*/	
    lin1Rx.driveStrength 	    = MCU_GPIO_LOW_DRIVE_STRENGTH;		/* Set drive strength*/
    lin1Rx.inputResistorConfig	= MCU_GPIO_FLOATING;			/* Set input resister as neither Pull-up nor Pull-down */
    lin1Rx.biDirectionControl	= MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;	/* Disabling bidirectional mode */
    McuGpioPortInit(&lin1Rx);

    /* Set RLIN31TX(P0_5) pin */
    lin1Tx.port 	            = MCU_PORT_P0; 			/* Set the port */
    lin1Tx.pin 	             	= MCU_PIN_5;				/* Set the pin */
    lin1Tx.alt	 		        = MCU_GPIO_ALT1;			/* Set the alternative function */
    lin1Tx.dir 	            	= MCU_GPIO_OUTPUT;			/* Set input/output mode */
    lin1Tx.portControl	     	= MCU_GPIO_SW_CONTROL;			/* I/O direction is controlled by portmode register */
    lin1Tx.pinOutputMode     	= MCU_GPIO_OPEN_DRAIN;			/* Set pin mode (Push-Pull or Open Drain)*/	
    lin1Tx.driveStrength 	    = MCU_GPIO_LOW_DRIVE_STRENGTH;		/* Set drive strength*/
    lin1Tx.inputResistorConfig	= MCU_GPIO_FLOATING;			/* Set input resister as neither Pull-up nor Pull-down */
    lin1Tx.biDirectionControl	= MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;	/* Disabling bidirectional mode */
    McuGpioPortInit(&lin1Tx);

#if 0
    /* Set RLIN31RX pin */
    PORT.PIBC0 &= _PORT_CLEAR_BIT4;
    PORT.PBDC0 &= _PORT_CLEAR_BIT4;
    PORT.PM0 |= _PORT_SET_BIT4;
    PORT.PMC0 &= _PORT_CLEAR_BIT4;
    PORT.PFC0 &= _PORT_CLEAR_BIT4;
    PORT.PFCE0 |= _PORT_SET_BIT4;
    PORT.PFCAE0 |= _PORT_SET_BIT4;
    PORT.PMC0 |= _PORT_SET_BIT4;
    /* Set RLIN31TX pin */
    PORT.PIBC0 &= _PORT_CLEAR_BIT5;
    PORT.PBDC0 &= _PORT_CLEAR_BIT5;
    PORT.PM0 |= _PORT_SET_BIT5;
    PORT.PMC0 &= _PORT_CLEAR_BIT5;
    PORT.PIPC0 &= _PORT_CLEAR_BIT5;
    PORT.PFC0 &= _PORT_CLEAR_BIT5;
    PORT.PFCE0 &= _PORT_CLEAR_BIT5;
    PORT.PFCAE0 &= _PORT_CLEAR_BIT5;
    PORT.PMC0 |= _PORT_SET_BIT5;
    PORT.PM0 &= _PORT_CLEAR_BIT5;

#endif

    //R_Config_UART1_Create_UserInit(); 
}

/***********************************************************************************************************************
 * Function Name: McuUart1Start
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart1Start(void)
{
    /* Enable UART1 operation */
    RLN31.LUOER |= UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED;
    /* Clear ICRLIN31UR0 interrupt request and enable operation */
    INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_DISABLED;
    /* Clear ICRLIN31UR1 interrupt request and enable operation */
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    /* Clear ICRLIN31UR2 interrupt request and enable operation */
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
}

/***********************************************************************************************************************
 * Function Name: McuUart1Stop
 * Description  : This function stops the CSIH0 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void McuUart1Stop(void)
{
    /* Disable ICRLIN31UR0 operation */
    INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_DISABLED;
    /* Disable ICRLIN31UR1 operation */
    INTC2.ICRLIN31UR1.BIT.MKRLIN31UR1 = INT_PROCESSING_DISABLED;
    /* Disable ICRLIN31UR2 operation */
    INTC2.ICRLIN31UR2.BIT.MKRLIN31UR2 = INT_PROCESSING_DISABLED;
    /* Disable UART1 operation */
    RLN31.LUOER &= (uint8_t) ~(UART_RECEPTION_ENABLED | UART_TRANSMISSION_ENABLED);
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();
    /* Clear ICRLIN31UR0 request */
    INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
    /* Clear ICRLIN31UR1 request */
    INTC2.ICRLIN31UR1.BIT.RFRLIN31UR1 = INT_REQUEST_NOT_OCCUR;
    /* Clear ICRLIN31UR2 request */
    INTC2.ICRLIN31UR2.BIT.RFRLIN31UR2 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = RLN31.LCUC;
    __syncp();
}

/***********************************************************************************************************************
 * Function Name: McuUart1Rx
 * Description  : This function receives UART0 data and initilize & pointer and counter  .
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart1Rx(uint8_t * const McuUartRxBuffer, uint16_t dataLength)
{
    static uint8_t *Uart1TxAddress;    /* uart1 transmit data address */
    static uint16_t   Uart1TxCount;       /* uart1 transmit data number */

    MD_STATUS status = MD_OK;
    if (dataLength < 1U)
    {
	status = MD_ARGERROR;
    }
    else
    {
	if (( RLN30.LST & UART_RECEPTION_OPERATED ) == 0U)// the result is non-zero, bit 5 is set 
	{
	    Uart1RxCount = 0U;
	    Uart1RxLength = dataLength;
	    Uart1RxAddress = McuUartRxBuffer;
	}
	else
	{
	    status = MD_ERROR;
	}
    }

    return (status);
}


/***********************************************************************************************************************
 * Function Name: McuUart1Tx
 * Description  : This function sends UART1 data.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/

MD_STATUS McuUart1Tx(uint8_t * const transmitBuffer, uint16_t dataLength)
{
    static uint8_t *Uart1RxAddress;    /* uart1 receive data address */
    static uint16_t   Uart1RxCount;      /* uart1 receive data number */
    static uint16_t   Uart1RxLength;     /* uart1 receive data length */

    MD_STATUS status = MD_OK;
    if (dataLength < 1U)
    {
        status = MD_ARGERROR;
    }
    else
    {
        Uart1TxAddress = transmitBuffer;
        Uart1TxCount = dataLength;
        if ((RLN31.LST & UART_TRANSMISSION_OPERATED) == 0U)
        {
            /* Clear ICRLIN31UR0 request and Disable operation */
            INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_DISABLED;
            INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
            RLN31.LUTDR.UINT16 = *Uart1TxAddress;
            Uart1TxAddress++;
            Uart1TxCount--;
            /* Clear ICRLIN31UR0 requestt and enable operation */
            INTC2.ICRLIN31UR0.BIT.RFRLIN31UR0 = INT_REQUEST_NOT_OCCUR;
            INTC2.ICRLIN31UR0.BIT.MKRLIN31UR0 = INT_PROCESSING_ENABLED;
        }
        else
        {
            status = MD_ERROR;
        }
    }
    return (status);
}
#endif

/*--------------------------- End McuCan.c -----------------------------*/
