/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: McuGpio.h
**
** Description:
** This header file declares the functions and macros used for GPIO configuration and control.
** It serves as the interface for other modules to access GPIO functionalities.
**---------------------------------------------------------------------------*/
#ifndef MCU_GPIO_H
#define MCU_GPIO_H

#include "McuTypedefs.h"
#include "SystemCommonIncludes.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define SIGNED_ZERO			0
#define ZERO				(uint8_t)0
#define ONE				    (uint8_t)1
#define TWO				    (uint8_t)2
#define THREE				(uint8_t)3
#define FOUR				(uint8_t)4
#define FIVE				(uint8_t)5
#define SIX				    (uint8_t)6
#define SEVEN				(uint8_t)7
#define EIGHT				(uint8_t)8
#define NINE				(uint8_t)9
#define TEN				    (uint8_t)10
#define ELEVEN				(uint8_t)11
#define TWELVE				(uint8_t)12
#define THIRTEEN			(uint8_t)13
#define FOURTEEN			(uint8_t)14
#define FIFTEEN				(uint8_t)15
#define SIXTEEN				(uint16_t)16

typedef enum MCU_GPIO_VALIDATION
{
    MCU_GPIO_OK			= 0,
    MCU_GPIO_INVALID_PORT	= 1,
    MCU_GPIO_INVALID_PIN	= 2
}McuGpioStatus;

typedef enum MCU_GPIO_DRIVE_STRENGTH
{
    MCU_GPIO_LOW_DRIVE_STRENGTH		= 0,
    MCU_GPIO_HIGH_DRIVE_STRENGTH 	= 1
}McuGpioDriveStrength;

typedef enum MCU_GPIO_PORT_CONTROL		/* Configuration specifies whether the I/O direction is controlled by port mode or by alternative function */
{
    MCU_GPIO_SW_CONTROL 	= 0,		/* ControlLed by port mode */
    MCU_GPIO_DIRECT_CONTROL 	= 1		/* ControlLed by Alternative mode */
}McuGpioPortControl;

typedef enum MCU_GPIO_PIN_OUTPUT_MODE		/* Configuring the output buffer function of the Pin */
{
    MCU_GPIO_PUSH_PULL	= 0,
    MCU_GPIO_OPEN_DRAIN	= 1
}McuGpioOutputMode;

typedef enum MCU_GPIO_INPUT_RESISTOR		/* Configuring the input internal resistors of the Pin */
{
    MCU_GPIO_FLOATING	= 0,
    MCU_GPIO_PULL_UP 	= 1,
    MCU_GPIO_PULL_DOWN 	= 2
}McuGpioInputResistor;

typedef enum MCU_GPIO_BI_DIRECTIONAL_CONTROL	/* Enabling this configuration enables the reading the state of a pin configured in output mode */
{
    MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE 	= 0,
    MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 	= 1
}McuGpioBidirectionControl;

typedef enum MCU_GPIO_ALT_FUNC
{
    MCU_GPIO_ALT_DEFAULT	= 0,
    MCU_GPIO_ALT1		= 1,
    MCU_GPIO_ALT2		= 2,
    MCU_GPIO_ALT3		= 3,
    MCU_GPIO_ALT4		= 4,
    MCU_GPIO_ALT5		= 5,
    MCU_GPIO_ALT6		= 6,
    MCU_GPIO_ALT7		= 7
}McuGpioAltFunc;

typedef enum MCU_GPIO_DIRECTION_IO
{
    MCU_GPIO_INPUT	= 0,
    MCU_GPIO_OUTPUT	= 1
}McuGpioDir;

typedef enum MCU_GPIO_STATE
{
    MCU_GPIO_LOW 	= 0,
    MCU_GPIO_HIGH	= 1
}McuGpioState;

typedef enum MCU_GPIO_PIN
{
    MCU_PIN_0	= 0U,
    MCU_PIN_1	= 1U,
    MCU_PIN_2	= 2U,
    MCU_PIN_3	= 3U,
    MCU_PIN_4	= 4U,
    MCU_PIN_5	= 5U,
    MCU_PIN_6	= 6U,
    MCU_PIN_7	= 7U,
    MCU_PIN_8	= 8U,
    MCU_PIN_9	= 9U,
    MCU_PIN_10	= 10U,
    MCU_PIN_11	= 11U,
    MCU_PIN_12	= 12U,
    MCU_PIN_13	= 13U,
    MCU_PIN_14	= 14U,
    MCU_PIN_15	= 15U,
}McuGpioPin;

typedef enum MCU_GPIO_PORT
{
    MCU_PORT_P0	= 0, 
    MCU_PORT_P8 = 1,
    MCU_PORT_P9 = 2,
    MCU_PORT_P10 = 3,
    MCU_APORT0 	= 4,
    
}McuGpioPort;


typedef struct MCU_GPIO_PORT_PIN_CONFIG
{
    McuGpioPort 		    port;			/*Port Number*/
    McuGpioPin 			    pin;			/*Pin Number*/
    McuGpioDir 			    dir;			/*Pin Direction (input or output)*/
    McuGpioPortControl	            portControl;
    McuGpioAltFunc 	            alt;			/*Pin Alternative Function*/
    McuGpioDriveStrength 	    driveStrength;		/*Pin Drive strength (Low or High)*/
    McuGpioOutputMode		    pinOutputMode;		/*Push-Pull or Open Drain*/
    McuGpioInputResistor	    inputResistorConfig;	/*Floating, Pull-Up or Pull-Down*/
    McuGpioBidirectionControl	    biDirectionControl;	/*Sets the pin in bidirectional mode*/

}McuGpioPinConfig;
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern McuGpioStatus	McuGpioPortInit(McuGpioPinConfig *pPinConfig);
extern void 		McuGpioSetOutputState(McuGpioPort port, McuGpioPin pin, McuGpioState state);
extern McuGpioState 	McuGpioGetInputState(McuGpioPort port, McuGpioPin pin);
extern McuGpioState	McuGpioGetOutputState(McuGpioPort port, McuGpioPin pin);

#endif //MCU_GPIO_H

/*--------------------------- End McuDio.h -----------------------------*/
