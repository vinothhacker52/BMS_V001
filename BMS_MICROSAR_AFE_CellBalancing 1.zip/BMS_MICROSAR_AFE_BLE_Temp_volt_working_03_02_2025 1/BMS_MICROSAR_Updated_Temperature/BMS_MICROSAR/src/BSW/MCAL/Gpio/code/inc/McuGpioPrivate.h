/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: McuGpioPrivate.h
**
** Description:
** General Header file for Mcu Gpio
**---------------------------------------------------------------------------*/
#ifndef MCU_GPIO_PRIVATE_H
#define MCU_GPIO_PRIVATE_H

#include "McuMacroDriver.h"		/* This is just the renamed r_cg_macrodriver.h */
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define NUM_PORTS 5

static const uint8_t McuGpioMaxPinsPerPort[NUM_PORTS] = 
		{6,6,3,14,9};	//Storing the maximum number of pins each port has

typedef struct MCU_GPIO_REGS
{
	volatile uint16_t * pPortReg;
	volatile uint16_t * pPNotReg;
	volatile uint16_t * pPmReg;
	volatile uint16_t * pPmcReg;
	volatile uint16_t * pPfcReg;
	volatile uint16_t * pPfceReg;
	volatile uint16_t * pPfcaeReg;
	volatile uint16_t * pPipcReg;
	volatile uint16_t * pPibcReg;
	volatile const uint16_t * pPprReg;
	volatile uint16_t * pPdReg;
	volatile uint16_t * pPuReg;
	volatile uint32_t * pPodcReg;
	volatile uint32_t * pPdscReg;
	volatile uint32_t * pPprotsReg;
	volatile uint32_t * pPpcmdReg;
	volatile uint32_t * pPbdcReg;
}McuGpioPortRegs;
		
static const McuGpioPortRegs McuGpioPortList[]=
{
	{(volatile uint16_t *)&PORT.P0,(volatile uint16_t *) &PORT.PNOT0,(volatile uint16_t *) &PORT.PM0,(volatile uint16_t *) &PORT.PMC0, (volatile uint16_t *)&PORT.PFC0, (volatile uint16_t *)&PORT.PFCE0, (volatile uint16_t *)&PORT.PFCAE0, (volatile uint16_t *)&PORT.PIPC0, (volatile uint16_t *)&PORT.PIBC0,(volatile uint16_t *) &PORT.PPR0, (volatile uint16_t *)&PORT.PD0, (volatile uint16_t *)&PORT.PU0, (volatile uint32_t *)&PORT.PODC0, (volatile uint32_t *)&PORT.PDSC0, (volatile uint32_t *)&PORT.PPROTS0, (volatile uint32_t *)&PORT.PPCMD0,(volatile uint32_t *)&PORT.PBDC0},
	{(volatile uint16_t *)&PORT.P8, (volatile uint16_t *)&PORT.PNOT8, (volatile uint16_t *)&PORT.PM8, (volatile uint16_t *)&PORT.PMC8, (volatile uint16_t *)&PORT.PFC8, (volatile uint16_t *)&PORT.PFCE8, (volatile uint16_t *)&PORT.PFCAE8, _NULL, (volatile uint16_t *)&PORT.PIBC8, (volatile uint16_t *)&PORT.PPR8, (volatile uint16_t *)&PORT.PD8, (volatile uint16_t *)&PORT.PU8, (volatile uint32_t *)&PORT.PODC8, _NULL, (volatile uint32_t *)&PORT.PPROTS8, (volatile uint32_t *)&PORT.PPCMD8,(volatile uint32_t *)&PORT.PBDC8},
	{(volatile uint16_t *)&PORT.P9, (volatile uint16_t *)&PORT.PNOT9, (volatile uint16_t *)&PORT.PM9, (volatile uint16_t *)&PORT.PMC9, (volatile uint16_t *)&PORT.PFC9, (volatile uint16_t *)&PORT.PFCE9, (volatile uint16_t *)&PORT.PFCAE9, _NULL, (volatile uint16_t *)&PORT.PIBC9, (volatile uint16_t *)&PORT.PPR9, (volatile uint16_t *)&PORT.PD9, (volatile uint16_t *)&PORT.PU9, (volatile uint32_t *)&PORT.PODC9, _NULL, (volatile uint32_t *)&PORT.PPROTS9, (volatile uint32_t *)&PORT.PPCMD9,(volatile uint32_t *)&PORT.PBDC9},
	{(volatile uint16_t *)&PORT.P10, (volatile uint16_t *)&PORT.PNOT10, (volatile uint16_t *)&PORT.PM10, (volatile uint16_t *)&PORT.PMC10, (volatile uint16_t *)&PORT.PFC10, (volatile uint16_t *)&PORT.PFCE10, (volatile uint16_t *)&PORT.PFCAE10, (volatile uint16_t *)&PORT.PIPC10, (volatile uint16_t *)&PORT.PIBC10, (volatile uint16_t *)&PORT.PPR10, (volatile uint16_t *)&PORT.PD10, (volatile uint16_t *)&PORT.PU10, (volatile uint32_t *)&PORT.PODC10, (volatile uint32_t *)&PORT.PDSC10, (volatile uint32_t *)&PORT.PPROTS10, (volatile uint32_t *)&PORT.PPCMD10,(volatile uint32_t *)&PORT.PBDC10},
	{(volatile uint16_t *)&PORT.AP0, (volatile uint16_t *)&PORT.APNOT0, (volatile uint16_t *)&PORT.APM0, _NULL, _NULL, _NULL, _NULL, _NULL, (volatile uint16_t *)&PORT.APIBC0, (volatile uint16_t *)&PORT.APPR0, _NULL, _NULL, _NULL, _NULL, _NULL, _NULL},
	
};
#endif /* MCU_GPIO_PRIVATE_H */
