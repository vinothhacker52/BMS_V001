/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                           
** File: McuGpio.c
**
** Description:
** This source file contains the implementation of functions responsible for configuring
** and controlling the General Purpose Input/Output (GPIO) ports of a microcontroller.
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuGpio.h"
#include "McuGpioPrivate.h"
#include "McuMacroDriver.h"		/* This is just the renamed r_cg_macrodriver.h */
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
static McuGpioStatus	McuGpioPortPinValidation	(McuGpioPort port,McuGpioPin pin);
static void 		McuGpioConfigOutput		(McuGpioPort port, McuGpioPin pin, McuGpioBidirectionControl bidirectionControl);
static void 		McuGpioConfigInput		(McuGpioPort port, McuGpioPin pin, McuGpioInputResistor inputResistor);
static void 		McuGpioSetAltfunction		(McuGpioPort port, McuGpioPin pin, McuGpioAltFunc alt, McuGpioDir dir, McuGpioPortControl portControl);
static void		McuGpioOutputModeConfig		(McuGpioPort port, McuGpioPin pin, McuGpioOutputMode outputMode);
static void		McuGpioInputResistorConfig	(McuGpioPort port, McuGpioPin pin, McuGpioInputResistor inputResistor);
static void		McuGpioDriveStrengthConfig	(McuGpioPort port, McuGpioPin pin, McuGpioDriveStrength driveStrength);
static void		McuGpioBiDirectionalConfig	(McuGpioPort port, McuGpioPin pin, McuGpioBidirectionControl bidirectionControl);
/*-----------------------------------------------------------------------------
** Function: McuGpioPortInit
**
** Description:
** Initializes the pin with the desired configuration
** Configures the pin as input, output or Alternative mode
**
** Arguments:
** 1. pPinConfig: pointer to the structure that store the configuration settings of the desired pin.
**
** Return values:
** Pin Status
**---------------------------------------------------------------------------*/
McuGpioStatus McuGpioPortInit(McuGpioPinConfig *pPinConfig)
{
    McuGpioStatus gpioStatus = MCU_GPIO_OK;

    gpioStatus = McuGpioPortPinValidation(pPinConfig->port,pPinConfig->pin);

    if(gpioStatus == MCU_GPIO_OK)
    {
	CLEAR_BIT(*McuGpioPortList[pPinConfig->port].pPibcReg, pPinConfig->pin);	/* Disabling input buffer */
	CLEAR_BIT(*McuGpioPortList[pPinConfig->port].pPbdcReg, pPinConfig->pin);	/* Disabling bi directional mode */
	SET_BIT(*McuGpioPortList[pPinConfig->port].pPmReg, pPinConfig->pin);		/* Configuring the pin as input */
	CLEAR_BIT(*McuGpioPortList[pPinConfig->port].pPmcReg, pPinConfig->pin);		/* Setting pin in port mode */
	CLEAR_BIT(*McuGpioPortList[pPinConfig->port].pPipcReg, pPinConfig->pin);		/* This register specifies whether the I/O direction of the Pn_m pin is 
												   controlled by the port mode register PMn.PMn_m or by an alternative function.*/

	/*Check the pin configuration mode*/
	if(pPinConfig->alt != MCU_GPIO_ALT_DEFAULT)	/*Alternative configuration*/
	{
	    McuGpioSetAltfunction(pPinConfig->port, pPinConfig->pin, pPinConfig->alt, pPinConfig->dir, pPinConfig->portControl);
	}
	else if(pPinConfig->dir == MCU_GPIO_OUTPUT)	/*Output mode configuration*/
	{
	    McuGpioConfigOutput(pPinConfig->port, pPinConfig->pin,pPinConfig->biDirectionControl);
	}
	else /* if(pPinConfig->dir == MCU_GPIO_INPUT) */ /*Input mode configuration*/
	{
	    McuGpioConfigInput(pPinConfig->port, pPinConfig->pin, pPinConfig->inputResistorConfig);
	}
	/*setting drive strength*/
	McuGpioDriveStrengthConfig(pPinConfig->port, pPinConfig->pin, pPinConfig->driveStrength);
	/* Configuring the output buffer function of the Pin */
	McuGpioOutputModeConfig(pPinConfig->port, pPinConfig->pin, pPinConfig->pinOutputMode);

    }

    return gpioStatus;
}/*--------------------------- End McuGpioPortInit () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioPortPinValidation
**
** Description:
** Validated the port and pin
** The function checks if the port and the pin provided is valid or not
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
**
** Return values:
** Pin Status
**---------------------------------------------------------------------------*/
static McuGpioStatus McuGpioPortPinValidation(McuGpioPort port,McuGpioPin pin)
{
    McuGpioStatus gpioStatus;

    if(port > MCU_APORT0)
    {
	gpioStatus = MCU_GPIO_INVALID_PORT;
    }
    else if(pin > McuGpioMaxPinsPerPort[port])
    {
	gpioStatus = MCU_GPIO_INVALID_PIN;
    }
    else
    {
	gpioStatus = MCU_GPIO_OK;
    }

    return gpioStatus;
}/*--------------------------- End McuGpioPortPinValidation () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioConfigOutput
**
** Description:
** This function configures the pin in output mode
** Also sets if the pin is in bidirectional mode.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
** 3. bidirectionControl: Sets the bidirectional configuration.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuGpioConfigOutput(McuGpioPort port, McuGpioPin pin, McuGpioBidirectionControl bidirectionControl)
{
    McuGpioBiDirectionalConfig(port, pin, bidirectionControl);
    CLEAR_BIT(*McuGpioPortList[port].pPmReg,pin);		/*Configuring the pin as output*/
    CLEAR_BIT(*McuGpioPortList[port].pPmcReg,pin);		/*Setting pin in port mode*/
    CLEAR_BIT(*McuGpioPortList[port].pPortReg,pin);		/*Making the State of the pin LOW by default*/

}/*--------------------------- End McuConfigGpioOutput () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioSetOutputState
**
** Description:
** This function sets the specific output pin to either High or Low state.	
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number to be set.
** 3. state: Output state High or Low
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuGpioSetOutputState(McuGpioPort port, McuGpioPin pin, McuGpioState state)
{

    if(state == MCU_GPIO_LOW)
    {
	CLEAR_BIT(*McuGpioPortList[port].pPortReg,pin);	/*Making the State of the pin LOW*/	
    }
    else /*state = MCU_HIGH*/
    {
	SET_BIT(*McuGpioPortList[port].pPortReg,pin);		/*Making the State of the pin HIGH*/
    }
}/*--------------------------- End McuSetGpioOutput () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioGetOutputState
**
** Description:
** This function gets the output state of the specific pin(either High or Low state).	
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number.
**
** Return values:
** MCU_GPIO_HIGH or MCU_GPIO_LOW
**---------------------------------------------------------------------------*/
McuGpioState	McuGpioGetOutputState(McuGpioPort port, McuGpioPin pin)
{
    McuGpioState pinState;

    if(((*McuGpioPortList[port].pPprReg) & ((uint16_t)1<<pin)))		/*Checks if the pin is high*/
    {
	pinState = MCU_GPIO_HIGH;
    }
    else/*pin state is LOW*/
    {
	pinState = MCU_GPIO_LOW;
    }
    return pinState;					/*Returning the Pin state*/
}


/*-----------------------------------------------------------------------------
** Function: McuGpioConfigInput
**
** Description:
** Set the pin in input mode enabling the port input buffer.
** Does the internal input resistor configuration.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
** 3. inputResistor: sets the configuration input internal resitor (Pull-up or Pull-down or neither(free/floating)) 
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuGpioConfigInput(McuGpioPort port, McuGpioPin pin, McuGpioInputResistor inputResistor)
{
    SET_BIT(*McuGpioPortList[port].pPmReg,pin);			/*Configuring the pin as input*/
    CLEAR_BIT(*McuGpioPortList[port].pPmcReg,pin);		/*Setting pin in port mode*/
    CLEAR_BIT(*McuGpioPortList[port].pPipcReg,pin);		/*This register specifies whether the I/O direction of the Pn_m pin is
								  controlled by the port mode register PMn.PMn_m or by an alternative function.*/

    /* Configuring the input pin characterstics (Pull-Up or Pull-down) */
    McuGpioInputResistorConfig(port, pin, inputResistor);
    /*Port input buffer selection*/
    SET_BIT(*McuGpioPortList[port].pPibcReg,pin);	/*Port Input Buffer Control Reg : Enable input buffer*/
}/*--------------------------- End McuSetGpioOutput () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGetInputState
**
** Description:
** Gets the state of a Pin.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
**
** Return values:
** MCU_GPIO_HIGH or MCU_GPIO_LOW
**---------------------------------------------------------------------------*/
McuGpioState McuGpioGetInputState(McuGpioPort port, McuGpioPin pin)
{
    McuGpioState pinState;

    if(((*McuGpioPortList[port].pPprReg) & ((uint16_t)1<<pin)))		/*Checks if the pin is high*/
    {
	pinState = MCU_GPIO_HIGH;
    }
    else/*pin state is LOW*/
    {
	pinState = MCU_GPIO_LOW;
    }
    return pinState;					/*Returning the Pin state*/
}/*--------------------------- End McuGetInputState () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuSetAltfunction
**
** Description:
** Configures pin to the chosen alternative function.
** This function also sets the direction of the pin in alternative mode.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
** 3. alt: Alternative Function (Alt1-Alt7)
** 4. dir: Input/Output direction
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void 	McuGpioSetAltfunction(McuGpioPort port, McuGpioPin pin, McuGpioAltFunc alt, McuGpioDir dir, McuGpioPortControl portControl)
{
    switch(alt)
    {
	case MCU_GPIO_ALT1:						/*Configuration for alternative 1 mode */
	    CLEAR_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT2:						/*Configuration for alternative 2 mode */
	    CLEAR_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT3:						/*Configuration for alternative 3 mode */
	    CLEAR_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT4:						/*Configuration for alternative 4 mode */
	    CLEAR_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT5:						/*Configuration for alternative 5 mode */
	    SET_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT6:						/*Configuration for alternative 6 mode */
	    SET_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	case MCU_GPIO_ALT7:						/*Configuration for alternative 7 mode */
	    SET_BIT(*McuGpioPortList[port].pPfcaeReg,pin);
	    SET_BIT(*McuGpioPortList[port].pPfceReg,pin);
	    CLEAR_BIT(*McuGpioPortList[port].pPfcReg,pin);
	    break;
	default:	
	    break;
    }
    /*Setting the direction of the pin (input or outpur)*/
    switch(dir)
    {
	case MCU_GPIO_INPUT:
	    SET_BIT(*McuGpioPortList[port].pPmReg, pin);	/*Setting the pin as input*/
	    break;
	case MCU_GPIO_OUTPUT:
	    CLEAR_BIT(*McuGpioPortList[port].pPmReg, pin);	/*Setting pin as output*/
	    break;
	default:
	    break;
    }
    /*Configuring what controls the output*/
    if(portControl == MCU_GPIO_DIRECT_CONTROL)
    {
	SET_BIT(*McuGpioPortList[port].pPipcReg,pin);
    }

    /*Setting pin in alternative function mode*/
    SET_BIT(*McuGpioPortList[port].pPmcReg,pin)	;		
}/*--------------------------- End McuSetAltfunction () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioBiDirectionalConfig
**
** Description:
** Enabling this configuration enables the reading the state of a pin configured in output mode 
**
** Arguments:
** 1. port: 			Portgroup
** 2. pin: 			Pin Number
** 3. bidirectionControl:	Bidirection enable control
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuGpioBiDirectionalConfig	(McuGpioPort port, McuGpioPin pin, McuGpioBidirectionControl bidirectionControl)
{
    if( bidirectionControl == MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE )
    {
	SET_BIT(*McuGpioPortList[port].pPbdcReg,pin);
    }
    else
    {
	CLEAR_BIT(*McuGpioPortList[port].pPbdcReg,pin);
    }
}/*--------------------------- End McuGpioBiDirectionalConfig () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioOutputModeConfig
**
** Description:
** Sets pin output buffer function to open-drain or push-pull.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
** 3. outputMode: the output buffer function.(open-drain or push-pull)
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void	McuGpioOutputModeConfig	(McuGpioPort port, McuGpioPin pin, McuGpioOutputMode outputMode)
{
    uint32_t podcValue;
    if(outputMode == MCU_GPIO_OPEN_DRAIN)
    {
	podcValue = ((*McuGpioPortList[port].pPodcReg) | ((uint32_t)1<<pin));	/*Setting the particular pin bit in PODC register*/
    }
    else
    {
	podcValue = ((*McuGpioPortList[port].pPodcReg) & ~((uint32_t)1<<pin));	/*Clearing the particular pin bit in PODC register*/

    }
    /*Setting the pin in Open drain mode*/	
    do
    {
	*McuGpioPortList[port].pPpcmdReg	=	WRITE_PROTECT_COMMAND;
	*McuGpioPortList[port].pPodcReg		=	podcValue;
	*McuGpioPortList[port].pPodcReg		=	~((uint32_t)podcValue);
	*McuGpioPortList[port].pPodcReg		=	podcValue;
    }while(*McuGpioPortList[port].pPprotsReg == WRITE_PROTECT_ERROR_OCCURED);
}/*--------------------------- End McuGpioOutputModeConfig () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioInputResistorConfig
**
** Description:
** Sets pin input characteristics to floating(free), pull-up or pull-down.
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuGpioInputResistorConfig	(McuGpioPort port, McuGpioPin pin, McuGpioInputResistor inputResistor)
{
    if(inputResistor == MCU_GPIO_PULL_UP)
    {
	SET_BIT(*McuGpioPortList[port].pPuReg,pin);
    }
    else if(inputResistor == MCU_GPIO_PULL_DOWN)
    {
	SET_BIT(*McuGpioPortList[port].pPdReg,pin);
    }
    else
    {
	CLEAR_BIT(*McuGpioPortList[port].pPuReg,pin);
	CLEAR_BIT(*McuGpioPortList[port].pPdReg,pin);
    }
}/*--------------------------- End McuGpioInputResistorConfig () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuGpioDriveStrengthConfig
**
** Description:
** Set output drive strength to high or low
**
** Arguments:
** 1. port: Portgroup
** 2. pin: Pin Number
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void	McuGpioDriveStrengthConfig(McuGpioPort port, McuGpioPin pin, McuGpioDriveStrength driveStrength)
{
    uint32_t pdscValue;
    pdscValue = (*McuGpioPortList[port].pPdscReg);
    if(driveStrength == MCU_GPIO_HIGH_DRIVE_STRENGTH)
    {
	pdscValue |= ((uint32_t)1<<pin);		/*Setting the bit in the Port Drive Strength Control Register corresponding to respective pin*/
    }
    else /*mode = MCU_GPIO_LOW_DRIVE_STRENGTH*/
    {
	pdscValue &= ~((uint32_t)1<<pin);		/*Clearing the bit in the Port Drive Strength Control Register corresponding to respective pin*/
    }
    /*Setting the pin drive strength configuration*/
    do
    {
	*McuGpioPortList[port].pPpcmdReg	=	WRITE_PROTECT_COMMAND;
	*McuGpioPortList[port].pPdscReg		=	pdscValue;
	*McuGpioPortList[port].pPdscReg		=	~((uint32_t)pdscValue);
	*McuGpioPortList[port].pPdscReg		=	pdscValue;
    }while(*McuGpioPortList[port].pPprotsReg == WRITE_PROTECT_ERROR_OCCURED);

}/*--------------------------- End McuGpioDriveStrengthConfig () -----------------------*/


/*--------------------------- End McuGpio.c -----------------------------*/
