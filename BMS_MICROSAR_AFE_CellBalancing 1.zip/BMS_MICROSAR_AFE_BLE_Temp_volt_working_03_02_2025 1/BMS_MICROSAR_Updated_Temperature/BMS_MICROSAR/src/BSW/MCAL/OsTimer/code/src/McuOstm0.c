/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                   
** File: McuOstm0.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of OS timer Module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/* Files : McuOstm0.c, McuOstm0.h & McuOstm0Private.h
 *

 */

/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuOstm0.h"
#include "McuOstmPrivate.h"
#include "McuMacroDriver.h"
#include "SystemGpio.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
static  VoidFuncPtr   osTimerCallback = NULL_VOID_FUNC_PTR;
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
** Function: McuOstm0init()
**
** Description:
** This function initializes the OS timer.
**
** Arguments:
** 1. pOsTimerConfig : pointer to OS Timer Configuration settings register.
**
** Return values:
** None
**---------------------------------------------------------------------------*/

void McuOstm0init(McuOstConfig *pOsTimerConfig)
{
    volatile uint32_t g_cg_sync_read;
    osTimerCallback = pOsTimerConfig->pCallbackFunc;

    /* Disable OSTM0 operation */
    McuOstm0Stop();			/*HD - Change made as suggested*/

    /* Set OSTM0 interrupt setting */
    INTC2.ICOSTM0.BIT.TBOSTM0 = INT_TABLE_VECTOR;
    INTC2.ICOSTM0.UINT16 &= INT_PRIORITY_LOWEST;
    /* Set OSTM0 control setting */
    OSTM0.CTL = OSTM_MODE_INTERVAL_TIMER | OSTM_START_INTERRUPT_DISABLE;
    /* Set the compare value */
    OSTM0.CMP = pOsTimerConfig->timerValue;
    /* Synchronization processing */
    g_cg_sync_read = OSTM0.CTL;
    __syncp();
}/*--------------------------- End McuOstm0init () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuOstm0Start()
**
** Description:
** Function to start OS Timer 0.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/

void McuOstm0Start(void)
{
    INTC2.ICOSTM0.BIT.RFOSTM0 = INT_REQUEST_NOT_OCCUR;
    INTC2.ICOSTM0.BIT.MKOSTM0 = INT_PROCESSING_ENABLED;
    /* Enable OSTM0 operation */
    OSTM0.TS = OSTM_COUNTER_START;
}/*--------------------------- End McuOstm0Start () -----------------------*/



/*-----------------------------------------------------------------------------
** Function: McuOstm0Stop()
**
** Description:
** Function to stop OS Timer 0.
** This function is not aligned with the DAMT project but is declared and
** defined for future use.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuOstm0Stop(void)
{
    volatile uint32_t g_cg_sync_read;
    /* Disable OSTM0 operation */
    OSTM0.TT = OSTM_COUNTER_STOP;
    /* Disable OSTM0 interrupt operation and clear request */
    INTC2.ICOSTM0.BIT.MKOSTM0 = INT_PROCESSING_DISABLED;
    INTC2.ICOSTM0.BIT.RFOSTM0 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = OSTM0.TT;
    __syncp();
}/*--------------------------- End McuOstm0Stop () -----------------------*/



/*-----------------------------------------------------------------------------
** Function: McuOstm0Interrupt()
**
** Description:
** This function handles the OS timer interrupt.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
/* MISRA Violation: START Msg(MISRA_OSTM0:1) */
#pragma ghs interrupt(enabled)
/* END Msg(MISRA_OSTM0:1) */
__interrupt void McuOstm0Interrupt(void)
{

    milliTick++;

    /* MISRA Violation: START Msg(MISRA_OSTM0:2) */
    /* MISRA Violation: START Msg(MISRA_OSTM0:3) */
    if(osTimerCallback != NULL_VOID_FUNC_PTR )			/* Checking if the Function pointer is NULL */
    {
	/* END Msg(MISRA_OSTM0:2) */
	/* END Msg(MISRA_OSTM0:3) */
	osTimerCallback();
    }
}/*--------------------------- End McuOstm0Interrupt () -----------------------*/

/*--------------------------- End McuOstm0.c -----------------------------*/
