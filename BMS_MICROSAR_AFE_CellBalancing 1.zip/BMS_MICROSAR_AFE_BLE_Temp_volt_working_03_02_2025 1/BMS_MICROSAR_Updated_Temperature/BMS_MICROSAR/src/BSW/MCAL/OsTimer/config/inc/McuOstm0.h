/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                         
** File: McuOstm0.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for OS Timer Module.
**---------------------------------------------------------------------------*/
#ifndef MCU_OSTM0_H
#define MCU_OSTM0_H

#include "McuTypedefs.h"	
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
/*Structure to store the OS timer Configuration*/
typedef struct
{	
    VoidFuncPtr	pCallbackFunc;	/* function pointer to reference the task defined */
    uint32_t	timerValue;	/* Compare value to be stored in the Os Timer Compare Register */
}McuOstConfig;

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern volatile uint32_t milliTick;
extern volatile uint8_t VxFlag; 
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void 	McuOstm0init	(McuOstConfig *pOsTimerConfig);
extern void 	McuOstm0Start	(void);
extern void 	McuOstm0Stop	(void);

#endif // MCU_OSTM0_H

/*--------------------------- End McuOstm0.h -----------------------------*/
