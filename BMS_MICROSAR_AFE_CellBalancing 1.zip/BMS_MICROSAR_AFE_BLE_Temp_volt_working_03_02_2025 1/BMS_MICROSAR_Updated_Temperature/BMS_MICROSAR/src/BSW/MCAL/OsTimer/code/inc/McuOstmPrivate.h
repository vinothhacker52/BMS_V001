/***********************************************************************************************************************
* File Name        : McuOstmPrivate.h
* Version          : 1.0.11
* Device(s)        : R7F701709
* Description      : General header file for OSTM peripheral.
***********************************************************************************************************************/

#ifndef MCU_OSTM_PRIVATE_H
#define MCU_OSTM_PRIVATE_H

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
/*
    OSTM Count Start Trigger Register (OSTMnTS)
*/
/* Start the counter (OSTMnTS) */
#define OSTM_COUNTER_START                       (0x01U) /* Start the counter. */

/*
    OSTM Count Stop Trigger Register (OSTMnTT)
*/
/* Stop the counter (OSTMnTT) */
#define OSTM_COUNTER_STOP                        (0x01U) /* Stop the counter. */

/*
    OSTM Control Register (OSTMnCTL)
*/
/* Specifie the operating mode for the counter (OSTMnMD1) */
#define OSTM_MODE_INTERVAL_TIMER                 (0x00U) /* Interval timer mode */
#define OSTM_MODE_FREE_RUNNING                   (0x02U) /* Free-running comparison mode */
/* Controls the generation of OSTMTINT interrupt requests at the start of counting (OSTMnMD0) */
#define OSTM_START_INTERRUPT_DISABLE             (0x00U) /* Disable the interrupts when counting starts. */
#define OSTM_START_INTERRUPT_ENABLE              (0x01U) /* Enable the interrupts when counting starts. */

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/

#endif	/* MCU_OSTM_PRIVATE_H */
