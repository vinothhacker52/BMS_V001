/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018, 2024 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name        : Config_TAUD0_14.c
* Component Version: 1.7.0
* Device(s)        : R7F701690
* Description      : This file implements device driver for Config_TAUD0_14.
***********************************************************************************************************************/
/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "McuMacroDriver.h"
#include "McuTaud0Ch14.h"
/* Start user code for include. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
extern volatile uint32_t g_cg_sync_read;
/* Start user code for global. Do not edit comment generated here */
volatile uint32_t _100MicroTick;
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: McuTaud0Ch14Init
* Description  : This function initializes the TAUD014 channel.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuTaud0Ch14Init(void)
{
    /* Disable channel 14 counter operation */
    TAUD0.TT |= TAUD_CHANNEL14_COUNTER_STOP;
    /* Disable INTTAUD0I14 operation and clear request */
    INTC1.ICTAUD0I14.BIT.MKTAUD0I14 = INT_PROCESSING_DISABLED;
    INTC1.ICTAUD0I14.BIT.RFTAUD0I14 = INT_REQUEST_NOT_OCCUR;
    /* Set INTTAUD0I14 setting */
    INTC1.ICTAUD0I14.BIT.TBTAUD0I14 = INT_TABLE_VECTOR;
    INTC1.ICTAUD0I14.UINT16 &= INT_PRIORITY_LOWEST;
    TAUD0.TPS &= TAUD_CK0_PRS_CLEAR;
    TAUD0.TPS |= TAUD_CK0_PRE_PCLK_0;
    /* Set channel 14 setting */
    TAUD0.CMOR14 = TAUD_SELECTION_CK0 | TAUD_COUNT_CLOCK_PCLK | TAUD_INDEPENDENT_CHANNEL | 
                   TAUD_START_TRIGGER_SOFTWARE | TAUD_OVERFLOW_AUTO_CLEAR | TAUD_INTERVAL_TIMER_MODE | 
                   TAUD_STARTINT_NOT_GENERATED;
    /* Set compare match register */
    TAUD0.CMUR14 = TAUD_INPUT_EDGE_UNUSED;
    TAUD0.CDR14 = TAUD014_COMPARE_VALUE;
    /* Set output mode setting */
    TAUD0.TOE |= TAUD_CHANNEL14_ENABLES_OUTPUT_MODE;
    TAUD0.TOM &= TAUD_CHANNEL14_INDEPENDENT_OUTPUT_MODE;
    TAUD0.TOC &= TAUD_CHANNEL14_OPERATION_MODE1;
    TAUD0.TOL &= TAUD_CHANNEL14_POSITIVE_LOGIC;
    TAUD0.TDE &= TAUD_CHANNEL14_DISABLE_DEAD_TIME_OPERATE;
    TAUD0.TDM &= TAUD_CHANNEL14_DETECTING_DUTY_CYCLE;
    TAUD0.TDL &= TAUD_CHANNEL14_NORMAL_PHASE;
    TAUD0.TRE &= TAUD_CHANNEL14_REAL_TIME_OUTPUT_DISABLES;
    /* Synchronization processing */
    g_cg_sync_read = TAUD0.TPS;
    __syncp();
}

/***********************************************************************************************************************
* Function Name: McuTaud0Ch14_Start
* Description  : This function starts the TAUD014 channel counter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuTaud0Ch14_Start(void)
{
    /* Clear INTTAUD0I14 request and enable operation */
    INTC1.ICTAUD0I14.BIT.RFTAUD0I14 = INT_REQUEST_NOT_OCCUR;
    INTC1.ICTAUD0I14.BIT.MKTAUD0I14 = INT_PROCESSING_ENABLED;
    /* Enable channel 14 counter operation */
    TAUD0.TS |= TAUD_CHANNEL14_COUNTER_START;
}

/***********************************************************************************************************************
* Function Name: McuTaud0Ch14_Stop
* Description  : This function stop the TAUD014 channel counter.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void McuTaud0Ch14_Stop(void)
{
    /* Disable channel 14 counter operation */
    TAUD0.TT |= TAUD_CHANNEL14_COUNTER_STOP;
    /* Disable INTTAUD0I14 operation and clear request */
    INTC1.ICTAUD0I14.BIT.MKTAUD0I14 = INT_PROCESSING_DISABLED;
    INTC1.ICTAUD0I14.BIT.RFTAUD0I14 = INT_REQUEST_NOT_OCCUR;
    /* Synchronization processing */
    g_cg_sync_read = TAUD0.TT;
    __syncp();
}

#pragma ghs interrupt(enabled)
void McuTaud0Ch14_Interrupt(void)
{
    /* Start user code for McuTaud0Ch14_Interrupt. Do not edit comment generated here */
    _100MicroTick++;
    /* End user code. Do not edit comment generated here */
}
/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
