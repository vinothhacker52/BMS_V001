/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                          
** File: McuClmaPrivate.h
**
** Description:
** Header file containing private macros for clock monitoring module(CLMA).
**---------------------------------------------------------------------------*/
#ifndef MCU_CLMA_PRIVATE_H
#define MCU_CLMA_PRIVATE_H
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/	
#define SAMPLING_CLOCK_CYCLE_COUNT	16.0f
#define PLL_JITTER			1.0f

/*Sampling Clock Frequencies*/
#define LS_OSC_FREQ		0x3A980						/* 240 Khz Low Speed Oscillator */ /* HD - Added description as suggested */
#define HS_OSC_FREQ		0x7A1200					/* 8 Mhz High Speed Oscillator */  /* HD - Added description as suggested */	

/* Replaced the macro with a functions to calculate lower and higher thresholds */

#define CLMA_ERROR_MASK_DISABLE_RESET	0x00000004	/* Error Mask Disable */
#define CLMA_ERROR_DETECTED		0x01

#endif	/* MCU_CLMA_PRIVATE_H */

/*--------------------------- End McuClmaPrivate.h -----------------------------*/
