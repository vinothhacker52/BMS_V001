/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                          
** File: McuClma.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for clock monitoring module(CLMA).
**---------------------------------------------------------------------------*/
#ifndef MCU_CLMA_H
#define MCU_CLMA_H

#include "McuMacroDriver.h"
#include "McuTypedefs.h"	

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/		

//enum to specify the CLMA control
typedef enum	MCU_CLMA_STATUS
{   
    DISABLE_CLMA	=	(0x00U),
    ENABLE_CLMA		=	(0x01U)
}McuClmaStatus;

//enum to specify the CLMA
typedef enum	MCU_CLMA_ID
{
    CLMA_0		=	(0x00U),
    CLMA_1		=	(0x01U),
    CLMA_3		=	(0x03U)
}McuClmaId;

//Stucture type to store CLMA Configuration
typedef struct	MCU_CLMA_CONFIG	
{
    McuClmaId 	clmaId;
    uint32_t 	clockFreq;
    uint8_t	tolerence;
}McuClmaConfig;
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void McuClmaInit		(McuClmaConfig *pMcuClmaConfig);
extern void McuClmaControl	(McuClmaId mcuClmaId, McuClmaStatus status);

#endif // MCU_CLMA_H

/*--------------------------- End McuClma.h -----------------------------*/
