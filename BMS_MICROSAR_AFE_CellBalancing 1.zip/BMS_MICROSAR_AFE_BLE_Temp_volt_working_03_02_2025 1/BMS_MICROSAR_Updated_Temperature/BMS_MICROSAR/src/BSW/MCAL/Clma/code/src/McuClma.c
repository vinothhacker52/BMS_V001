/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland                        
** File: McuClma.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of Clock Monitoring Module(CLMA).
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/


/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuClma.h"
#include "McuClmaPrivate.h"
#include "McuMacroDriver.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/

/* 1. MISRA C RULE VIOLATION:                                             	*/

/********************************************************************************/

/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

/* Formulas to get the upper and lower threshold of the monitored clock (User's Manual - pg: 1253) */
static float	GetMaxClockFrequecy	(uint32_t clockValue, uint8_t tol);
static float	GetMinClockFrequecy	(uint32_t clockValue, uint8_t tol);
static uint16_t CalculateUpperThreshold	(uint32_t mClock,uint32_t sClock, uint8_t tol);
static uint16_t CalculateLowerThreshold	(uint32_t mClock,uint32_t sClock, uint8_t tol);
// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: McuClmaInit()
**
** Description:
** Function to initialize clock monitor.
**
** Arguments:
** 1. pMcuClmaConfig : pointer to Clma config setting structure
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuClmaInit(McuClmaConfig *pMcuClmaConfig)
{
    /* CLMA0 : Monitoring High Speed Oscillator */
    if(pMcuClmaConfig->clmaId == CLMA_0)            
    {
	/* Disabling CLMA */
	McuClmaControl(CLMA_0,DISABLE_CLMA);

	/* Setting the lower and higher threshold values for HS Oscillator(8 Mhz)*/
	CLMA0.CMPH = CalculateUpperThreshold((pMcuClmaConfig->clockFreq),(LS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Higher threshold value */
	CLMA0.CMPL = CalculateLowerThreshold((pMcuClmaConfig->clockFreq),(LS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Lower threshold value */

    }

    /* CLMA1 : Monitoring Main Oscillator */
    else if(pMcuClmaConfig->clmaId == CLMA_1)       
    {
	/* Disabling CLMA */
	McuClmaControl(CLMA_1,DISABLE_CLMA);

	/* Setting the lower and higher threshold values for Main Oscillator(16 Mhz) */
	CLMA1.CMPH = CalculateUpperThreshold((pMcuClmaConfig->clockFreq),(LS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Higher threshold value */
	CLMA1.CMPL = CalculateLowerThreshold((pMcuClmaConfig->clockFreq),(LS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Lower threshold value */

    }




    /* CLMA3 : Monitoring PPLLOUT */
    else  /* (pMcuClmaConfig->clmaId == CLMA_3) */ 
    {
	/* Disabling the clock monitor */
	/* Disabling CLMA */
	McuClmaControl(CLMA_3,DISABLE_CLMA);

	/* Setting the lower and higher threshold value for PPLLCLK */
	CLMA3.CMPH = CalculateUpperThreshold((pMcuClmaConfig->clockFreq),(HS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Higher threshold value */
	CLMA3.CMPL = CalculateLowerThreshold((pMcuClmaConfig->clockFreq),(HS_OSC_FREQ),(pMcuClmaConfig->tolerence));		/* Lower threshold value */
    }

}/*--------------------------- End McuClmaInit () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuClmaControl()
**
** Description:
** Function to Enable/Disable clock monitoring.
**
** Arguments:
** 1. mcuClmaId : Clma module to Start/Stop
** 2. status    : Enable or Disable
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuClmaControl(McuClmaId mcuClmaId, McuClmaStatus status)
{
    /* CLMA0 */
    if(mcuClmaId == CLMA_0)
    {
	/* Enabling/Disabling CLMA */
	do
	{
	    CLMA0.PCMD = (uint8_t)WRITE_PROTECT_COMMAND;
	    CLMA0.CTL0 = (uint8_t)status;
	    CLMA0.CTL0 = ~((uint8_t)status);
	    CLMA0.CTL0 = (uint8_t)status;
	}while(WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);

	while (CLMA0.CTL0 != (uint8_t)status)
	{
	    NOP();
	}
    }


    /* CLMA1 */
    else if(mcuClmaId == CLMA_1)
    {

	/* Enabling/Disabling CLMA */
	do
	{
	    CLMA1.PCMD = (uint8_t)WRITE_PROTECT_COMMAND;
	    CLMA1.CTL0 = (uint8_t)status;
	    CLMA1.CTL0 = ~((uint8_t)status);
	    CLMA1.CTL0 = (uint8_t)status;
	}while(WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);

	while (CLMA1.CTL0 != (uint8_t)status)
	{
	    NOP();
	}
    }


    /* CLMA3 */
    else /* (mcuClmaId == CLMA_3) */
    {
	/* Enabling/Disabling CLMA */		
	do
	{
	    CLMA3.PCMD = (uint8_t)WRITE_PROTECT_COMMAND;
	    CLMA3.CTL0 = (uint8_t)status;
	    CLMA3.CTL0 = ~((uint8_t)status);
	    CLMA3.CTL0 = (uint8_t)status;
	}while(WPROTR.PROTS0  == WRITE_PROTECT_ERROR_OCCURED);

	while (CLMA3.CTL0 != (uint8_t)status)
	{
	    NOP();
	}
    }
}/*--------------------------- End McuClmaControl () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: GetMaxClockFrequecy()
**
** Description:
** Function to calculate the maximum clock frequency after adding the tolerence.
**
** Arguments:
** 1. clockValue : clock value in frequency.
** 2. tol	 : tolerence value in percentage(0-100)
**
** Return values:
** The clock frequency after adding the tolerence.
**---------------------------------------------------------------------------*/
static float GetMaxClockFrequecy(uint32_t clockValue, uint8_t tol)
{
    uint32_t clockMax;
    clockMax = clockValue + ((clockValue * tol) / 100);

    /* MISRA Violation: START Msg(MISRA_CLMA:1)*/
    return ((float)clockMax);
    /* END Msg(MISRA_CLMA:1) */
}/*--------------------------- End GetMaxClockFrequecy () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: GetMinClockFrequecy()
**
** Description:
** Function to calulate the minimum clock frequency after substracting the tolerence.
**
** Arguments:
** 1. clockValue : clock value in frequency.
** 2. tol	 : tolerence value in percentage(0-100)
**
** Return values:
** The clock frequency after substracting the tolerence.
**---------------------------------------------------------------------------*/
static float GetMinClockFrequecy(uint32_t clockValue, uint8_t tol)
{
    uint32_t clockMin;
    clockMin = clockValue - ((clockValue * tol) / 100 );

    /* MISRA Violation: START Msg(MISRA_CLMA:1)*/
    return (float)clockMin;
    /* END Msg(MISRA_CLMA:1) */
}/*--------------------------- End GetMinClockFrequecy () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: calculateUpperThreshold()
**
** Description:
** Function to calculate the upper threshold for the clock monitor.
**
** Arguments:
** 1. mClock 	: frequency of the monitored clock.
** 2. sClock 	: frequency of the sampling clock.
** 3. tol	: tolerence value in percentage(0-100)
**
** Return values:
** The upper threshold value.
**---------------------------------------------------------------------------*/
static uint16_t CalculateUpperThreshold(uint32_t mClock,uint32_t sClock, uint8_t tol)
{
    float upperThreshold;
    upperThreshold = (float)((GetMaxClockFrequecy(mClock,tol)/GetMinClockFrequecy(sClock,tol))*SAMPLING_CLOCK_CYCLE_COUNT + PLL_JITTER);

    return (uint16_t)upperThreshold;	/* The receiver of this value is a 16bit register. Hence the typecast */
}/*--------------------------- End calculateUpperThreshold () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: calculateLowerThreshold()
**
** Description:
** Function to calculate the lower threshold for the clock monitor.
**
** Arguments:
** 1. mClock 	: frequency of the monitored clock.
** 2. sClock 	: frequency of the sampling clock.
** 3. tol	: tolerence value in percentage(0-100)
**
** Return values:
** The lower threshold value.
**---------------------------------------------------------------------------*/
static uint16_t CalculateLowerThreshold(uint32_t mClock,uint32_t sClock, uint8_t tol)
{
    float lowerThreshold;
    lowerThreshold =(float)((GetMinClockFrequecy(mClock,tol)/GetMaxClockFrequecy(sClock,tol))*SAMPLING_CLOCK_CYCLE_COUNT - PLL_JITTER);

    return (uint16_t)lowerThreshold;	/* The receiver of this value is a 16bit register. Hence the typecast */
}/*--------------------------- End calculateLowerThreshold () -----------------------*/

/*--------------------------- End McuClma.c -----------------------------*/
