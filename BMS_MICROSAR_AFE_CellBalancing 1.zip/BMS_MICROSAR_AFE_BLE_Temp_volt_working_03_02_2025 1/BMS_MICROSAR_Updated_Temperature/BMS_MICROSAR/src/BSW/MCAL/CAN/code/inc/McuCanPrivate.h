/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: McuCanPrivate.h
**
** Description:
** Header file containing private macros for CAN module.
**---------------------------------------------------------------------------*/
#ifndef MCU_CAN_PRIVATE_H
#define MCU_CAN_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define TX_BUFFER 	1
#define TX_RX_FIFO	2
#define TX_MODE		TX_BUFFER
#define TX_ID_1		0x12344321
#define TX_ID_2		0x456
#define DATA_LENGTH	8
#define TRUE 1
#define FALSE 0

#define INPUT_BUFFER_PAYLOAD		0x00000006U		/* Receive buffer payload : 48 Byte*/
#define NUMBER_OF_RECEIVE_BUFFER	0x00000010U		/* Total of buffers : 11 */

#define CAN_ID_EXT		0x80000000U	/* CAN extended Id specifier */
#define ID_MASK			0x1FFFFFFFU	/* Mask to get the Id seperated from the Id register */
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

#endif /* MCU_CAN_PRIVATE_H */

/*--------------------------- End McuCanPrivate.h -----------------------------*/

