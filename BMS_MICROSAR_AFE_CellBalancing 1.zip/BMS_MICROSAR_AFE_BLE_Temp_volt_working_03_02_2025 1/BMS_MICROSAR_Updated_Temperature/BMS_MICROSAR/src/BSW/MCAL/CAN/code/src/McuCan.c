/*-----------------------------------------------------------------------------
**                           
** File: McuTauj3Ch1.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of the McuTauj3Ch1 module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/


/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "McuTypedefs.h"
#include "McuCan.h"
#include "McuCanPrivate.h"
#include "McuMacroDriver.h"
#include "SystemGpio.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/

/********************************************************************************/
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/
static uint16_t i;
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
void	McuCan0Init(void);		/* channel 0 intialization */
void	McuCan0Tx(
			uint32_t canId,
			McuCanMode canMode,
			uint8_t dataLength,
			uint8_t *pData,
			McuCanIdFormat canIdFormat
			);
void	McuCanGetData(uint8_t receiveBufferNumber, uint8_t *pdata);
void McuCanPinInit(void);
/*-----------------------------------------------------------------------------
** Function: McuCanPinInit
**
** Description:
** Initializes the Can Pinout configuration for Channel 0.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/

void McuCanPinInit(void)
{
     McuGpioPinConfig Can0Rx;
    McuGpioPinConfig McuCan0Tx;
        /* Set CAN0RX(P0_1) pin */
/*    PORT.PIBC0 &= PORT_CLEAR_BIT1;
 -     PORT.PBDC0 &= PORT_CLEAR_BIT1;
 -     PORT.PM0 |= PORT_SET_BIT1;
 -     PORT.PMC0 &= PORT_CLEAR_BIT1;
 -     PORT.PFC0 &= PORT_CLEAR_BIT1;
 -     PORT.PFCE0 |= PORT_SET_BIT1;
 -     PORT.PFCAE0 |= PORT_SET_BIT1;
 -     PORT.PMC0 |= PORT_SET_BIT1;*/


    Can0Rx.port           	    		= MCU_PORT_P0; 			/* Set the port */
    Can0Rx.pin 	            			= MCU_PIN_1;				/* Set the pin */
    Can0Rx.alt	 		        	= MCU_GPIO_ALT7;			/* Set the alternative function */
    Can0Rx.dir 	                		= MCU_GPIO_INPUT;	            	/* Set input/output mode *//*MCU_GPIO_INPUT;*/
    Can0Rx.portControl	     		= MCU_GPIO_SW_CONTROL;			/* I/O direction is controlled by portmode register */
    Can0Rx.pinOutputMode     		= MCU_GPIO_OPEN_DRAIN;			/* Set pin mode (Push-Pull or Open Drain)*/	
    Can0Rx.driveStrength 	    	= MCU_GPIO_LOW_DRIVE_STRENGTH;		/* Set drive strength*/
    Can0Rx.inputResistorConfig	= MCU_GPIO_FLOATING;			/* Set input resister as neither Pull-up nor Pull-down */
    Can0Rx.biDirectionControl		= MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;	/* Disabling bidirectional mode */
     McuGpioPortInit(&Can0Rx);

    /* Set McuCan0Tx(P0_0) pin */
/*    PORT.PIBC0 &= PORT_CLEAR_BIT0;
 -     PORT.PBDC0 &= PORT_CLEAR_BIT0;
 -     PORT.PM0 |= PORT_SET_BIT0;
 -     PORT.PMC0 &= PORT_CLEAR_BIT0;
 -     PORT.PFC0 |= PORT_SET_BIT0;
 -     PORT.PFCE0 &= PORT_CLEAR_BIT0;
 -     PORT.PFCAE0 &= PORT_CLEAR_BIT0;
 -     PORT.PMC0 |= PORT_SET_BIT0;
 -     PORT.PM0 &= PORT_CLEAR_BIT0;*/

     McuCan0Tx.port           	    		= MCU_PORT_P0; 			/* Set the port */
    McuCan0Tx.pin 	            			= MCU_PIN_0;				/* Set the pin */
    McuCan0Tx.alt	 		        	= MCU_GPIO_ALT2;			/* Set the alternative function */
    McuCan0Tx.dir 	                		= MCU_GPIO_OUTPUT;	            	/* Set input/output mode *//*MCU_GPIO_INPUT;*/
    McuCan0Tx.portControl	     		= MCU_GPIO_SW_CONTROL;			/* I/O direction is controlled by portmode register */
    McuCan0Tx.pinOutputMode     		= MCU_GPIO_OPEN_DRAIN;			/* Set pin mode (Push-Pull or Open Drain)*/	
    McuCan0Tx.driveStrength 	    	= MCU_GPIO_LOW_DRIVE_STRENGTH;		/* Set drive strength*/
    McuCan0Tx.inputResistorConfig	= MCU_GPIO_FLOATING;			/* Set input resister as neither Pull-up nor Pull-down */
    McuCan0Tx.biDirectionControl		= MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE;	/* Disabling bidirectional mode */
     McuGpioPortInit(&McuCan0Tx);

     SystemGpioWritePin(MCU_PORT_P8, MCU_PIN_3, MCU_GPIO_HIGH);
}

/*-----------------------------------------------------------------------------
** Function: McuCanInit
**
** Description:
** Initializes the Can Module Channel 3 and 4.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuCanInit(void)
{
    /*---------- Set CAN0 port pins -------------------*/
    McuCanPinInit();
/*while((RCFDC0.CFDGSTS.UINT32 && 0x04) = 0x00)
 - {*/
    RCFDC0.CFDGCTR.UINT32 	= 0x00000005U;			/* Setting the CAN module in global stop mode */
    RCFDC0.CFDC0CTR.UINT32 	= 0x00000002U;			/* Setting Channel stop mode to channel reset mode */
    RCFDC0.CFDGAFLCFG0.UINT32 	= 0x00000000U;			/* Initializing the number of rules for all the channels as 0 */
    RCFDC0.CFDC0FDCFG.UINT32	= 0x40000000U;;
    //RCFDC0.CFDC3FDCFG.UINT32 	= 0x40000000U;			/* Enabling Classic CAN only mode */

    //Global Status Register	
    while((RCFDC0.CFDGSTS.UINT8[LL] & 0x08U) == 0x08U)		/* Wait until CAN RAM is initialized */			/* !!!!!!! while((RCFDC0.CFDGSTS.UINT8[LL] && 0x04) == 0x04); */
    {
	NOP();
    }
    /* global stop status flag */
    /* Global Control Register */

    /* GSLPR-->0 other than stop mode */
    /* GSLPR-->1 stop mode */
    RCFDC0.CFDGCTR.UINT8[LL]      &= 0xFBU;  	 		/* Transition to global reset mode from global stop mode */

    while(RCFDC0.CFDGSTS.UINT8[LL] != 0x01U)			/* Wait until the CAN module transitions to global reset mode */
    {
	NOP();
    }


    /* Global Configuration Register */
    RCFDC0.CFDGCFG.UINT8[LL] = 0x10U;				/* xin clock selected */

    McuCan0Init();          					/* channel 0 intialization */
    

    //------------ Operating mode --------------------------------------

    RCFDC0.CFDGCTR.UINT8[LL] = 0x00U;      			/* Setting the CAN module into Global Operating Mode */
    //Global operating mode
    for(  i=0;i<0xfff;i++)  					/* Waiting for transition into Global Operating Mode */
    {
	NOP();
    }

    //Set RFE bit in global operating mode 
    RCFDC0.CFDRFCC0.UINT8[LL] |= 0x00U;      			/* receive FIFO is not used */		/* RCFDC0.CFDRFCC0.UINT8[LL] |= 0x00; */

    RCFDC0.CFDC0CTR.UINT8[LL] = 0x00U;   			/* Setting the CAN module into Global Operating Mode for Channel 3 */
    //channel communication mode

    for(  i=0;i<0xfff;i++)  					/* Waiting for transition into Global Operating Mode */
    {
	NOP();
    }
//}
}/*--------------------------- End McuCanInit () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuCan0Init
**
** Description:
** Initializes the Can Module Channel 3.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void	McuCan0Init(void)
{
    /* Channel Control Register */
    /* Channel 3 */
    RCFDC0.CFDC0CTR.UINT8[LL] &= 0xFBU;   			/* Setting the Channel into Reset mode from Channel Stop mode */ /* Configuration of Global Stop sets the channels automatically in stop mode */
    /*
      CSLPR-->0 other than stop mode
      CSLPR-->1 stop mode
      */
    while((RCFDC0.CFDC0STS.UINT8[LL] & 0x07U) != 0x01U)		/* Waiting for transition into Channel reset Mode */
    {
	NOP();
    }

    RCFDC0.CFDC0FDCFG.UINT8[HH] &= 0xAFU;			/* Configuring the channel in CAN-FD mode */

    /**********************************Baud settings for 16MHz clock**********************************/
    /* Nominal bit rate */
    RCFDC0.CFDC0NCFG.UINT32 = 0x030A0801U;			/* 500kbps, 16Tq, Prescalar:1Tq, SEG2:4Tq, SEG1:11Tq, 75% sampling, SJW: 1Tq (=>2) */
    /* Data bit rate */
    RCFDC0.CFDC0DCFG.UINT32 = 0x013A0001U; 		   	/* 500kbps, 16Tq, Prescalar:1Tq, SEG2:4Tq, SEG1:11Tq, 75% sampling, SJW: 1Tq */


    /******************************************Receive Rules******************************************/
    /* Receive Rule Configuration Register */
    /* Channel 3 */
    RCFDC0.CFDGAFLCFG0.UINT8[HH] = 0x10U;    			/* No. of rules for channel 0 is set to 16 */

    RCFDC0.CFDGAFLECTR.UINT8[LH] = 0x01U;   			/* Enabling write to receive rule table */
    RCFDC0.CFDGAFLECTR.UINT8[LL] = 0x00U;   			/* Selecting the Page number 0 to add receive rules to */

					/* receive rule 1 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID0.UINT32 |= 0x8CF00400U; 			/* EEC1 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM0.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_0.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_0.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_0.UINT8[LH] |= 0x00U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 2 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID1.UINT32 |= 0x8CF00300U; 			/* EEC2 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM1.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_1.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_1.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_1.UINT8[LH] |= 0x40U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 3 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID2.UINT32 |= 0x98FEDF00U; 			/* EEC3 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM2.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_2.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_2.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_2.UINT8[LH] |= 0x41U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 4 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID3.UINT32 |= 0x98FEF100U; 			/* CCVS_ENG (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM3.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_3.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_3.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_3.UINT8[LH] |= 0x42U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 5 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID4.UINT32 |= 0x98FEF500U; 			/* AMB (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM4.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_4.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_4.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_4.UINT8[LH] |= 0x43U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 6 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID5.UINT32 |= 0x98F0010BU; 			/* EBC1 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM5.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_5.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_5.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_5.UINT8[LH] |= 0x44U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 7 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID6.UINT32 |= 0x98FEBF0BU; 			/* EBC2 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM6.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_6.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_6.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_6.UINT8[LH] |= 0x45U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 8 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID7.UINT32 |= 0x8C010305U; 			/* KA SHIFTER (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM7.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_7.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_7.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_7.UINT8[LH] |= 0x46U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 9 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID8.UINT32 |= 0x98FEF63DU; 			/* IC1 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM8.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_8.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_8.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_8.UINT8[LH] |= 0x47U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 10 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID9.UINT32 |= 0x98FEF000U; 			/* PTO_ENG (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM9.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_9.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_9.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_9.UINT8[LH] |= 0x48U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 11 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID10.UINT32 |= 0x98EBFF00U; 			/* TPDT-EC1 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM10.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_10.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_10.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_10.UINT8[LH] |= 0x49U;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 12 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID11.UINT32 |= 0x98ECFF00U; 			/* TPCM-EC1 (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM11.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_11.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_11.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_11.UINT8[LH] |= 0x4AU;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 13 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID12.UINT32 |= 0x98FEE300U; 			/* Dummy (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM12.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_12.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_12.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_12.UINT8[LH] |= 0x4BU;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 14 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID13.UINT32 |= 0x91234567U; 			/* Dummy (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM13.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_13.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_13.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_13.UINT8[LH] |= 0x4CU;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 15 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID14.UINT32 |= 0x91234568U; 			/* Dummy (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM14.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_14.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_14.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_14.UINT8[LH] |= 0x4DU;			/* Configuring receive buffer 0 to store the data from the ID */


					/* receive rule 16 */
    /* Receive Rule ID Register */
    RCFDC0.CFDGAFLID15.UINT32 |= 0x91234569U; 			/* Dummy (Extended ID)*/

    /* Receive Rule Mask Register */
    RCFDC0.CFDGAFLM15.UINT32 |= 0x9FFFFFFFU;   		 	/* ID bits are compared compared */ 

    /* Receive Rule Pointer 0 Register */
    RCFDC0.CFDGAFLP0_15.UINT8[LL] &= 0x00U;   			/* DLC Check is disabled. */
    RCFDC0.CFDGAFLP0_15.UINT8[LH] |= 0x80U;   			/* Configuring to use receive buffer */
    RCFDC0.CFDGAFLP0_15.UINT8[LH] |= 0x4EU;			/* Configuring receive buffer 0 to store the data from the ID */



    /* Receive rule entry control register */
    RCFDC0.CFDGAFLECTR.UINT8[LH] = 0x00U; 			/* Disabling write to receive rule table */

    /***************************************End of Receive Rule***************************************/


    /***************************************Buffer Configuration***************************************/
    /* Configuring the receive buffer setting */
    /*
     -> Setting the payload of the input buffer as 48 bytes
     -> Setting the number of receive buffer to 13.
     */
    RCFDC0.CFDRMNB.UINT32 = INPUT_BUFFER_PAYLOAD | NUMBER_OF_RECEIVE_BUFFER;     

}/*--------------------------- End McuCan0Init () -----------------------*/




/*-----------------------------------------------------------------------------
** Function: can4Init
**
** Description:
** Initializes the Can Module Channel 3.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
McuCanBufferReceiveStatus McuCanReadMsgReceiveStatus(uint8_t receiveBufferNumber)
{
 
    McuCanBufferReceiveStatus  bufferStatus = MCU_CAN_BUFFER_MESSAGE_NOT_RECEIVED;
#if 1
    switch(receiveBufferNumber)
    {
	case 63:	/* EEC1 */					
	    if((RCFDC0.CFDRMND1.UINT8[HH] & 0x80U) == 0x80U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 64:	/* EEC2 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x01U) == 0x01U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 65:	/* EEC3 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x02U) == 0x02U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 66:	/* CCVS_ENG */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x04U) == 0x04U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 67:	/* AMB */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x08U) == 0x08U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 68:	/* EBC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x10U) == 0x10U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 69:	/* EEBC2 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x20U) == 0x20U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 70:	/* KA SHIFTER */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x40U) == 0x40U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 71:	/* IC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x80U) == 0x80U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 72:	/* PTO_ENG */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x01U) == 0x01U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 73:	/* TPDT_EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x02U) == 0x02U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 74:	/* TPCM_EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x04U) == 0x04U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	case 75:	/* EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x08U) == 0x08U)
	    {
		bufferStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
	    }
	    break;
	default:
	    /* default case */
	    break;
    }
#endif
    return bufferStatus;

}


/*-----------------------------------------------------------------------------
** Function: McuCan0Tx
**
** Description:
** Funciton to perform CAN transmission operation.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuCanTx(
		     McuCanChannel canChannel,
		     uint32_t canId,
		     McuCanMode canMode,
		     uint8_t dataLength,
		     uint8_t *pData,
		     McuCanIdFormat canIdFormat
		     )
{
    if(canChannel == MCU_CHANNEL_0)
    {
	McuCan0Tx(
	canId,
	canMode,
	dataLength,
	pData,
	canIdFormat
	);
    }
    else
    {
	
    }

}


/*-----------------------------------------------------------------------------
** Function: McuCan0Tx
**
** Description:
** Funciton to perform CAN transmission operation for Channel 4.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static	void	McuCan0Tx(
	uint32_t canId,
	McuCanMode canMode,
	uint8_t dataLength,
	uint8_t *pData,
	McuCanIdFormat canIdFormat
	)
{
#if 1

	RCFDC0.CFDTMSTS0 = 0x00U;		/* Transmission is in progress */
	RCFDC0.CFDTMIEC0.UINT16[L] = 0x0000U;	/* Disabling the interrupt */

	if(canIdFormat == MCU_CAN_EXTENDED)
	{
	    /* Configuring as extended Id Format */
	    /* Transmit buffer ID register */
	    RCFDC0.CFDTMID0.UINT32 = canId | CAN_ID_EXT;

	}
	else
	{
	    /* Standard ID */
	    RCFDC0.CFDTMID0.UINT32 = canId;
	}

	if(canMode == MCU_CAN_FD)
	{
	    RCFDC0.CFDTMFDCTR0.UINT8[LL] |= 0x04U;		/* Setting as CAN_FD */
	    RCFDC0.CFDTMFDCTR0.UINT8[LL] |= 0x02U;     	/* BRS is enabled */
	    if(dataLength >= 12)
	    {
		switch(dataLength)
		{
		    case 12:
			dataLength = 9;
			break;
		    case 16:
			dataLength = 10;
			break;
		    case 20:
			dataLength = 11;
			break;
		    case 24:
			dataLength = 12;
			break;
		    case 32:
			dataLength = 13;
			break;
		    case 48:
			dataLength = 14;
			break;
		    case 64:
			dataLength = 15;
			break;
		    default :
			/* default case */
			break;
		}

	    }
	}
	else
	{
	    RCFDC0.CFDTMFDCTR0.UINT8[LL] |= 0x00U;		/* Setting as Normal CAN */
	    RCFDC0.CFDTMFDCTR0.UINT8[LL] |= 0x00U;     	/* BRS is disabled */
	}

	/* Transmit buffer pointer register */
	RCFDC0.CFDTMPTR0.UINT8[HH] = dataLength<<4;   // DLC: 8 data bytes.

	/* Transmit buffer data field register */
	RCFDC0.CFDTMDF0_0.UINT8[LL] = (*pData++);
	RCFDC0.CFDTMDF0_0.UINT8[LH] = (*pData++);
	RCFDC0.CFDTMDF0_0.UINT8[HL] = (*pData++);
	RCFDC0.CFDTMDF0_0.UINT8[HH] = (*pData++);
     
	RCFDC0.CFDTMDF1_0.UINT8[LL] = (*pData++);
	RCFDC0.CFDTMDF1_0.UINT8[LH] = (*pData++);
	RCFDC0.CFDTMDF1_0.UINT8[HL] = (*pData++);
	RCFDC0.CFDTMDF1_0.UINT8[HH] = (*pData++);

      
	//Transmit buffer status register
      	RCFDC0.CFDTMC0 = 0x01U;         // Transmission requested - TMTR bit

#endif
}/*--------------------------- End McuCan0Tx () -----------------------*/




/*-----------------------------------------------------------------------------
** Function: McuCanRx
**
** Description:
** Funciton to extract the receive message Id, CAN mode, data length of the
** message, CAN, channel and the Data received.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/

McuCanRxMsg McuCanRx(uint8_t receiveBufferNumber)
{

    McuCanRxMsg canRxMsg = {0};
    canRxMsg.receiveStatus  = MCU_CAN_BUFFER_MESSAGE_NOT_RECEIVED;
    /* Check for reception in buffers 0 to 15 */
    switch(receiveBufferNumber)
    {

	case 0:	/* EEC1 */					
	    if((RCFDC0.CFDRMND0.UINT8[LL] & 0x01U) == 0x01U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND0.UINT8[LL] &= 0xFEU;
		canRxMsg.canId = (RCFDC0.CFDRMID0.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID0.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR0.UINT8[HH]>>4;		/* !!!!! */

		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;

	case 1:	/* EEC2 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x01U) == 0x01U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xFEU;
		canRxMsg.canId = (RCFDC0.CFDRMID1.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID1.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR1.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;

	case 2:	/* EEC3 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x02U) == 0x02U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xFDU;
		canRxMsg.canId = (RCFDC0.CFDRMID2.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID2.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR2.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 3:	/* CCVS_ENG */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x04U) == 0x04U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xFBU;
		canRxMsg.canId = (RCFDC0.CFDRMID3.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID3.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR3.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 4:	/* AMB */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x08U) == 0x08U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xF7U;
		canRxMsg.canId = (RCFDC0.CFDRMID4.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID4.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR4.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;

	case 5:	/* EBC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x10U) == 0x10U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xEFU;
		canRxMsg.canId = (RCFDC0.CFDRMID5.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID5.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR5.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 6:	/* EEBC2 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x20U) == 0x20U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xDFU;
		canRxMsg.canId = (RCFDC0.CFDRMID6.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID6.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR6.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 7:	/* KA SHIFTER */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x40U) == 0x40U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0xBFU;
		canRxMsg.canId = (RCFDC0.CFDRMID7.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID7.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR23.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 8:	/* IC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LL] & 0x80U) == 0x80U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LL] &= 0x7FU;
		canRxMsg.canId = (RCFDC0.CFDRMID8.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID8.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR8.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 9:	/* PTO_ENG */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x01U) == 0x01U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xFEU;
		canRxMsg.canId = (RCFDC0.CFDRMID9.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID9.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR9.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 10:	/* TPDT_EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x02U) == 0x02U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xFDU;
		canRxMsg.canId = (RCFDC0.CFDRMID10.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID10.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR10.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 11:	/* TPCM_EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x04U) == 0x04U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xFBU;
		canRxMsg.canId = (RCFDC0.CFDRMID11.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID11.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR11.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 12:	/* EC1 */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x08U) == 0x08U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xF7U;
		canRxMsg.canId = (RCFDC0.CFDRMID12.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID12.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR12.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 13:	/* Dummy */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x10U) == 0x10U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xEFU;
		canRxMsg.canId = (RCFDC0.CFDRMID13.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID13.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR13.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 14:	/* Dummy */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x20U) == 0x20U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xDFU;
		canRxMsg.canId = (RCFDC0.CFDRMID14.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID14.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR14.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	case 15:	/* Dummy */
	    if((RCFDC0.CFDRMND1.UINT8[LH] & 0x40U) == 0x40U)
	    {
		canRxMsg.canChannel = MCU_CHANNEL_0;
		canRxMsg.receiveStatus = MCU_CAN_BUFFER_MESSAGE_RECEIVED;
		RCFDC0.CFDRMND1.UINT8[LH] &= 0xBFU;
		canRxMsg.canId = (RCFDC0.CFDRMID15.UINT32 & ID_MASK);
		/* MISRA Violation: START Msg(MISRA_CAN:0) */
		canRxMsg.canMode = (McuCanMode)(RCFDC0.CFDRMID15.UINT8[HH]>>7);
		/* END Msg(MISRA_CAN:0) */
		canRxMsg.dataLength = RCFDC0.CFDRMPTR15.UINT8[HH]>>4;		/* !!!!! */
    
		McuCanGetData(receiveBufferNumber,canRxMsg.data);
	    }
	    break;
	default:
	    /* default case */
	    break;
    }
	
    return canRxMsg;
}/*--------------------------- End McuCanRx () -----------------------*/


 #if 1
/*-----------------------------------------------------------------------------
** Function: McuCanGetData
**
** Description:
** Funciton to perform CAN transmission operation for Channel 3.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void McuCanGetData(uint8_t receiveBufferNumber, uint8_t *pdata)
{
    switch(receiveBufferNumber)
    {
	case 0:
	    pdata[0] = RCFDC0.CFDRMDF0_0.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_0.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_0.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_0.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_0.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_0.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_0.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_0.UINT8[HH];
	    break;
	case 1:
	    pdata[0] = RCFDC0.CFDRMDF0_1.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_1.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_1.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_1.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_1.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_1.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_1.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_1.UINT8[HH];
	    break;
	case 2:
	    pdata[0] = RCFDC0.CFDRMDF0_2.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_2.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_2.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_2.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_2.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_2.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_2.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_2.UINT8[HH];
	    break;
	case 3:
	    pdata[0] = RCFDC0.CFDRMDF0_3.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_3.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_3.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_3.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_3.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_3.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_3.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_3.UINT8[HH];
	    break;
	case 4:
	    pdata[0] = RCFDC0.CFDRMDF0_4.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_4.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_4.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_4.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_4.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_4.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_4.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_4.UINT8[HH];
	    break;
	case 5:
	    pdata[0] = RCFDC0.CFDRMDF0_5.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_5.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_5.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_5.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_5.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_5.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_5.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_5.UINT8[HH];
	    break;
	case 6:
	    pdata[0] = RCFDC0.CFDRMDF0_6.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_6.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_6.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_6.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_6.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_6.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_6.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_6.UINT8[HH];
	    break;
	case 7:
	    pdata[0] = RCFDC0.CFDRMDF0_7.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_7.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_7.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_7.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_7.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_7.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_7.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_7.UINT8[HH];
	    break;
	case 8:
	    pdata[0] = RCFDC0.CFDRMDF0_8.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_8.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_8.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_8.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_8.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_8.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_8.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_8.UINT8[HH];
	    break;
	case 9:
	    pdata[0] = RCFDC0.CFDRMDF0_9.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_9.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_9.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_9.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_9.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_9.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_9.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_9.UINT8[HH];
	    break;
    case 10:
	    pdata[0] = RCFDC0.CFDRMDF0_10.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_10.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_10.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_10.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_10.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_10.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_10.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_10.UINT8[HH];
	    break;
	case 11:
	    pdata[0] = RCFDC0.CFDRMDF0_11.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_11.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_11.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_11.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_11.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_11.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_11.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_11.UINT8[HH];
	    break;
	case 12:
	    pdata[0] = RCFDC0.CFDRMDF0_12.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_12.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_12.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_12.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_12.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_12.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_12.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_12.UINT8[HH];

	    pdata[8] = RCFDC0.CFDRMDF2_12.UINT8[LL];
	    pdata[9] = RCFDC0.CFDRMDF2_12.UINT8[LH];
	    pdata[10] = RCFDC0.CFDRMDF2_12.UINT8[HL];
	    pdata[11] = RCFDC0.CFDRMDF2_12.UINT8[HH];

	    pdata[12] = RCFDC0.CFDRMDF3_12.UINT8[LL];
	    pdata[13] = RCFDC0.CFDRMDF3_12.UINT8[LH];
	    pdata[14] = RCFDC0.CFDRMDF3_12.UINT8[HL];
	    pdata[15] = RCFDC0.CFDRMDF3_12.UINT8[HH];

	    pdata[16] = RCFDC0.CFDRMDF4_12.UINT8[LL];
	    pdata[17] = RCFDC0.CFDRMDF4_12.UINT8[LH];
	    pdata[18] = RCFDC0.CFDRMDF4_12.UINT8[HL];
	    pdata[19] = RCFDC0.CFDRMDF4_12.UINT8[HH];

	    pdata[20] = RCFDC0.CFDRMDF5_12.UINT8[LL];
	    pdata[21] = RCFDC0.CFDRMDF5_12.UINT8[LH];
	    pdata[22] = RCFDC0.CFDRMDF5_12.UINT8[HL];
	    pdata[23] = RCFDC0.CFDRMDF5_12.UINT8[HH];

	    pdata[24] = RCFDC0.CFDRMDF6_12.UINT8[LL];
	    pdata[25] = RCFDC0.CFDRMDF6_12.UINT8[LH];
	    pdata[26] = RCFDC0.CFDRMDF6_12.UINT8[HL];
	    pdata[27] = RCFDC0.CFDRMDF6_12.UINT8[HH];

	    pdata[28] = RCFDC0.CFDRMDF7_12.UINT8[LL];
	    pdata[29] = RCFDC0.CFDRMDF7_12.UINT8[LH];
	    pdata[30] = RCFDC0.CFDRMDF7_12.UINT8[HL];
	    pdata[31] = RCFDC0.CFDRMDF7_12.UINT8[HH];

	    pdata[32] = RCFDC0.CFDRMDF8_12.UINT8[LL];
	    pdata[33] = RCFDC0.CFDRMDF8_12.UINT8[LH];
	    pdata[34] = RCFDC0.CFDRMDF8_12.UINT8[HL];
	    pdata[35] = RCFDC0.CFDRMDF8_12.UINT8[HH];

	    pdata[36] = RCFDC0.CFDRMDF9_12.UINT8[LL];
	    pdata[37] = RCFDC0.CFDRMDF9_12.UINT8[LH];
	    pdata[38] = RCFDC0.CFDRMDF9_12.UINT8[HL];
	    pdata[39] = RCFDC0.CFDRMDF9_12.UINT8[HH];
	    break;
	case 13:
	    pdata[0] = RCFDC0.CFDRMDF0_13.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_13.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_13.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_13.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_13.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_13.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_13.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_13.UINT8[HH];
	     break;
	case 14:
	    pdata[0] = RCFDC0.CFDRMDF0_14.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_14.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_14.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_14.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_14.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_14.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_14.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_14.UINT8[HH];
	     break;
	case 15:
	    pdata[0] = RCFDC0.CFDRMDF0_15.UINT8[LL];
	    pdata[1] = RCFDC0.CFDRMDF0_15.UINT8[LH];
	    pdata[2] = RCFDC0.CFDRMDF0_15.UINT8[HL];
	    pdata[3] = RCFDC0.CFDRMDF0_15.UINT8[HH];

	    pdata[4] = RCFDC0.CFDRMDF1_15.UINT8[LL];
	    pdata[5] = RCFDC0.CFDRMDF1_15.UINT8[LH];
	    pdata[6] = RCFDC0.CFDRMDF1_15.UINT8[HL];
	    pdata[7] = RCFDC0.CFDRMDF1_15.UINT8[HH];
	     break;
	default:
	    /* default case */
	    break;

    }
    #endif
}/*--------------------------- End McuCanGetData () -----------------------*/


/*--------------------------- End McuCan.c -----------------------------*/
