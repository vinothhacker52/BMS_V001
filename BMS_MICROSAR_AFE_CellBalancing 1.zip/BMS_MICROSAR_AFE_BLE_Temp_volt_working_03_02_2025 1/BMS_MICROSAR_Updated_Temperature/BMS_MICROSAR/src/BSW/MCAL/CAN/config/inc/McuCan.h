/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: McuAdc.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for CAN module.
**---------------------------------------------------------------------------*/
#ifndef MCU_CAN_H
#define MCU_CAN_H

#include "McuTypedefs.h"
#include "McuGpio.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
/* Can Channel Selection */
typedef enum MCU_CAN_CHANNEL
{
    MCU_CHANNEL_0	= 0,
    MCU_CHANNEL_1	= 1,
    MCU_CHANNEL_2	= 2,
    MCU_CHANNEL_3	= 3,
    MCU_CHANNEL_4	= 4
}McuCanChannel;

/* Can Mode Selection */
typedef enum MCU_CAN_MODE
{
	MCU_CAN		= 0,
	MCU_CAN_FD	= 1
}McuCanMode;

// can ID type structure
typedef enum MCU_CAN_ID_FORMAT
{
	 MCU_CAN_STANDARD	= 0,
	 MCU_CAN_EXTENDED	= 1
}McuCanIdFormat;


typedef enum MCU_CAN_BUFFER_RECEIVE_STATUS
{
    MCU_CAN_BUFFER_MESSAGE_NOT_RECEIVED	= 0,
    MCU_CAN_BUFFER_MESSAGE_RECEIVED	= 1
}McuCanBufferReceiveStatus;

typedef struct	MCU_CAN_RX_MSG
{
    McuCanChannel canChannel;
    McuCanBufferReceiveStatus receiveStatus;
    McuCanMode canMode;
    uint32_t canId;
    uint8_t dataLength;
    uint8_t data[64];
}McuCanRxMsg;


/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void McuCanInit(void);
extern void McuCanTx(
			 McuCanChannel canChannel,
			 uint32_t canId,
			 McuCanMode canMode,
			 uint8_t dataLength,
			 uint8_t *pData,
			 McuCanIdFormat canIdFormat
		     );
extern McuCanRxMsg McuCanRx(uint8_t receiveBufferNumber);
extern McuCanBufferReceiveStatus McuCanReadMsgReceiveStatus(uint8_t receiveBufferNumber);
extern	void	McuCan0Init(void);
#endif /* MCU_CAN_H */

/*--------------------------- End McuCan.h -----------------------------*/

