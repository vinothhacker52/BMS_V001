/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: McuAdc.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for ADC module.
**---------------------------------------------------------------------------*/
#ifndef MCU_ADC_H
#define MCU_ADC_H

#include "McuTypedefs.h"
#include "McuGpio.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define ADC0_SG1_START_POINTER		(0x00000000UL)		/* First Virtual Channel */
#define ADC0_SG1_END_POINTER            (0x0000000AUL)		/* Last Virtual Channel */

/* 12/10 bit select mode (CTYP) */
typedef enum ADC_BIT_MODE		/* Configuring this set the bit select mode as either 12 but or 10 bits according to the selection */
{
    ADC_12_BIT_MODE		=	(0x00000000UL), /* 12-bit mode */
    ADC_10_BIT_MODE		=	(0x00000010UL) /* 10-bit mode */
}AdcBitMode;

/*
  Sampling Control Register (ADCAnSMPCR)
  */
typedef enum ADC_SAMPLING_TIME
{
    ADC_SAMPLING_18_CYCLES	=	(0x00000012UL),  /* 18 cycles (PCLK = 8 MHz to 32 MHz) */
    ADC_SAMPLING_24_CYCLES	=	(0x00000018UL) 	 /* 24 cycles (PCLK = 8 MHz to 40 MHz) */
}AdcSamplingTime;

//enum data type to store the status of ADC
typedef enum ADC_STATUS
{
    ADC_OK			= 	(0x00U),	/* ADC status OK */
    ADC_NOT_OK			= 	(0x01U)		/* ADC status Not OK */
}McuAdcStatus;

typedef struct ADC_CONFIG
{
    AdcSamplingTime	samplingTime;	/*18 or 24 cycles*/
    AdcBitMode 		bitSelection;	/*10 or 12 bit mode*/
}McuAdcConfig;
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void 		McuAdc0Init		(McuAdcConfig *pAdcConfig);
extern void 		McuAdc0Halt		(void);
extern void 		McuAdc0Sg1Start		(void);
extern void 		McuAdc0Sg1Stop		(void);
extern McuAdcStatus 	McuAdc0Sg1GetResult	(uint16_t * pBuffer, uint8_t bufferSize);
extern McuAdcStatus 	McuAdc0ChannelGetResult	(uint16_t * pBuffer, uint8_t channelNo);

#endif /* MCU_ADC_H */

/*--------------------------- End McuAdc.h -----------------------------*/

