/*-----------------------------------------------------------------------------
**                             � 2025 Ashok Leyland
** File: McuAdc.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of ADC.
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                               **
*****************************************************************************************************************************************/
/* Files : McuAdc.c, McuAdc.h and McuAdcDefines.h
 * 
 *

 */
/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "McuAdc.h"
#include "McuAdcPrivate.h"
#include "McuMacroDriver.h"
/******************************************************************************
**                         MISRA C Rule Violations                           **
******************************************************************************/

/* 1. MISRA C RULE VIOLATION:                                                */
/* Message       :                                                           */
/* Rule          :                                                           */
/* Justification :                                                           */
/* Verification  :                                                           */
/* Reference     :                                                           */
/*****************************************************************************/

/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define LOWER_DATA_FIELD	0x0000FFFFUL
#define HIGHER_DATA_FIELD	0xFFFF0000UL
/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: McuAdc0Init()
**
** Description:
** This function initializes the ADC0 module.
**
** Arguments:
** 1. pAdcConfig : Pointer to the function that stores the configuration for
**		   the ADC module.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuAdc0Init(McuAdcConfig *pAdcConfig)
{
    McuGpioPinConfig adc0Ch0,adc0Ch1,adc0Ch2,adc0Ch3,adc0Ch4,adc0Ch5,adc0Ch6;
    /* Set APORT0_0(A0_0) pin */
    adc0Ch0.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch0.pin                  = MCU_PIN_0;                /* Set the pin */
    adc0Ch0.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch0.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch0.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch0.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch0.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch0.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch0.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch0);

     /* Set APORT0_1(A0_1) pin */
    adc0Ch1.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch1.pin                  = MCU_PIN_1;                /* Set the pin */
    adc0Ch1.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch1.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch1.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch1.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch1.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch1.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch1.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch1);
    /* Set APORT0_2(A0_2) pin */
    adc0Ch2.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch2.pin                  = MCU_PIN_2;                /* Set the pin */
    adc0Ch2.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch2.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch2.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch2.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch2.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch2.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch2.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch2);
    /* Set APORT0_3(A0_3) pin */
    adc0Ch3.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch3.pin                  = MCU_PIN_3;                /* Set the pin */
    adc0Ch3.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch3.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch3.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch3.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch3.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch3.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch3.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch3);
    /* Set APORT0_4(A0_4) pin */
    adc0Ch4.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch4.pin                  = MCU_PIN_4;                /* Set the pin */
    adc0Ch4.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch4.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch4.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch4.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch4.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch4.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch4.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch4);
    /* Set APORT0_5(A0_5) pin */
    adc0Ch5.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch5.pin                  = MCU_PIN_5;                /* Set the pin */
    adc0Ch5.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch5.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch5.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch5.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch5.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch5.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch5.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch5);
    /* Set APORT0_6(A0_6) pin */
    adc0Ch6.port                 = MCU_APORT0;          /* Set the port */
    adc0Ch6.pin                  = MCU_PIN_6;                /* Set the pin */
    adc0Ch6.dir                  = MCU_GPIO_INPUT;                   /* Set input/output mode *//*MCU_GPIO_INPUT;*/
    adc0Ch6.alt                  = MCU_GPIO_ALT_DEFAULT;            /* Set the alternative function */
    adc0Ch6.portControl          = MCU_GPIO_SW_CONTROL;          /* I/O direction is controlled by portmode register */
    adc0Ch6.pinOutputMode        = MCU_GPIO_PUSH_PULL;           /* Set pin mode (Push-Pull or Open Drain)*/
    adc0Ch6.driveStrength        = MCU_GPIO_LOW_DRIVE_STRENGTH;      /* Set drive strength*/
    adc0Ch6.inputResistorConfig  = MCU_GPIO_FLOATING;            /* Set input resister as neither Pull-up nor Pull-down */
    adc0Ch6.biDirectionControl   = MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE; /* Disabling bidirectional mode */
    McuGpioPortInit(&adc0Ch6);

    volatile uint32_t g_cg_sync_read;
    /* Disable ADC0 error interrupt (INTADCA0ERR) operation and clear request */
    INTC2.ICADCA0ERR.BIT.MKADCA0ERR = INT_PROCESSING_DISABLED;
    INTC2.ICADCA0ERR.BIT.RFADCA0ERR =  INT_REQUEST_NOT_OCCUR;
    /* Set ADC0 global setting */
    /*
     -> Disabling interrupt
     -> Disabling table limit check
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR00.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI00 | ADC_MPX_DISABLE;		
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR01.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI01 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR02.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI02 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR03.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI03 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR04.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI04 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR05.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI05 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR06.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI06 |  ADC_MPX_DISABLE;
    /*
     -> Disabling virtual channel end interrupt
     -> Disabling table limit check (Do we need this turned on?)
     -> Selecting the physical Channel
     -> Disabling multiplex
     */
    ADCA0.VCR07.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI07 |  ADC_MPX_DISABLE;

    ADCA0.VCR08.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI08 |  ADC_MPX_DISABLE;

    ADCA0.VCR09.UINT32 = ADC_VIRTUAL_CHANNEL_END_INT_DISABLE | ADC_LIMIT_TABLE_SELECT_NONE | 
	ADC_PHYSICAL_CHANNEL_ANI09 |  ADC_MPX_DISABLE;

    ADCA0.ADCR.UINT32 = ADC_SELF_DIAG_VOLTAGE_CIRCUIT_OFF | ADC_RIGHT_ALIGNED | (uint32_t)pAdcConfig->bitSelection | ADC_SYNC_SUSPEND;	
    ADCA0.SMPCR.UINT32 = (uint32_t)pAdcConfig->samplingTime;

    /*
    ***Safety Control***
    -> Disabling read clear
    -> Disabling limit error detection interrupt
    -> Disabling overwrite error detection interrupt
    */
    ADCA0.SFTCR.UINT32 = ADC_READ_CLEAR_DISABLE | ADC_OVERWRITE_ERROR_INT_DISABLE | ADC_LIMIT_ERROR_INT_DISABLE;

    /*Removed the Upper and Lower limit table configuration as we are not using this*/

    /* Set ADC0 scan group setting */
    /*
     -> Setting the scan mode setting of the scan group as continuous.
     -> Disabling scan end interrupt.
     */
    ADCA0.SGCR1.UINT32 = ADC_SG_SCAN_MODE_CONTINUOUS | ADC_SG_SCAN_END_INT_DISABLE | ADC_SG_CHANNEL_REPEAT_TIME_1;

    ADCA0.SGVCSP1.UINT32 = ADC0_SG1_START_POINTER; 			
    ADCA0.SGVCEP1.UINT32 = ADC0_SG1_END_POINTER;
    ADCA0.SGMCYCR1.UINT32 = ADC_SG_MULTICYCLE_NUMBER_1;
    ADCA0.SGCR1.UINT32 |= ADC_SG_HW_TRIGGER_DISABLE;

    /*Disabling all the Track and hold circuits*/
    ADCA0.THER.UINT32 = ADC_TH4_DISABLED | ADC_TH2_DISABLED | ADC_TH0_DISABLED | ADC_TH2_DISABLED | ADC_TH1_DISABLED | ADC_TH0_DISABLED;

    /* Synchronization processing */
    g_cg_sync_read = ADCA0.ADHALTR.UINT32;
    __syncp();

}/*--------------------------- End McuAdc0Init () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuAdcHalt()
**
** Description:
** This function is to halt the convertion for all the SGs of ADCAn.
** All Scan groups are halted and initialized.
** This function is not aligned with the DAMT project but is declared and
** defined for future use.
**
** Arguments: 
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuAdc0Halt(void)	/* !!!This function is a placeholder!!! */
{
    volatile uint32_t g_cg_sync_read;
    /* All scan groups are halted and initialized */
    ADCA0.ADHALTR.UINT32 = ADC_HALT;
    /* Synchronization processing */
    g_cg_sync_read = ADCA0.ADHALTR.UINT32;
    __syncp();
}/*--------------------------- End McuAdcHalt () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuAdc0Sg1Start()
**
** Description:
** This function starts ADC0 scan group 1 convertion.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuAdc0Sg1Start(void)
{
    /* Enable ADC0 SG1 operation */
    ADCA0.SGSTCR1.UINT32 = ADC_START;
}/*--------------------------- End McuAdc0Sg1Start () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuAdc0Sg1Stop()
**
** Description:
** This function stops ADC0 scan group 1 convertion.
** This function is not aligned with the DAMT project but is declared and
** defined for future use.
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
void McuAdc0Sg1Stop(void)	/* !!!This function is a placeholder!!! */
{
    /* Disable ADCA0 SG1 operation */
    ADCA0.SGSTPCR1.UINT32 = ADC_STOP;
}/*--------------------------- End McuAdc0Sg1Stop () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuAdc0Sg1GetResult
**
** Description:
** This function gets A/D conversion result for ADC0 scan group 1.
** It gets the conversion values of all ADC channels from Scan Group 1.
**
** Arguments:
** 1. pbuffer	: Pointer to the buffer to store ADC conversion result
** 2. bufferSize: Size of the buffer	(Buffer size here is 2 as only 2 channels are assigned to scan group 1)
**
** Return values:
** None
**---------------------------------------------------------------------------*/
McuAdcStatus McuAdc0Sg1GetResult(uint16_t * pBuffer, uint8_t bufferSize)
{
    uint8_t startPointer;
    uint8_t endPointer;
    uint8_t countNum;
    uint8_t bufferIndex;
    uint32_t volatile * pAddr;
    uint32_t convertData;

    startPointer = (uint8_t)ADCA0.SGVCSP1.UINT32;		/* Gets the first virtual channel number */
    endPointer = (uint8_t)ADCA0.SGVCEP1.UINT32;			/* Gets the Last virtual channel number	*/

    countNum = (endPointer - startPointer) + ADC_CHANNEL_COUNT_OFFSET;		/* To get the total number of virtual channels in the scan group */
    if (bufferSize > countNum)							/* Checks if the entered buffer size is greater than the number of channels in the scan group */
    {
	return ADC_NOT_OK;
    }
    /* ADCA0.DR00 */
    pAddr = (uint32_t*)(ADC0_VCHANNEL_DATA_BASE + (ADC_CHANNEL_ADDRESS_OFFSET * startPointer));	/* getting address of the starting virtual channel */

    /*Getting the data from the data register into the buffer*/
    for (bufferIndex = ZERO_BASE_INDEX; bufferIndex < countNum; bufferIndex = bufferIndex + ADC_CHANNEL_DATA_REGISTER_STEP)	/* bufferIndex + CHANNEL_DATA_REGISTER_STEP because each data register stores values from two virtual channels */
    {
	convertData = (uint32_t) * pAddr;
	pBuffer[bufferIndex] = (uint16_t)(convertData & LOWER_DATA_FIELD);						/* gets the lowers 16 bits from the data register */
	if ((countNum - bufferIndex) > MORE_CHANNEL_TO_READ)
	{
	    pBuffer[bufferIndex + SINGLE_INDEX_INCREMENT] = (uint16_t)((convertData & HIGHER_DATA_FIELD) >> SHIFT_TWO_BYTES);	/* gets the upper 16 bits from the data register */
	}
	pAddr++;
    }
    return ADC_OK;
}/*--------------------------- End McuAdc0Sg1GetResult () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: McuAdc0ChannelGetResult
**
** Description:
** This function gets A/D conversion result for single specific ADC0 Channel.
** This function is only while testing the module.
**
** Arguments:
** 1. pBuffer      : Pointer to the buffer to store ADC conversion result
** 2. channelNo	   : Channel Number to read from.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
McuAdcStatus McuAdc0ChannelGetResult(uint16_t * pBuffer, uint8_t channelNo)
{
    uint8_t startPointer;
    uint8_t endPointer;
    volatile uint32_t * pAddr;
    uint32_t convertData;

    startPointer = (uint8_t)ADCA0.SGVCSP1.UINT32;
    endPointer = (uint8_t)ADCA0.SGVCEP1.UINT32;

    /*Checking if the channel number entered is configured or not*/
    if (channelNo > endPointer || channelNo < startPointer)		
    {
	return ADC_NOT_OK;
    }

    pAddr = (uint32_t*)(ADC0_VCHANNEL_DATA_BASE + (ADC_CHANNEL_ADDRESS_OFFSET  * channelNo));

    /*Getting the data from the data register into the buffer*/
    convertData = (uint32_t) * pAddr;

    pBuffer = (convertData & LOWER_DATA_FIELD);	/* Gets the values stored in the data register of the corresponding virtual channel selected */
    return ADC_OK;
}/*--------------------------- End McuAdc0ChannelGetResult () -----------------------*/


/*--------------------------- End Adc.c -----------------------------*/
