/*-----------------------------------------------------------------------------
**                            � 2025 Ashok Leyland
** File: McuClock.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the configuration of MCU's clock sources, PLL and Peripheral clocks.
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                               **
*****************************************************************************************************************************************/

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "McuClock.h"
#include "McuTauj0Ch0.h"
#include "McuClockPrivate.h"
#include "McuMacroDriver.h"
/*********************************************************************************
**                         MISRA C Rule Violations                           	**
*********************************************************************************/

/********************************************************************************/

/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
static McuClockStatus  	InitPll              	( McuPllConfig *pPllConfig );
static McuClockStatus  	InitMainOsc          	( McuMainOscClkGain *pmainOscGain );
static McuClockStatus	GetHsOscStatus	( void );
static McuClockStatus	InitCPU			( McuPllConfig *pPllConfig );
static void			InitPeripheralClks	( McuPclkConfig *pMcuPclkConfig );
static void			InitTauj0			( void );
uint32_t clockTimeOut;
/*-----------------------------------------------------------------------------
** Function: McuClockInit()
**
** Description:
** Initializes MCU clock.
**
** Arguments:
** *pMcuClkConfig: Pointer to MCU Clock Configuration.
**
** Return values:
** MCU clock initialisation status.
**---------------------------------------------------------------------------*/
McuClockStatus  McuClockInit           ( McuClkConfig *pMcuClkConfig )
{
    McuClockStatus clockStatus = MCU_CLOCK_STATUS_OK;

    InitTauj0();

    /*---------------------------------------------------------------------------
      HS IntOSC setting.
      ---------------------------------------------------------------------------*/
    clockStatus = GetHsOscStatus();

    /*---------------------------------------------------------------------------
      Set up the main clock.
      ---------------------------------------------------------------------------*/
    if(pMcuClkConfig->mainOscGain != MAINOSC_INACTIVE)
    {
	clockStatus = InitMainOsc ( &(pMcuClkConfig->mainOscGain) );
    }

    /*---------------------------------------------------------------------------
      Set up the PLL.
      ---------------------------------------------------------------------------*/
    /* MISRA Violation: START Msg(MISRA_CLOCK:4) */
    if(clockStatus == MCU_CLOCK_STATUS_OK)
    {
	/* END Msg(MISRA_CLOCK:4) */
	clockStatus = InitPll	( &pMcuClkConfig->pllConfig );
    }

    /*---------------------------------------------------------------------------
      Set up the CPU.
      ---------------------------------------------------------------------------*/
    /* MISRA Violation: START Msg(MISRA_CLOCK:4) */
    if(clockStatus == MCU_CLOCK_STATUS_OK)
    {
	/* END Msg(MISRA_CLOCK:4) */
	clockStatus = InitCPU  ( &pMcuClkConfig->pllConfig );
    }

    /*Stopping the timer after its use*/
    McuTauj0Ch0Stop();
    /*---------------------------------------------------------------------------
      Set up the Peripheral Clocks.
      ---------------------------------------------------------------------------*/
    /* MISRA Violation: START Msg(MISRA_CLOCK:4) */
    if(clockStatus == MCU_CLOCK_STATUS_OK)
    {
	/* END Msg(MISRA_CLOCK:4) */
	InitPeripheralClks( &pMcuClkConfig->pClkConfig );
    }

    return clockStatus;

}/*--------------------------- End McuClockInit () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: InitMainOsc()
**
** Description:
** Initializes MCU main.
**
** Arguments:
** mainOscGain: variable to store main clock frequency.
**
** Return values:
** main clock initialisation status.
**---------------------------------------------------------------------------*/
static McuClockStatus  InitMainOsc    (McuMainOscClkGain *pmainOscGain)
{

    McuClockStatus clockStatus = MCU_CLOCK_STATUS_OK;
    /*---------------------------------------------------------------------------
      MainOSC setting.
      ---------------------------------------------------------------------------*/
    CLKCTL.MOSCM			= CGC_MAINOSC_OSC_MODE;
    CLKCTL.MOSCC			= MOSCC_DEFAULT_VALUE | (uint32_t)(*pmainOscGain);
    CLKCTL.MOSCST		= MAINOSC_STABILIZE_TIME;
    CLKCTL.MOSCSTPM    	= MOSCSTPM_DEFAULT_VALUE | CGC_MAINOSC_REQUEST_STOP;


    /* Unlock access to write protected register */
    /* Start the Main Oscillator */
    do
    {
	WPROTR.PROTCMD0 	= WRITE_PROTECT_COMMAND;
	CLKCTL.MOSCE 		= (uint32_t)MAINOSC_START;
	CLKCTL.MOSCE 		= ~((uint32_t)MAINOSC_START);
	CLKCTL.MOSCE 		= (uint32_t)MAINOSC_START;
    }while(WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);

    /* Wait until clock is active */
    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while ((CLKCTL.MOSCS & (uint32_t)MAINOSC_ACTIVE) != (uint32_t)MAINOSC_ACTIVE)		
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_MAIN_OSC_TIMEOUT_FAIL;
	    break;
	}
    }
    return clockStatus;
}/*--------------------------- End InitMainOsc() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: GetHsOscStatus()
**
** Description:
** Checks if HS Oscillator is active or not and configures it to stop operation
** while in standby mode.
**
** Arguments:
** mainOscGain: variable to store main clock frequency.
**
** Return values:
** main clock initialisation status.
**---------------------------------------------------------------------------*/
static McuClockStatus  GetHsOscStatus   (void)
{
    McuClockStatus clockStatus = MCU_CLOCK_STATUS_OK;
    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while((CLKCTL.ROSCS & (uint32_t)CGC_HSOSC_ACTIVE) != (uint32_t)CGC_HSOSC_ACTIVE)
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_HS_OSC_TIMEOUT_FAIL;
	    break;
	}
    }
    /*---------------------------------------------------------------------------
      HSOSC setting.
      ---------------------------------------------------------------------------*/
    CLKCTL.ROSCSTPM = ROSCSTPM_DEFAULT_VALUE | CGC_HSOSC_REQUEST_STOP;		/* Configuring HSOsc to stop operation in stand by mode */

    return clockStatus;
}/*--------------------------- End GetHsOscStatus() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: InitPll()
**
** Description:
** Initializes PLL0, PLL1.
**
** Arguments:
** *pPllConfig: Pointer to PLLx and CPU clock Configuration.
**
** Return values:
** 
**---------------------------------------------------------------------------*/
static McuClockStatus  InitPll   ( McuPllConfig *pPllConfig )
{
    McuClockStatus clockStatus = MCU_CLOCK_STATUS_OK;
    volatile uint32_t g_cg_sync_read;

    /*---------------------------------------------------------------------------
      PLL1 setting.
      ---------------------------------------------------------------------------*/
    /* Unlock access to write protected register */
    /* Set PLL1 Source Clock */
    do
    {
        WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
        CLKCTL.CKSC_PLL1IS_CTL = (uint32_t)pPllConfig->sourceOsc;
        CLKCTL.CKSC_PLL1IS_CTL = ~(uint32_t)pPllConfig->sourceOsc;
        CLKCTL.CKSC_PLL1IS_CTL = (uint32_t)pPllConfig->sourceOsc;
    } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    while ((CLKCTL.CKSC_PLL1IS_ACT & (uint32_t)PLL1_SOURCE_ACTIVE) != (uint32_t)pPllConfig->sourceOsc)
    {
        NOP();
    }

    /* Set PLL1 Division ratio Mr */
    /* Configuring PLL1 VCO output clock frequency */
    /*
     -> Setting the division ratio. Mr=2 & Nr=60 so that the VCO1OUT frequency is 480 MHz.
    */
    CLKCTL.PLL1C = PLL1C_DEFAULT_VALUE | PLL1_DIVISION_RATIO;

    /* Unlock access to write protected register */
    /* Start PLL1 */
    do
    {
        WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
        CLKCTL.PLL1E = (uint32_t)CGC_PLL1_START;
        CLKCTL.PLL1E = ~(uint32_t)CGC_PLL1_START;
        CLKCTL.PLL1E = (uint32_t)CGC_PLL1_START;
    } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while ((CLKCTL.PLL1S & (uint32_t)CGC_PLL1_ACTIVE) != (uint32_t)CGC_PLL1_ACTIVE)
    {
        /* MISRA Violation: START Msg(MISRA_CLOCK:2) */
        /* MISRA Violation: START Msg(MISRA_CLOCK:3) */
        if (clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
        {
            /* END Msg(MISRA_CLOCK:2) */
            /* END Msg(MISRA_CLOCK:3) */
            clockStatus = MCU_PLL1_CLOCK_TIMEOUT_FAIL;
            break;
        }
    }

    /*---------------------------------------------------------------------------
      PPLLCLK setting.
      ---------------------------------------------------------------------------*/
    /* Unlock access to write protected register */
    /* Set PPLLCLK Source Clock */
    do
    {
        WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
        CLKCTL.CKSC_PPLLCLKS_CTL = (uint32_t)pPllConfig->ppllSourceClk;
        CLKCTL.CKSC_PPLLCLKS_CTL = ~(uint32_t)pPllConfig->ppllSourceClk;
        CLKCTL.CKSC_PPLLCLKS_CTL = (uint32_t)pPllConfig->ppllSourceClk;
    } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while ((CLKCTL.CKSC_PPLLCLKS_ACT & (uint32_t)PPLLCLK_SOURCE_ACTIVE) != (uint32_t)pPllConfig->ppllSourceClk)
    {
        /* MISRA Violation: START Msg(MISRA_CLOCK:2) */
        /* MISRA Violation: START Msg(MISRA_CLOCK:3) */
        if (clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
        {
            /* END Msg(MISRA_CLOCK:2) */
            /* END Msg(MISRA_CLOCK:3) */
            clockStatus = MCU_PPLL_CLOCK_TIMEOUT_FAIL;
            break;
        }
    }

    return clockStatus;

}/*--------------------------- End InitPll() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: InitCPU()
**
** Description:
** Initializes CPU clock.
**
** Arguments:
** *pPllConfig: Pointer to PLLx and CPU clock Configuration.
**
** Return values:
** CPU initialization status.
**---------------------------------------------------------------------------*/
static McuClockStatus InitCPU   (McuPllConfig *pPllConfig)
{
    uint32_t cpuDiv;
    McuClockStatus clockStatus = MCU_CLOCK_STATUS_OK;
    /*---------------------------------------------------------------------------
      CPU clock setting.
      ---------------------------------------------------------------------------*/
    cpuDiv = (uint32_t)pPllConfig->cpllOutDiv | (uint32_t)pPllConfig->cpuClkDiv;
    do
    {
	WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
	/* MISRA Violation: START Msg(MISRA_CLOCK:5) */
	CLKCTL.CKSC_CPUCLKD_CTL = (uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1;
	CLKCTL.CKSC_CPUCLKD_CTL = ~((uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1);
	CLKCTL.CKSC_CPUCLKD_CTL = (uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1;
	/* END Msg(MISRA_CLOCK:5) */
    }while(WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while (CLKCTL.CKSC_CPUCLKD_ACT != ((uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1))
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_CPU_CLOCK_TIMEOUT_FAIL;
	    break;
	}
    }
    /*Setting Source Clock*/
    do
    {
	WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
	/* MISRA Violation: START Msg(MISRA_CLOCK:5) */
	CLKCTL.CKSC_CPUCLKS_CTL = (uint32_t)pPllConfig->cpuSourceClk;
	CLKCTL.CKSC_CPUCLKS_CTL = ~(uint32_t)pPllConfig->cpuSourceClk;
	CLKCTL.CKSC_CPUCLKS_CTL = (uint32_t)pPllConfig->cpuSourceClk;
	/* END Msg(MISRA_CLOCK:5) */
    }while(WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while (CLKCTL.CKSC_CPUCLKS_ACT != (uint32_t)pPllConfig->cpuSourceClk)
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_CPU_CLOCK_TIMEOUT_FAIL;
	    break;
	}
    }

    do
    {
	WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
	/* MISRA Violation: START Msg(MISRA_CLOCK:5) */
	CLKCTL.CKSC_CPUCLKD_CTL = (uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1;
	CLKCTL.CKSC_CPUCLKD_CTL = ~((uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1);
	CLKCTL.CKSC_CPUCLKD_CTL = (uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1;
	/* END Msg(MISRA_CLOCK:5) */
    }while(WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while (CLKCTL.CKSC_CPUCLKD_ACT != ((uint32_t)CPLLOUT_DIVIDER_4 | (uint32_t)CPU_CLK_DIVIDER_1))
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_CPU_CLOCK_TIMEOUT_FAIL;
	    break;
	}
    }

    do
    {
	WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
	/* MISRA Violation: START Msg(MISRA_CLOCK:5) */
	CLKCTL.CKSC_CPUCLKD_CTL = cpuDiv;
	CLKCTL.CKSC_CPUCLKD_CTL = ~(cpuDiv);
	CLKCTL.CKSC_CPUCLKD_CTL = cpuDiv;
	/* END Msg(MISRA_CLOCK:5) */
    }while(WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);

    clockTimeOut = CLOCK_TIMEOUT_RESET;
    while (CLKCTL.CKSC_CPUCLKD_ACT != (cpuDiv))
    {
	/* MISRA Violation: START Msg(MISRA_CLOCK:2) */
	/* MISRA Violation: START Msg(MISRA_CLOCK:3) */
	if(clockTimeOut == CLOCK_TIMEOUT_EXPIRED)
	{
	    /* END Msg(MISRA_CLOCK:2) */
	    /* END Msg(MISRA_CLOCK:3) */
	    clockStatus = MCU_CPU_CLOCK_TIMEOUT_FAIL;
	    break;
	}
    }

    return clockStatus;

}/*--------------------------- End InitCPU() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: InitTauj0()
**
** Description:
** Initializes the Tauj Timer module clock.
** This timer is added here to introduce a timeout condition while initializing
** the clocks. This timer uses an interrupt and is stoped after all the clock
** initialization.
** Source clock : Low Speed Oscillator (LSOsc)
**
** Arguments:
** None
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void	InitTauj0	(void)
{
    /* TAUJ0 clock domain setting */
    WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
    CLKCTL.CKSC_ATAUJS_CTL = CGC_TAUJ_CLK_SOURCE_LSOSC;
    CLKCTL.CKSC_ATAUJS_CTL = (uint32_t) ~CGC_TAUJ_CLK_SOURCE_LSOSC;
    CLKCTL.CKSC_ATAUJS_CTL = CGC_TAUJ_CLK_SOURCE_LSOSC;
    while (CLKCTL.CKSC_ATAUJS_ACT != CGC_TAUJ_CLK_SOURCE_LSOSC)
    {
        NOP();
    }
    WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
    CLKCTL.CKSC_ATAUJD_CTL = CGC_TAUJ_CLK_DIVIDER_1;
    CLKCTL.CKSC_ATAUJD_CTL = (uint32_t) ~CGC_TAUJ_CLK_DIVIDER_1;
    CLKCTL.CKSC_ATAUJD_CTL = CGC_TAUJ_CLK_DIVIDER_1;
    while (CLKCTL.CKSC_ATAUJD_ACT != CGC_TAUJ_CLK_DIVIDER_1)
    {
        NOP();
    }
    CLKCTL.CKSC_ATAUJD_STPM = CKSC_ATAUJD_STPM_DEFAULT_VALUE | CGC_TAUJ_CLK_REQUEST_STOP;

    McuTauj0Ch0Init();
    McuTauj0Ch0Start();
}/*--------------------------- End InitTauj0() -----------------------*/


/*-----------------------------------------------------------------------------
** Function: InitPeripheralClks()
**
** Description:
** Initializes the clocks to the various peripheral modules.
**
** Arguments:
** *pMcuPllConfig: Pointer to PLLx and CPU clock Configuration.
**
** Return values:
** None
**---------------------------------------------------------------------------*/
static void  InitPeripheralClks           ( McuPclkConfig *pMcuPclkConfig )
{
    /*---------------------------------------------------------------------------
      ADCA0 clock domain setting.
      ---------------------------------------------------------------------------*/
    if (pMcuPclkConfig->adca0Config.mcuAdca0ClkisUsed)
    {
        /*Setting Source Clock*/
        do
        {
            WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_AADCAS_CTL = (uint32_t)pMcuPclkConfig->adca0Config.sourceClk;
            CLKCTL.CKSC_AADCAS_CTL = ~(uint32_t)pMcuPclkConfig->adca0Config.sourceClk;
            CLKCTL.CKSC_AADCAS_CTL = (uint32_t)pMcuPclkConfig->adca0Config.sourceClk;
        } while (WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_AADCAS_ACT != (uint32_t)pMcuPclkConfig->adca0Config.sourceClk)
        {
            NOP();
        }

        /*Setting Clock Divider*/
        do
        {
            WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_AADCAD_CTL = (uint32_t)pMcuPclkConfig->adca0Config.clkDiv;
            CLKCTL.CKSC_AADCAD_CTL = ~(uint32_t)pMcuPclkConfig->adca0Config.clkDiv;
            CLKCTL.CKSC_AADCAD_CTL = (uint32_t)pMcuPclkConfig->adca0Config.clkDiv;
        } while (WPROTR.PROTS0 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_AADCAD_ACT != (uint32_t)pMcuPclkConfig->adca0Config.clkDiv)
        {
            NOP();
        }
        CLKCTL.CKSC_AADCAD_STPM = CKSC_AADCAD_STPM_DEFAULT_VALUE | CGC_ADCA0_CLK_REQUEST_STOP;
    }

    /*---------------------------------------------------------------------------
      Peripheral clock domain setting.
      ---------------------------------------------------------------------------*/
    if (pMcuPclkConfig->peri1Config.mcuPeri1ClkisUsed)
    {
        /*Setting Source Clock*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_IPERI1S_CTL = (uint32_t)pMcuPclkConfig->peri1Config.sourceClk;
            CLKCTL.CKSC_IPERI1S_CTL = ~(uint32_t)pMcuPclkConfig->peri1Config.sourceClk;
            CLKCTL.CKSC_IPERI1S_CTL = (uint32_t)pMcuPclkConfig->peri1Config.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_IPERI1S_ACT != (uint32_t)pMcuPclkConfig->peri1Config.sourceClk)
        {
            NOP();
        }

        /*Setting Clock Divider*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_IPERI2S_CTL = (uint32_t)pMcuPclkConfig->peri2Config.sourceClk;
            CLKCTL.CKSC_IPERI2S_CTL = ~(uint32_t)pMcuPclkConfig->peri2Config.sourceClk;
            CLKCTL.CKSC_IPERI2S_CTL = (uint32_t)pMcuPclkConfig->peri2Config.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_IPERI2S_ACT != (uint32_t)pMcuPclkConfig->peri2Config.sourceClk)
        {
            NOP();
        }
    }

    if (pMcuPclkConfig->canConfig.mcuCanClkisUsed)
    {
        /*Setting Source Clock*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_ICANS_CTL = (uint32_t)pMcuPclkConfig->canConfig.sourceClk;
            CLKCTL.CKSC_ICANS_CTL = ~(uint32_t)pMcuPclkConfig->canConfig.sourceClk;
            CLKCTL.CKSC_ICANS_CTL = (uint32_t)pMcuPclkConfig->canConfig.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_ICANS_ACT != (uint32_t)pMcuPclkConfig->canConfig.sourceClk)
        {
            NOP();
        }
        CLKCTL.CKSC_ICANS_STPM = CKSC_ICANS_STPM_DEFAULT_VALUE | CGC_RSCAN_CLK_REQUEST_STOP;

        /*Setting Clock Divider*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_ICANOSCD_CTL = (uint32_t)pMcuPclkConfig->canConfig.clkDiv;
            CLKCTL.CKSC_ICANOSCD_CTL = ~(uint32_t)pMcuPclkConfig->canConfig.clkDiv;
            CLKCTL.CKSC_ICANOSCD_CTL = (uint32_t)pMcuPclkConfig->canConfig.clkDiv;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_ICANOSCD_ACT != (uint32_t)pMcuPclkConfig->canConfig.clkDiv)
        {
            NOP();
        }
        CLKCTL.CKSC_ICANOSCD_STPM = CKSC_ICANOSCD_STPM_DEFAULT_VALUE | CGC_RSCANOSC_CLK_REQUEST_STOP;
    }

    /*---------------------------------------------------------------------------
      CSI clock domains setting.
      ---------------------------------------------------------------------------*/
    if (pMcuPclkConfig->csiConfig.mcuCsiClkisUsed)
    {
        /*Setting Source Clock*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_ICSIS_CTL = (uint32_t)pMcuPclkConfig->csiConfig.sourceClk;
            CLKCTL.CKSC_ICSIS_CTL = ~(uint32_t)pMcuPclkConfig->csiConfig.sourceClk;
            CLKCTL.CKSC_ICSIS_CTL = (uint32_t)pMcuPclkConfig->csiConfig.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_ICSIS_ACT != (uint32_t)pMcuPclkConfig->csiConfig.sourceClk)
        {
            NOP();
        }
    }

    /*---------------------------------------------------------------------------
      I2C clock domains setting.
      ---------------------------------------------------------------------------*/
    if (pMcuPclkConfig->i2cConfig.mcuI2cClkisUsed)
    {
        /* Setting Source Clock */
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_IIICS_CTL = (uint32_t)pMcuPclkConfig->i2cConfig.sourceClk;
            CLKCTL.CKSC_IIICS_CTL = ~(uint32_t)pMcuPclkConfig->i2cConfig.sourceClk;
            CLKCTL.CKSC_IIICS_CTL = (uint32_t)pMcuPclkConfig->i2cConfig.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_IIICS_ACT != (uint32_t)pMcuPclkConfig->i2cConfig.sourceClk)
        {
            NOP();
        }
    }

    /*For testing Clock*/
    /* Frequency output clock setting */
    WPROTR.PROTCMD0 = WRITE_PROTECT_COMMAND;
    CLKCTL.CKSC_AFOUTS_CTL = (uint32_t)FOUT_CLK_SOURCE_MAINOSC;
    CLKCTL.CKSC_AFOUTS_CTL = ~((uint32_t)FOUT_CLK_SOURCE_MAINOSC);
    CLKCTL.CKSC_AFOUTS_CTL = (uint32_t)FOUT_CLK_SOURCE_MAINOSC;
    while (CLKCTL.CKSC_AFOUTS_ACT != (uint32_t)FOUT_CLK_SOURCE_MAINOSC)
    {
        NOP();
    }
    CLKCTL.FOUTDIV = FOUT_DIVISION_RATIO;
    CLKCTL.CKSC_AFOUTS_STPM = CKSC_AFOUTS_STPM_DEFAULT_VALUE | FOUT_CLK_REQUEST_STOP;

    /*---------------------------------------------------------------------------
      UART/LIN clock domains setting.
      ---------------------------------------------------------------------------*/
    if (pMcuPclkConfig->UARTConfig.mcuUARTClkisUsed)
    {
        /*Setting Source Clock*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_ILINS_CTL = (uint32_t)pMcuPclkConfig->UARTConfig.sourceClk;
            CLKCTL.CKSC_ILINS_CTL = ~(uint32_t)pMcuPclkConfig->UARTConfig.sourceClk;
            CLKCTL.CKSC_ILINS_CTL = (uint32_t)pMcuPclkConfig->UARTConfig.sourceClk;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_ILINS_ACT != (uint32_t)pMcuPclkConfig->UARTConfig.sourceClk)
        {
            NOP();
        }

        /*Setting Clock Divider*/
        do
        {
            WPROTR.PROTCMD1 = WRITE_PROTECT_COMMAND;
            CLKCTL.CKSC_ILIND_CTL = (uint32_t)pMcuPclkConfig->UARTConfig.clkDiv;
            CLKCTL.CKSC_ILIND_CTL = ~(uint32_t)pMcuPclkConfig->UARTConfig.clkDiv;
            CLKCTL.CKSC_ILIND_CTL = (uint32_t)pMcuPclkConfig->UARTConfig.clkDiv;
        } while (WPROTR.PROTS1 == WRITE_PROTECT_ERROR_OCCURED);
        while (CLKCTL.CKSC_ILIND_ACT != (uint32_t)pMcuPclkConfig->UARTConfig.clkDiv)
        {
            NOP();
        }
        CLKCTL.CKSC_ILIND_STPM = CKSC_ILIND_STPM_DEFAULT_VALUE | CGC_RLIN_CLK_REQUEST_STOP;
    }
}/*--------------------------- End InitPeripheralClks() -----------------------*/


/*--------------------------- End McuClock.c -----------------------------*/
