/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                          
** File: McuClockPrivate.h
**
** Description:
** Header file containing private macros for Clock module.
**---------------------------------------------------------------------------*/
#ifndef MCU_CLOCK_PRIVATE_H
#define MCU_CLOCK_PRIVATE_H
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/	

/*
    MainOSC Enable Register (MOSCE)
*/
/* MainOSC disable trigger (MOSCDISTRG) */
#define MAINOSC_STOP                    	(0x00000002UL) /* Stops MainOSC */
/* MainOSC enable trigger (MOSCENTRG) */
#define MAINOSC_START                   	(0x00000001UL) /* Start MainOSC */

/*
    MainOSC Status Register (MOSCS)
*/
/* MainOSC active status (MOSCCLKACT) */
#define MAINOSC_ACTIVE                  	(0x00000004UL) /* MainOSC is active */

/*
    MainOSC Stop Mask Register (MOSCSTPM)
*/
/* MainOSC stop request mask (MOSCSTPMSK) */
#define CGC_MAINOSC_REQUEST_STOP            	(0x00000000UL) /* MainOSC stops operation in standby mode */
#define CGC_MAINOSC_REQUEST_CONTINUE        	(0x00000001UL) /* MainOSC continues operation in standby mode */

/*
    MainOSC Mode Control Register (MOSCM)
*/
/* MainOSC mode control (MOSCM) */
#define CGC_MAINOSC_OSC_MODE                	(0x00000000UL) /* OSC mode */
#define CGC_MAINOSC_EXCLK_MODE              	(0x00000001UL) /* EXCLK mode */

/*
    SubOSC Enable Register (SOSCE)
*/
/* SubOSC disable trigger (SOSCDISTRG) */
#define CGC_SUBOSC_STOP                     	(0x00000002UL) /* Stops SubOSC */
/* SubOSC enable trigger (SOSCENTRG) */
#define CGC_SUBOSC_START                    	(0x00000001UL) /* Starts SubOSC */

/*
    SubOSC Status Register (SOSCS)
*/
/* SubOSC activation status (SOSCCLKACT) */
#define CGC_SUBOSC_ACTIVE                   	(0x00000004UL) /* SubOSC is active */

/*
    HS IntOSC Enable Register (ROSCE)
*/
/* HS IntOSC disable trigger (ROSCDISTRG) */
#define CGC_HSOSC_STOP                      	(0x00000002UL) /* Stops HS IntOSC */

/*
    HS IntOSC Status Register (ROSCS)
*/
/* HS IntOSC active status (ROSCCLKACT) */
#define CGC_HSOSC_INACTIVE                	(0x00000000UL) /* HS IntOSC is inactive */
#define CGC_HSOSC_ACTIVE                  	(0x00000004UL) /* HS IntOSC is active */

/*
    HS IntOSC Stop Mask Register (ROSCSTPM)
*/
/* HS IntOSC stop request mask (ROSCSTPMSK) */
#define CGC_HSOSC_REQUEST_STOP              	(0x00000000UL) /* HS IntOSC stops operation in standby mode */
#define CGC_HSOSC_REQUEST_CONTINUE          	(0x00000001UL) /* HS IntOSC continues operation in standby mode */

/*
    PLL0 Enable Register (PLL0E)
*/
/* PLL0 disable trigger (PLL0DISTRG) */
#define CGC_PLL0_STOP                       	(0x00000002UL) /* Stops PLL0 */
/* PLL0 enable trigger (PLL0ENTRG) */
#define CGC_PLL0_START                      	(0x00000001UL) /* Starts PLL0 */

/*
    PLL0 Status Register (PLL0S)
*/
/* PLL0 active status (PLL0CLKACT) */
#define CGC_PLL0_ACTIVE                     	(0x00000004UL) /* PLL0 is active */

/*
   PLL0 Control Register (PLL0C)
*/
/*VCO output frequency range setting (PLL0FVV)*/			
#define PLL0_VCO                        	(0x00000000UL) 	    /* 440 MHz to 480 MHz.*/
/* Frequency modulation cycle setting (PLL0MF)*/
#define PLL0_MFD10                      	(0x00000000UL) /* Modulation frequency division ratio MFD=10 */
#define PLL0_MFD12                      	(0x01000000UL) /* Modulation frequency division ratio MFD=12 */
#define PLL0_MFD18                      	(0x02000000UL) /* Modulation frequency division ratio MFD=18 */
#define PLL0_MFD20                      	(0x03000000UL) /* Modulation frequency division ratio MFD=20 */
#define PLL0_MFD22                      	(0x04000000UL) /* Modulation frequency division ratio MFD=22 */
#define PLL0_MFD26                      	(0x05000000UL) /* Modulation frequency division ratio MFD=26 */
#define PLL0_MFD28                      	(0x06000000UL) /* Modulation frequency division ratio MFD=28 */
#define PLL0_MFD30                      	(0x07000000UL) /* Modulation frequency division ratio MFD=30 */
#define PLL0_MFD34                      	(0x08000000UL) /* Modulation frequency division ratio MFD=34 */
#define PLL0_MFD38                      	(0x09000000UL) /* Modulation frequency division ratio MFD=38 */
#define PLL0_MFD40                      	(0x0a000000UL) /* Modulation frequency division ratio MFD=40 */
#define PLL0_MFD44                      	(0x0b000000UL) /* Modulation frequency division ratio MFD=44 */
#define PLL0_MFD50                      	(0x0c000000UL) /* Modulation frequency division ratio MFD=50 */
#define PLL0_MFD56                      	(0x0d000000UL) /* Modulation frequency division ratio MFD=56 */
#define PLL0_MFD58                      	(0x0e000000UL) /* Modulation frequency division ratio MFD=58 */
#define PLL0_MFD60                      	(0x0f000000UL) /* Modulation frequency division ratio MFD=60 */
#define PLL0_MFD62                      	(0x10000000UL) /* Modulation frequency division ratio MFD=62 */
#define PLL0_MFD66                      	(0x11000000UL) /* Modulation frequency division ratio MFD=66 */
#define PLL0_MFD72                      	(0x12000000UL) /* Modulation frequency division ratio MFD=72 */
#define PLL0_MFD76                      	(0x13000000UL) /* Modulation frequency division ratio MFD=76 */
#define PLL0_MFD80                      	(0x14000000UL) /* Modulation frequency division ratio MFD=80 */
#define PLL0_MFD84                      	(0x15000000UL) /* Modulation frequency division ratio MFD=84 */
#define PLL0_MFD86                      	(0x16000000UL) /* Modulation frequency division ratio MFD=86 */
#define PLL0_MFD100                     	(0x17000000UL) /* Modulation frequency division ratio MFD=100 */
#define PLL0_MFD120                     	(0x18000000UL) /* Modulation frequency division ratio MFD=120 */
#define PLL0_MFD126                    	(0x19000000UL) /* Modulation frequency division ratio MFD=126 */
#define PLL0_MFD134                     	(0x1a000000UL) /* Modulation frequency division ratio MFD=134 */
#define PLL0_MFD150                     	(0x1b000000UL) /* Modulation frequency division ratio MFD=150 */
#define PLL0_MFD166                    	(0x1c000000UL) /* Modulation frequency division ratio MFD=166 */
#define PLL0_MFD200                     	(0x1d000000UL) /* Modulation frequency division ratio MFD=200 */
#define PLL0_MFD250                     	(0x1e000000UL) /* Modulation frequency division ratio MFD=250 */
#define PLL0_MFD300                     	(0x1f000000UL) /* Modulation frequency division ratio MFD=300 */
/* Frequency modulation range setting (PLL0ADJ)*/
#define PLL0_FMR_1                      	(0x00000000UL) /* Frequency modulation range 1% */
#define PLL0_FMR_2                      	(0x00100000UL) /* Frequency modulation range 2% */
#define PLL0_FMR_3                     	(0x00200000UL) /* Frequency modulation range 3% */
#define PLL0_FMR_4                      	(0x00300000UL) /* Frequency modulation range 4% */
#define PLL0_FMR_5                      	(0x00400000UL) /* Frequency modulation range 5% */
#define PLL0_FMR_6                     	(0x00500000UL) /* Frequency modulation range 6% */
#define PLL0_FMR_8                      	(0x00600000UL) /* Frequency modulation range 8% */
#define PLL0_FMR_10                     	(0x00700000UL) /* Frequency modulation range 10% */
/* Operating mode setting (PLL0MD)*/
#define PLL0_SSCCG_MODE                 	(0x00004000UL) /*SSCG mode (modulation frequency) */
/* Modulation mode setting in SSCG mode (PLL0SMD)*/
#define PLL0_SSCCG_MODU_MODE_SEL        	(0x00000000UL)  /* Down spread modulation */

/*
    PLL0 Input Clock Selection Register (CKSC_PLL0IS_CTL)
*/
/* Source clock setting for PLL0 input clock (PLL0ISCSID1,PLL0ISCSID0) */
#define CGC_PLL0_SOURCE_MAINOSC             	(0x00000001UL) /* Main OSC */
#define CGC_PLL0_SOURCE_HSOSC               	(0x00000002UL) /* HS IntOSC */

/*
    PLL1 Enable Register (PLL1E)
*/
/* PLL1 disable trigger (PLL1DISTRG) */
#define CGC_PLL1_STOP                       	(0x00000002UL) /* Stops PLL1 */
/* PLL1 enable trigger (PLL1ENTRG) */
#define CGC_PLL1_START               		(0x00000001UL) /* Starts PLL1 */

/*
    PLL1 Status Register (PLL1S)
*/
/* PLL1 active status (PLL1CLKACT) */
#define CGC_PLL1_ACTIVE                     	(0x00000004UL) /* PLL1 is active */


/*
    PLL1 Input Clock Active Register (CKSC_PLL1IS_ACT)
*/
/* Source clock for currently active PLL1 input clock (PLL1ISACT1,PLL1ISACT0) */
#define PLL1_SOURCE_ACTIVE              	(0x00000003UL) /* Source clock for currently active PLL1 input clock */

/*
    PLL0 Input Clock Active Register (CKSC_PLL0IS_ACT)
*/
/* Source clock for currently active PLL0 input clock (PLL0ISACT1,PLL0ISACT0) */
#define PLL0_SOURCE_ACTIVE              	(0x00000003UL) /* Source clock for currently active PLL0 input clock */


/*
    PPLLCLK Source Clock Active Register (CKSC_PPLLCLKS_ACT)
*/
/* Source clock for currently active PPLLCLK (PPLLCLKSCSID1,PPLLCLKSCSID0) */
#define PPLLCLK_SOURCE_ACTIVE           	(0x00000003UL) /* Source clock for currently active PPLLCLK */


/* Common Macros */
#define MOSCC_DEFAULT_VALUE                 	(0x00000004UL) /* MOSCC default value */
#define MOSCSTPM_DEFAULT_VALUE               	(0x00000002UL) /* MOSCSTPM default value */
#define ROSCSTPM_DEFAULT_VALUE               	(0x00000002UL) /* ROSCSTPM default value */
#define PLL1C_DEFAULT_VALUE                  	(0x00010300UL) /* PLL1C default value */
#define PLL0C_DEFAULT_VALUE                  	(0x60004000UL) /* PLL0C default value */
#define CKSC_AWDTAD_STPM_DEFAULT_VALUE       	(0x00000002UL) /* CKSC_AWDTAD_STPM default value */
#define CKSC_ATAUJD_STPM_DEFAULT_VALUE       	(0x00000002UL) /* CKSC_ATAUJD_STPM default value */
#define CKSC_ARTCAD_STPM_DEFAULT_VALUE       	(0x00000002UL) /* CKSC_ARTCAD_STPM default value */
#define CKSC_AADCAD_STPM_DEFAULT_VALUE       	(0x00000002UL) /* CKSC_AADCAD_STPM default value */
#define CKSC_AFOUTS_STPM_DEFAULT_VALUE       	(0x00000002UL) /* CKSC_AFOUTS_STPM default value */
#define CKSC_ILIND_STPM_DEFAULT_VALUE        	(0x00000002UL) /* CKSC_ILIND_STPM default value */
#define CKSC_ICANS_STPM_DEFAULT_VALUE        	(0x00000002UL) /* CKSC_ICANS_STPM default value */
#define CKSC_ICANOSCD_STPM_DEFAULT_VALUE     	(0x00000002UL) /* CKSC_ICANOSCD_STPM default value */
#define MAINOSC_STABILIZE_TIME               	(0x000044C0UL) /* the count value for the MainOSC stabilization counter */
#define PLL1_DIVISION_RATIO                  	(0x0000083BUL) /* PLL1 Division ratio Mr is set */
#define FOUT_DIVISION_RATIO                  	(0x00000001UL) /* Clock divider N */
#define PLL0_DIVISION_RATIO                  	(0x0000083BUL) /* PLL0 Division ratio Mr is set */

/*
    C_AWO_FOUT Stop Mask Register (CKSC_AFOUTS_STPM)
*/
/* C_AWO_FOUT stop request mask (AFOUTSSTPMSK) */
#define FOUT_CLK_REQUEST_STOP          	 	(0x00000000UL) /* C_AWO_FOUT is stopped in standby mode */
#define FOUT_CLK_REQUEST_CONTINUE       	(0x00000001UL) /* C_AWO_FOUT is not stopped in standby mode */

/*
    C_AWO_WDTA Clock Divider Selection Register (CKSC_AWDTAD_CTL)
*/
/* Clock divider setting for C_AWO_WDTA (AWDTADCSID1,AWDTADCSID0) */
#define CGC_WDTA_CLK_SOURCE_LSOSC_128       	(0x00000001UL) /* LS IntOSC / 128 (default) */
#define CGC_WDTA_CLK_SOURCE_LSOSC_1         	(0x00000002UL) /* LS IntOSC / 1 */

/*
    C_AWO_TAUJ Source Clock Selection Register (CKSC_ATAUJS_CTL)
*/
/* Source clock setting for C_AWO_TAUJ (ATAUJSCSID2,ATAUJSCSID1,ATAUJSCSID0) */
#define CGC_TAUJ_CLK_SOURCE_DISABLE         	(0x00000000UL) /* Disabled */
#define CGC_TAUJ_CLK_SOURCE_HSOSC           	(0x00000001UL) /* HS IntOSC (default) */
#define CGC_TAUJ_CLK_SOURCE_MAINOSC         	(0x00000002UL) /* MainOSC */
#define CGC_TAUJ_CLK_SOURCE_LSOSC           	(0x00000003UL) /* LS IntOSC */
#define CGC_TAUJ_CLK_SOURCE_PPLLCLK2        	(0x00000004UL) /* PPLLCLK2 */

/*
    C_AWO_TAUJ Clock Divider Selection Register (CKSC_ATAUJD_CTL)
*/
/* Clock divider setting for C_AWO_TAUJ (ATAUJDCSID2,ATAUJDCSID1,ATAUJDCSID0) */
#define CGC_TAUJ_CLK_DIVIDER_1              	(0x00000001UL) /* CKSC_ATAUJS_CTL selection /1 (default) */
#define CGC_TAUJ_CLK_DIVIDER_2              	(0x00000002UL) /* CKSC_ATAUJS_CTL selection /2 */
#define CGC_TAUJ_CLK_DIVIDER_4              	(0x00000003UL) /* CKSC_ATAUJS_CTL selection /4 */
#define CGC_TAUJ_CLK_DIVIDER_8              	(0x00000004UL) /* CKSC_ATAUJS_CTL selection /8 */

/*			
    C_AWO_TAUJ Stop Mask Register (CKSC_ATAUJD_STPM)			
*/	
		
/* C_AWO_TAUJ stop request mask (ATAUJDSTPMSK) */
#define  CGC_TAUJ_CLK_REQUEST_STOP          	(0x00000000UL) /* C_AWO_TAUJ is stopped in standby mode */
#define	 CGC_TAUJ_CLK_REQUEST_CONTINUE      	(0x00000001UL) /* C_AWO_TAUJ is not stopped in standby mode */


/*
    C_AWO_WDTA Stop Mask Register (CKSC_AWDTAD_STPM)
*/
/* C_AWO_WDTA stop request mask (AWDTADSTPMSK) */
#define CGC_WDTA_CLK_REQUEST_STOP           	(0x00000000UL) /* C_AWO_WDTA is stopped in standby mode */
#define CGC_WDTA_CLK_REQUEST_CONTINUE       	(0x00000001UL) /* C_AWO_WDTA is not stopped in standby mode */

/*
    C_AWO_ADCA Stop Mask Register (CKSC_AADCAD_STPM)
*/
/* C_AWO_ADCA stop request mask (AADCADSTPMSK) */
#define CGC_ADCA0_CLK_REQUEST_STOP          	(0x00000000UL) /* C_AWO_ADCA is stopped in standby mode */
#define CGC_ADCA0_CLK_REQUEST_CONTINUE      	(0x00000001UL) /* C_AWO_ADCA is not stopped in standby mode */


/*
    C_ISO_CAN Stop Mask Register (CKSC_ICANS_STPM)
*/
/* C_ISO_CAN stop request mask (ICANSSTPMSK) */
#define CGC_RSCAN_CLK_REQUEST_STOP          	(0x00000000UL) /* C_ISO_CAN is stopped in standby mode */
#define CGC_RSCAN_CLK_REQUEST_CONTINUE      	(0x00000001UL) /* C_ISO_CAN is not stopped in standby mode */


/*
    C_ISO_CANOSC Stop Mask Register (CKSC_ICANOSCD_STPM)
*/
/* C_ISO_CANOSC stop request mask (ICANOSCDSTPMSK) */
#define  CGC_RSCANOSC_CLK_REQUEST_STOP      	(0x00000000UL) /* C_ISO_CANOSC is stopped in standby mode */
#define  CGC_RSCANOSC_CLK_REQUEST_CONTINUE  	(0x00000001UL) /* C_ISO_CANOSC is not stopped in standby mode */


/*
    C_ISO_LIN Stop Mask Register (CKSC_ILIND_STPM)
*/
/* C_AWO_FOUT stop request mask (ILINDSTPMSK) */
#define CGC_RLIN_CLK_REQUEST_STOP             (0x00000000UL) /* C_ISO_LIN is stopped in standby mode */
#define CGC_RLIN_CLK_REQUEST_CONTINUE         (0x00000001UL) /* C_ISO_LIN is not stopped in standby mode */

#endif /* MCU_CLOCK_PRIVATE_H */
