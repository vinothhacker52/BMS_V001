/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: Ina226Private.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for CAN module.
**---------------------------------------------------------------------------*/
#ifndef SYSTEMCURRENTSENSORPRIVATE_H
#define SYSTEMCURRENTSENSORPRIVATE_H


#endif

/*--------------------------- End McuCan.h -----------------------------*/

