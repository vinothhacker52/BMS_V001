/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                              
** File: ina226.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for INA226 module.
**---------------------------------------------------------------------------*/
#ifndef SYSTEMCURRENTSENSOR_H
#define SYSTEMCURRENTSENSOR_H
#include "McuI2c.h"
#include "SystemCurrentSensorPrivate.h"
//#include <math.h>
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

#define DEV_ADDR	0x40
#define min(a,b) ((a)<(b)?(a):(b))
#define ROUND(x) ((int)((x) + ((x) >= 0 ? 0.5 : -0.5)))

//  set by setAlertRegister
#define INA226_SHUNT_OVER_VOLTAGE	0x8000
#define INA226_SHUNT_UNDER_VOLTAGE	0x4000
#define INA226_BUS_OVER_VOLTAGE	0x2000
#define INA226_BUS_UNDER_VOLTAGE	0x1000
#define INA226_POWER_OVER_LIMIT	0x0800
#define INA226_CONVERSION_READY	0x0400


//  returned by getAlertFlag
#define INA226_ALERT_FUNCTION_FLAG	0x0010
#define INA226_CONVERSION_READY_FLAG	0x0008
#define INA226_MATH_OVERFLOW_FLAG	0x0004
#define INA226_ALERT_POLARITY_FLAG	0x0002
#define INA226_ALERT_LATCH_ENABLE_FLAG	0x0001


//  returned by setMaxCurrentShunt
#define INA226_ERR_NONE	0x0000
#define INA226_ERR_SHUNTVOLTAGE_HIGH	0x8000
#define INA226_ERR_MAXCURRENT_LOW	0x8001
#define INA226_ERR_SHUNT_LOW	0x8002
#define INA226_ERR_NORMALIZE_FAILED	0x8003

//  REGISTERS
#define INA226_CONFIGURATION	0x00
#define INA226_SHUNT_VOLTAGE	0x01
#define INA226_BUS_VOLTAGE	0x02
#define INA226_POWER	0x03
#define INA226_CURRENT	0x04
#define INA226_CALIBRATION	0x05
#define INA226_MASK_ENABLE	0x06
#define INA226_ALERT_LIMIT	0x07
#define INA226_MANUFACTURER	0xFE
#define INA226_DIE_ID	0xFF


//  CONFIGURATION MASKS
#define INA226_CONF_RESET_MASK	0x8000
#define INA226_CONF_AVERAGE_MASK	0x0E00
#define INA226_CONF_BUSVC_MASK	0x01C0
#define INA226_CONF_SHUNTVC_MASK	0x0038
#define INA226_CONF_MODE_MASK	0x0007
//  See issue #26
#define INA226_MINIMAL_SHUNT_OHM	0.001

#define INA226_MAX_WAIT_MS	600   //  millis

#define INA226_MAX_SHUNT_VOLTAGE	(81.92 / 1000)

#define INA_OK	0
#define INA_NOT_OK	1

#define TRUE  1
#define FALSE 0

uint8_t* InaTransmitAck(uint16_t , uint8_t * , uint8_t* );
uint16_t ReadRegister(uint8_t , uint16_t );
uint16_t WriteRegister(uint8_t , uint16_t );
int configure(float , float , float , uint16_t );
int setMaxCurrentShunt(float , float , _Bool );
uint8_t getShuntVoltageConversionTime(void);
_Bool setShuntVoltageConversionTime(uint8_t );
uint8_t getBusVoltageConversionTime(void);
_Bool setBusVoltageConversionTime(uint8_t );
uint8_t getAverage(void);
_Bool setAverage(uint8_t );
_Bool reset(void);
_Bool isConversionReady(void);
float getPower(void);
float getCurrent(void);
float getShuntVoltage(void);
float getBusVoltage(void);
uint8_t McuIna226Init(void);

float    _current_LSB;
float    _shunt;
float    _maxCurrent;
float    _current_zero_offset = 0;
uint16_t _bus_V_scaling_e4 = 10000;
#endif

/*--------------------------- End McuCan.h -----------------------------*/

