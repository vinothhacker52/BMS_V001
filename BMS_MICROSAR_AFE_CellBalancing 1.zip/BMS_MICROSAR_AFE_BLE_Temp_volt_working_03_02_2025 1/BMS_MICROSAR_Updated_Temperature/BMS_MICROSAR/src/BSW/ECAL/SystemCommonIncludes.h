/*-----------------------------------------------------------------------------
**                            
** File: SystemCommonIncludes.h
**
** Description:
** 	Header file containing constants, data type definitions which are common 
** for all the modules.
**---------------------------------------------------------------------------*/


#ifndef SYSTEM_COMMON_INCLUDES_H
#define SYSTEM_COMMON_INCLUDES_H



//#include "McuMacroDriver.h"
//#include "McuCan.h"
//#include "SystemCan.h"
//#include "SystemAdc.h"
//#include "SystemGpio.h"
//#include "SystemPwm.h"
//#include "SystemOstim0.h"
//#include "SystemAfe.h"
//#include "SystemAfePrivate.h"


/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
/*for Mgic numbers*/
#define INVALID  			(float)-1.0
#define DUTY_CYCLE_CONVERSION_FACTOR 	0.01f
#define ZERO_FLOAT			0.0f
#define ONE_FLOAT			1.0f
#define SIGNED_ZERO			0
#define ZERO				(uint8_t)0
#define ONE				    (uint8_t)1
#define TWO				    (uint8_t)2
#define THREE				(uint8_t)3
#define FOUR				(uint8_t)4
#define FIVE				(uint8_t)5
#define SIX				    (uint8_t)6
#define SEVEN				(uint8_t)7
#define EIGHT				(uint8_t)8
#define NINE				(uint8_t)9
#define TEN				    (uint8_t)10
#define ELEVEN				(uint8_t)11
#define TWELVE				(uint8_t)12
#define THIRTEEN			(uint8_t)13
#define FOURTEEN			(uint8_t)14
#define FIFTEEN				(uint8_t)15
#define SIXTEEN				(uint16_t)16

#define PRESCALAR_2			0.5f



typedef enum 
{
    
    MODULE_SUCCESS=0,
    MODULE_FAILED=1,
    MODULE_ERROR=2,
    /*GPIO_PORT_INIT_SUCCESS,
    GPIO_PORT_INIT_FAILED,
    MODULE_ADC_INIT_SUCCESS,
    MODULE_CLMA_INIT_SUCCESS,
    WRONG_CLMA_ID,
    MODULE_CLMA_STARTED,
    MODULE_CLMA_STOPED,
    WRONG_CHANNEL,
    PWM_NOT_INTITIALIZED,
    PWM_STARTED,
    PWM_NOTSTARTED,
    PWM_STOPED,
    PWM_NOTSTOPED,
    WDT_NOT_INITIALIZED,
    WDT_INITIALIZED,
    WRONG_WDT_PERIOD,
    WRONG_OVF_VALUE,
    CH1_INITIALIZED,
    CH3_INITIALIZED,
    CH5_INITIALIZED,
    CH7_INITIALIZED,
    NORMAL_CLOCK_INIT_SUCCESS,
    REDUCED_CLOCK_INIT_SUCCESS,
    CLOCK_INIT_FAILED,
    */
} ModuleStatus ;


/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/


#endif//SYSTEM_COMMON_INCLUDES_H
