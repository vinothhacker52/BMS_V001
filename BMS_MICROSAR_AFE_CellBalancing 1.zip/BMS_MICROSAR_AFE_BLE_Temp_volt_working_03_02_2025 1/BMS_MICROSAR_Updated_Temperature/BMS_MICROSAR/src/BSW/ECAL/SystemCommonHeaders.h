/*-----------------------------------------------------------------------------
**                            
** File: SystemCommonHeaders.h
**
** Description:
** 	Header file containing constants, data type definitions which are common 
** for all the modules.
**---------------------------------------------------------------------------*/


#ifndef SYSTEM_COMMON_HEADERS_H
#define SYSTEM_COMMON_HEADERS_H


#include "SystemClock.h"
#include "McuPortConfig.h"
#include "McuPin.h"
#include "SystemGpio.h"
#include "SystemPwm.h"
#include "SystemAdc.h"
#include "SystemAfe.h"
#include "SystemCan.h"
#include "SystemClma.h"
#include "SystemDefaultConfig.h"
#include "SystemOstim0.h"
#include "McuUart.h"

#include "McuMacroDriver.h"
#include "McuCan.h"
#include "SystemCan.h"
#include "SystemAdc.h"
#include "SystemGpio.h"
#include "SystemPwm.h"
#include "SystemOstim0.h"
#include "SystemAfe.h"
#include "SystemAfePrivate.h"


#endif