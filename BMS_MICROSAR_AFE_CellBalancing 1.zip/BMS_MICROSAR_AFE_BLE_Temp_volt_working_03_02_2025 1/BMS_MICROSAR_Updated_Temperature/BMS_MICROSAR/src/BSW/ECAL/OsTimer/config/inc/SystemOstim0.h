/*-----------------------------------------------------------------------------
**                            
** File: SystemOstim.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for the ECUAL layer of the OS Timer Module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	:  Not integrated with MCAL
*/
 
#ifndef SYSTEMOSTIM_H
#define SYSTEMOSTIM_H

#include "SystemCommonIncludes.h"
#include "McuOstm0.h"
#include "SystemClock.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define SOURCE_OF_OST 		(freqUsing.OsTimerFrequency)

typedef void (*CallbackType)(void) ; // function pointer type
/*timer start status*/
typedef enum 
{
    OST_NOT_INITIALIZED=0,
    OST_NOTSTARTED =1,
    OST_STARTED=2,
    OST_INITIALIZED=3,

}SystemOstimStartStatus;

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern SystemOstimStartStatus IsOstInitialised;
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void SystemOstimInit(CallbackType pCallBackFunction ,uint8_t timer);
extern SystemOstimStartStatus SystemOstimStart(void);

#endif // MCU_OSTM0_ECUAL_H

/*--------------------------- End SystemOstim0.h -----------------------------*/
