/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemOsTimPrivate.h
**
** Description:
** General Header file for System Ostime0
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_OSTIM_PRIVATE_H
#define SYSTEM_OSTIM_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

#define PRESCALAR_4         4000U
#define MIN_TIMER_VALUE 	1
#define MAX_TIMER_VALUE 	10






#endif /* SYSTEM_OSTIM_PRIVATE_H */
