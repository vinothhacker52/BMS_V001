/*-----------------------------------------------------------------------------
**                            
** File: SystemOstim0.c
**
** Description:
** This source file defines the functions, macros, and variables related
** to the operation of the ECUAL layer of the OS Timer Module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	: Not Integrated with the project

 * V1.6		: 10 - June - 2025 : Integrated with project

 * V1.7		: 19 - June - 2025 : The following changes were made
 			1. Added OstInitialise enum defination from SystemCommonIncludes.h
			2. Added else condition in SystemOstm0Init() for error handling.
 * V1.8		: 22 - July - 2025 : No changes were made.			
*/
 
/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "SystemOstim0.h"
#include "SystemOsTimPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
SystemOstimStartStatus IsOstInitialised = OST_NOT_INITIALIZED;
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/


// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: SystemOstm0Init()
**
** Description:
** This function validates the timer value and initializes the OS timer.
**
** Arguments:
** pCallBackFunction - Pointer to the OS timer configuration structure.
** timer 	  - timer value to run the task schedular.
** 
** Return values:- NA 
**---------------------------------------------------------------------------*/
void SystemOstimInit (CallbackType pCallBackFunction,uint8_t timer)
{    
    McuOstConfig ostConfig;

    /*validating timer input values*/
    if((timer >= MIN_TIMER_VALUE ) && ( timer <= MAX_TIMER_VALUE))                               //timer input range from 1 ms to 10 ms 
    {
	    /*MCAL structure intialization*/
	    ostConfig.pCallbackFunc     =   pCallBackFunction  ;                 //assignment of application layer function using p to p type
	    ostConfig.timerValue        =   (timer * SOURCE_OF_OST) - 1;         //assigning the timer value 
	    
	    /*structure pass by reference*/
	    McuOstm0init(&ostConfig);

	    /*storing status of initialisation*/
	    IsOstInitialised = OST_INITIALIZED;
             
    }
    else
    {
	     /*storing status of initialisation*/
	    IsOstInitialised = OST_NOT_INITIALIZED;
    }
    
}/*--------------------------- End SystemOstm0Init() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemOstm0Start()
**
** Description:
** 	This function will call McuOstm0Start() after validation of OS TIMER0 
** initialisation status. 
**
** Arguments:
** None
**
** Return values:- OsTimerStartStatus	
** 		OST_NOT_INITIALISED
** 		OST_STARTED
**---------------------------------------------------------------------------*/
SystemOstimStartStatus SystemOstimStart(void)
{
    /*validating intialised or not*/
    if(IsOstInitialised != OST_INITIALIZED)
    {
        return OST_NOT_INITIALIZED;
    }
    /*start OStimer*/
    McuOstm0Start();

    return OST_STARTED;
}/*--------------------------- End SystemOstm0Start() -----------------------*/


/*--------------------------- End SystemOstm0.c -----------------------------*/
