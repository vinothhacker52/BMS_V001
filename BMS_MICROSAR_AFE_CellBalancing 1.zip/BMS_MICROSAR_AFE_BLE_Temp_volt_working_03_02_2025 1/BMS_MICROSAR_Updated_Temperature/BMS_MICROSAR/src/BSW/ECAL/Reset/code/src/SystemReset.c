/*-----------------------------------------------------------------------------
**                            ï¿½ 2025 Ashok Leyland
** File: SystemReset.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of clock module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	: Not Integrated with the project

 * V1.6		: 10 - June - 2025 : Integrated with project

 * V1.7		: 19 - June - 2025 : The following changes were made
 *				1. changed Funtion name from SystemCheckResetCause to SystemResetCauseCheck.
 *                              2. Removed Function SystemClockManager().
 *                              3. changed name from SystemSoftwareReset to SystemResetSoftware.
 *				4. changed name from SystemSetSafeMode to ResetSetSafeMode.

 * V1.8 	: 22 - July - 2025: The following Chnages were made 
 *	 		        1. name McuSoftwareReset changed to McuResetSoftware.
 *			        2. Mcaro changed from SYS_GPIO_HIGH to MCU_GPIO_HIGH.
 *			        3. Macro name CLMA_MAX_RETRY_COUNT was changed to CLMA_MAX_FAILURE_COUNT.
			        4. resetFlag.wdt2Flag has changed to resetFlag.wdt0Flag.
 */

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemReset.h"
#include "SystemResetPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/
SystemClockMode resetCause;
SystemResetFlag resetFlag;
uint8_t shutDownRequestFlag= ZERO;
FlagStatus SafeModeflag;
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/




/*-----------------------------------------------------------------------------
** Function: SystemResetCauseCheck()
**
** Description:
** 	->This function is used to check the cause behind the previous reset and 
** inrements the reset count which stores the count value
** in retention ram variable 
**      ->it invokes the MCAL API to clear all SW reset flag register.
**
** Arguments:
** void: N/A.
**
** Return values:- resetReturn
** 		NORMAL_MODE	
REDUCED_MODE 	
STOP_OPERATION 	
DEFAULT_MODE 	

**---------------------------------------------------------------------------*/
//write a if condition to check the cold or warm start

/* 
   In function ret = CheckResetCause1 we are checking 
   ret is
   cold start
   make Safestateflag=0;
   run POST (ASW will write POST)
   OR
   warm start
   make Safestateflag=1;
   */

void SystemResetCauseCheck (void)
{

    //SystemResetFlag resetFlag;
    FlagStatus systemResetFlag;

    /* Invoke MCAL API to read reset cause*/
    McuResetStatusCheck();

    if (mcuResetStatus.bit.powerUpReset == ONE)
    {
	/*Set power on reset flag to 1*/

	resetFlag.pwResetFlag = ONE;
	//systemResetFlag = ResetSetSafeMode();
	

	//DO the POST
    }

    //warm reset
    /*reset due to CMLA0(HS Osc)*/
    if(mcuResetStatus.bit.clma0Reset == ONE)
    {
        /*increment CLMA0 count*/
        Clma0ResetCount++;  //resposible for HS OSC
	/*set HS Osc flag to 1*/
	resetFlag.hsOSCFlag = ONE;
	/*check Clma0ResetCount with the threshold*/
	if(Clma0ResetCount >= CLMA_MAX_RETRY_COUNT)
	{
	    /*prevent from overflow*/
	    Clma0ResetCount = CLMA_MAX_RETRY_COUNT;

	}
    }
    /*reset due to CMLA1(Main OSC)*/
    if(mcuResetStatus.bit.clma1Reset == ONE)
    {
        /*increment CLMA1 count*/
        Clma1ResetCount++;  // MainOSC
	/*set main OSC reset flag to 1*/
	resetFlag.mainOSCFlag = ONE;
	/*check Clma0ResetCount with the threshold*/
	if(Clma1ResetCount >= CLMA_MAX_RETRY_COUNT)
	{
	    /* prevent from overflow */
	    Clma1ResetCount = CLMA_MAX_RETRY_COUNT;

	}
    }
    /*reset due to CMLA2*/
    // if(mcuResetStatus.bit.clma2Reset == ONE)
    // {
    //     /*increment CLMA2 count*/
    //     Clma2ResetCount++;		//PLL0
	// /*set main OSC reset flag to 1*/
	// resetFlag.pll0Flag = ONE;
	// /*check Clma0ResetCount with the threshold*/
	// if(Clma2ResetCount >= CLMA_MAX_RETRY_COUNT)
	// {
	//     /* prevent from overflow */
	//     Clma2ResetCount = CLMA_MAX_RETRY_COUNT;

	// }
    // }
    /*reset due to CMLA3*/
    if(mcuResetStatus.bit.clma3Reset == ONE)
    {
        /*increment CLMA3 count*/
        Clma3ResetCount++;		//PPL
	/*set main OSC reset flag to 1*/
	resetFlag.pplFlag = ONE;
	/*check Clma0ResetCount with the threshold*/
	if(Clma3ResetCount >= CLMA_MAX_RETRY_COUNT)
	{
	    /* prevent from overflow */
	    Clma3ResetCount = CLMA_MAX_RETRY_COUNT;

	}
    }
    /*reset due to Watchdog0*/
    if(mcuResetStatus.bit.wdta0Reset == ONE)
    {

        /*set Watchdog0 flag to 1*/
	resetFlag.wdt0Flag = ONE;

    }
    /*reset due to Watchdog1*/
    if(mcuResetStatus.bit.wdta1Reset == ONE)
    {
	
        /*set Watchdog1 flag to 1*/
	resetFlag.wdt1Flag = ONE;

    }
    /*reset due to Watchdog2*/
    if(mcuResetStatus.bit.wdta2Reset == ONE)
    {
	
        /*set Watchdog2 flag to 1*/
	resetFlag.wdt2Flag = ONE;

    }
    /*reset due to software*/
    if(mcuResetStatus.bit.swReset == ONE)
    {
	/*setting SW reset falg to 1*/
	resetFlag.swResetFlag = ONE;

    }

    /*invoke MCAL API to clear all sofetware reset flag register*/
    McuResetStatusClearAll();
}
/*--------------------------- End SystemResetCauseCheck() -----------------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemShutdownSequence()
**
** Description:
** 	This function is used to do some checks before shutting down the TCU when 
** shutdwon is triggered .
**
** Arguments:
** void: N/A.
**
** Return values:
** NA
**---------------------------------------------------------------------------*/

void SystemShutdownSequence(void)
{
    /*validate shutDownRequestFlag*/
    if(shutDownRequestFlag == ONE)
    {

	/*1.NVM_Manager Storing

	  **2.External_powerSupply(False);  (Gpio)

	  ** checking for the ignition pin state before shutdown
	  SystemAbortSequence(); 

	  **power Hold disable
	  */
	/*write POWER_HOLD pin*/
    /*Check for the gpio pin for the BMS project*/
	/*SystemGpioWritePin(MCU_PORT_P10, MCU_PIN_1 , MCU_GPIO_LOW) ;*/

    }



}/*--------------------------- End SystemShutdownSequence() -----------------------------*/
/*-----------------------------------------------------------------------------
** Function: SystemAbortShutdownSequence()
**
** Description:
** 	This function is used to abort the shutdown sequence at ignition 
** enable pin senses High or any software reset inserts..
**
** Arguments:
** void: N/A.
**
** Return values:
** NA
**---------------------------------------------------------------------------*/
void SystemAbortShutdownSequence(void)
{
    /*read IGNITION_ENABLE pin*/
/*    if(SystemGpioReadWithDebounceOption(MCU_PORT_P18, MCU_PIN_7,ZERO) ==  GPIO_SIGNAL_HIGH) //Abort Shutdown
 -     {
 - 	@/@*$invoke MCAL SW reset API$*@/@
 - 	McuResetSoftware();
 - 
 -     }*/

}/*--------------------------- End CheckResetCause() -----------------------------*/


/*-----------------------------------------------------------------------------
** Function: SystemResetSoftware()
**
** Description:
** 	This function is used to assert the software reset from the ECUAL
**
** Arguments:
** void: N/A.
**
** Return values:
** NA
**---------------------------------------------------------------------------*/
void SystemResetSoftware(void)
{		 
    /*Invoke MCAL software reset API to reset the MCU*/
    McuResetSoftware();

}/*--------------------------- End SystemResetSoftware() -----------------------------*/


/*-----------------------------------------------------------------------------
** Function: ResetSetSafeMode()
**
** Description:
** 	->This function will sets or resets the SafeModeflag
**      ->if main osc flag or SW reset flag or WDT2 flags are high then it 
**	  sets the SafeModeflag else resets it.
**
** Arguments:
** NA
**
** Return values:
** FlagStatus: HIGH or LOW
**---------------------------------------------------------------------------*/
FlagStatus ResetSetSafeMode(void)
{
  
    /*conditions to enable the flag in Warm start*/
    if(resetFlag.mainOSCFlag == ONE || resetFlag.swResetFlag == ONE || resetFlag.wdt0Flag == ONE )
    {
	/*set safemode flag*/
	SafeModeflag = HIGH;//POST should not performed if SafeModeflag is high

    }
    else
    {
	/*reset safemode flag*/
	SafeModeflag = LOW;	     	

    }
    return SafeModeflag ;
}/*--------------------------- End ResetSetSafeMode() -----------------------------*/
/*--------------------------- End SystemReset.c -----------------------------*/
