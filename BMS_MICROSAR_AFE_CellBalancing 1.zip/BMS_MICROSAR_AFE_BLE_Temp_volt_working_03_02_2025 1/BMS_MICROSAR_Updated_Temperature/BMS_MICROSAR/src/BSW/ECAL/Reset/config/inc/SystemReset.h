/***********************************************************************************************************************
* File Name        : SysytemReset.h
* Version          : 1.4
* Device(s)        : R7F701709
* Description      : Header file containing constants, data type definitions, and function
** prototypes for SystemReset Module.
***********************************************************************************************************************/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	:  Not integrated with MCAL
*/
 
#ifndef SYSTEM_RESET_H
#define SYSTEM_RESET_H

/***********************************************************************************************************************
** Includes
***********************************************************************************************************************/
#include "McuGpio.h"
#include "SystemClma.h"
#include "SystemCommonIncludes.h"
#include "retention.h"
#include "McuReset.h"
#include "McuClma.h"
#include "SystemGpio.h"
#include "SystemClockPrivate.h"
/***********************************************************************************************************************
** Global Defines/Typedefs/Enums/Macros
***********************************************************************************************************************/


/*flags for reset cause*/
typedef struct
{
	uint8_t pwResetFlag;
	uint8_t hsOSCFlag;
	uint8_t mainOSCFlag;
	uint8_t pll0Flag;
	uint8_t pplFlag;
	uint8_t wdt0Flag;
	uint8_t wdt1Flag;
	uint8_t wdt2Flag;
	uint8_t swResetFlag;
}SystemResetFlag;

typedef enum
{
    LOW,
    HIGH

}FlagStatus;

/***********************************************************************************************************************
** Exported Global Variable Declarations
***********************************************************************************************************************/
extern SystemResetFlag resetFlag;
//extern SystemSwitchs debounceIndex;
extern FlagStatus SafeModeflag;
extern uint8_t shutDownRequestFlag;
/***********************************************************************************************************************
** Exported Function Declarations
***********************************************************************************************************************/

extern void SystemResetCauseCheck (void);
extern void SystemShutdownSequence(void);
extern void SystemAbortShutdownSequence(void);
extern void SystemResetSoftware(void);
extern FlagStatus ResetSetSafeMode(void);
#endif//SYSTEM_RESET_H











