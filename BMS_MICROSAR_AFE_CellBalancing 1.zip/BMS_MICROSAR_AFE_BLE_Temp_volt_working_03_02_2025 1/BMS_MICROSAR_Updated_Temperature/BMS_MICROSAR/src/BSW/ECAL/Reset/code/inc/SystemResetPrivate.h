/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemResetPrivate.h
**
** Description:
** General Header file for System reset
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_RESET_PRIVATE_H
#define SYSTEM_RESET_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/



#endif /* SYSTEM_RESET_PRIVATE_H */