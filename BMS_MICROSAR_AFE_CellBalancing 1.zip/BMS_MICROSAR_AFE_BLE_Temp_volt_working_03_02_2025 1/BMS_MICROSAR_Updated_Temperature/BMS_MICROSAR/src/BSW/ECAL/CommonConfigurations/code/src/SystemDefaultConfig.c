/*-----------------------------------------------------------------------------
**                            
** File: SystemDefaultConfig.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of test module.
**---------------------------------------------------------------------------*/
 
/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "SystemDefaultConfig.h"
#include "SystemDefaultConfigPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
 void SystemCsih0Create(void);

// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: SystemCommonGpioInit()
**
** Description:
** This function configures the all GPIO's as per the requirements.
**
** Arguments:
** NA
**
** Return values:
** NA
**---------------------------------------------------------------------------*/


void SystemCommonConfig(void)
{
 
    SystemGpioInit(	MCU_PORT_P0, 
			MCU_PIN_2, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );

	 SystemGpioInit(MCU_APORT0, 
			MCU_PIN_0, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );

	  SystemGpioInit(MCU_APORT0, 
			MCU_PIN_1, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );

	  SystemGpioInit(MCU_APORT0, 
			MCU_PIN_2, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );
	  SystemGpioInit(MCU_APORT0, 
			MCU_PIN_3, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );
	  SystemGpioInit(MCU_APORT0, 
			MCU_PIN_4, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );
	   SystemGpioInit(MCU_APORT0, 
			MCU_PIN_5, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );
	   SystemGpioInit(MCU_APORT0, 
			MCU_PIN_5, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );

		 SystemGpioInit(MCU_APORT0, 
			MCU_PIN_6, 
			MCU_GPIO_INPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_DISABLE
		   );

		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_0, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );

		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_1, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_2, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_3, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_4, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_5, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		 SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_6, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		  SystemGpioInit(	MCU_PORT_P10, 
			MCU_PIN_4, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		   SystemGpioInit(	MCU_PORT_P10, 
			MCU_PIN_5, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		    SystemGpioInit(	MCU_PORT_P10, 
			MCU_PIN_6, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		   SystemGpioInit(	MCU_PORT_P10, 
			MCU_PIN_9, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
		   SystemGpioInit(	MCU_PORT_P8, 
			MCU_PIN_3, 
			MCU_GPIO_OUTPUT,
			MCU_GPIO_ALT_DEFAULT,
			MCU_GPIO_SW_CONTROL,
			MCU_GPIO_LOW_DRIVE_STRENGTH,
			MCU_GPIO_PUSH_PULL,
			MCU_GPIO_FLOATING,
			MCU_GPIO_BI_DIRECTIONAL_MODE_ENABLE 
		   );
	  
}
/*----------------------End SystemCommonGpioInit()---------------------------*/

/*----------------------End SystemDefaultConfig.c----------------------------*/

