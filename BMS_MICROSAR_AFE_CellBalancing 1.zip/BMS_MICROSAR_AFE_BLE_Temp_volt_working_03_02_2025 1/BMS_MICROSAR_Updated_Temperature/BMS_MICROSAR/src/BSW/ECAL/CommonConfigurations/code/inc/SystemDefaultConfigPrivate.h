/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemDefaultConfigPrivate.h
**
** Description:
** General Header file for System WatchDogTimers in ECUAL
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_DEFAULT_CONFIG_PRIVATE_H
#define SYSTEM_DEFAULT_CONFIG_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/



#endif // SYSTEM_DEFAULT_CONFIG_PRIVATE_H 
