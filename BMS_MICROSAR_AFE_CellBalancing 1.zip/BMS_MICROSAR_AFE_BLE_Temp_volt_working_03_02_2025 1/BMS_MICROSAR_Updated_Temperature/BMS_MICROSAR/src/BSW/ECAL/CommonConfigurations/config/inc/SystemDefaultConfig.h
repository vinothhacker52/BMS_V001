/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemDefaultConfig.h
**
** Description:
** General Header file for System Circuit
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_DEFAULT_CONFIG_H
#define SYSTEM_DEFAULT_CONFIG_H
/*----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemCommonIncludes.h"
#include "SystemGpio.h"

/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define ONE_KILO_HERTZ 		1000

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
void SystemCommonConfig(void);
extern void CreateClock(void);
extern void CreatePort(void);
extern void CreateTimers(void);
extern void CreateNormalClma(void);
extern void CreateReducedClma(void);
extern void StartNormalClma(void);
extern void StartReducedClma(void);
extern void SystemCommonGpioInit(void);



#endif//SYSTEM_DEFAULT_CONFIG_H
/*---------------------------------End SystemDefaultConfig.h---------------------------*/
