/*-----------------------------------------------------------------------------
**                            � 2025 Your Company Name
** File: SystemGpio.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for Digital Input or Output Module System in the ECUAL .
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	:  Not integrated with MCAL
*/
 
#ifndef SYSTEM_GPIO_H
#define SYSTEM_GPIO_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/

#include <stdbool.h>
#include "McuGpio.h"
#include "SystemCommonIncludes.h"


/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/


typedef enum {
	
    SYS_GPIO_LOW = ZERO,
    SYS_GPIO_HIGH = ONE,
    SYS_GPIO_DEFAULT = TWO,

} SystemGpioState;




/*to check gpio initalise status*/
typedef enum {
	
    SYSTEM_GPIO_INITIALIZED 	= ZERO,
    SYSTEM_GPIO_UNINITIALIZED 	= ZERO,

} SystemGpioInitStatus;

/*to create pin in portlist*/
typedef struct SYSTEM_PORT_LIST
{
	uint8_t pin[SIXTEEN];
	
}SystemPortList;

/*to create the no of port list*/
extern SystemPortList portPinState[ELEVEN];

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern McuGpioStatus SystemGpioInit(	McuGpioPort portNum, 
					McuGpioPin pinNum, 
					McuGpioDir pinDirection,
					McuGpioAltFunc altFunc, 
					McuGpioPortControl portcntrl,
					McuGpioDriveStrength drive,
					McuGpioOutputMode gpioPinMode,
					McuGpioInputResistor ipResister,
					McuGpioBidirectionControl bdControl
				   );
extern void SystemGpioWritePin(McuGpioPort portNum, McuGpioPin pinNum, McuGpioState pinState) ;
extern SystemGpioState SystemGpioReadPin(McuGpioPort portNum, McuGpioPin pinNum) ;
extern void SystemGpioHandlerFunction(void);

#endif // SYSTEM_GPIO_H

/*--------------------------- End SystemGpio.h -----------------------------*/
