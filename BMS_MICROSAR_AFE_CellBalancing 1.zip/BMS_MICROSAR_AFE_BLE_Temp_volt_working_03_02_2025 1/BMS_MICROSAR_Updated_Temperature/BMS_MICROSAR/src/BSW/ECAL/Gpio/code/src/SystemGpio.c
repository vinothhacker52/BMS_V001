/*-----------------------------------------------------------------------------
**                            
** File: SystemGpio.c
**
** Description:
** This source file defines the functions, macros, and variables related
** to the operation of the GPIO module in ECUAL .
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************

  /*-----------------------------------------------------------------------------
  ** Includes
  **---------------------------------------------------------------------------*/
#include <stdbool.h>
#include "SystemGpio.h"
#include "SystemGpioPrivate.h"


/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
static SystemPortList portPinState[ELEVEN];
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
//SystemGpioDebounceStatus read_pin_status(McuGpioPort port, McuGpioPin pin);
/*-----------------------------------------------------------------------------
** Function: SystemGpioInit()
** Description:
** This function configures a single GPIO pin based on the provided parameters.
**
** Arguments:
** portNum	: The GPIO port number.
** pinNum	: The GPIO pin number.
** pinDirection	: The direction of the pin(i/p or o/p).
** alt 		: Alternate function of the pin.
** modeType	: The mode type of the GPIO pin(pushpull / opendrain).
** drive	: The drive strength of the GPIO pin.(LOW_drive / High_Drive).
** gpioPinMode	: Push-Pull or Open Drain
** ipResister	: Floating, Pull-Up or Pull-Down
** bdControl	: enables the pin in bidirectional mode
**
** Return values: gpioInitStatus	
**	 
**---------------------------------------------------------------------------*/

McuGpioStatus SystemGpioInit(	McuGpioPort portNum, 
	McuGpioPin pinNum, 
	McuGpioDir pinDirection,
	McuGpioAltFunc altFunc, 
	McuGpioPortControl portcntrl,
	McuGpioDriveStrength drive,
	McuGpioOutputMode gpioPinMode,
	McuGpioInputResistor ipResister,
	McuGpioBidirectionControl bdControl
	)
{
    /*create an instance for McuGpioPinConfig to configure the port and pin*/
    McuGpioPinConfig mcuGpioCfg;

    McuGpioStatus gpioInitStatus = MCU_GPIO_OK;
    /*MCAL McuGpioPinConfig structure initialization*/
    mcuGpioCfg.port = portNum;
    mcuGpioCfg.pin = pinNum;
    mcuGpioCfg.dir = pinDirection;
    mcuGpioCfg.alt = altFunc;
    mcuGpioCfg.portControl = portcntrl;
    mcuGpioCfg.driveStrength = drive;
    mcuGpioCfg.pinOutputMode = gpioPinMode;
    mcuGpioCfg.inputResistorConfig = ipResister;
    mcuGpioCfg.biDirectionControl = bdControl;

    /*Invoke MCAL function to intialze the port& pin*/
    gpioInitStatus = McuGpioPortInit(&mcuGpioCfg);
    //Init
    return gpioInitStatus;
}/*--------------------------- End SystemGpioInit() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemGpioReadWithDebounceOption()
**
** Description:
** This function uses to read the status of Gpio pins including with the input
** switches deboucing and error handling 
**
** Arguments:
** portNum : the GPIO port number.
** pinNum : the Gpio Pin number.
** debounceFlag : Presence of Debouncing process(0 or 1)
**
** Return values:
** returnValue: Returns the status of the pin either HIGH or LOW or LOOSE_WIRE
**---------------------------------------------------------------------------*/
#if 1
SystemGpioState SystemGpioReadPin(McuGpioPort portNum, McuGpioPin pinNum)
{
    SystemGpioState  systemGpioState = SYS_GPIO_DEFAULT;

    systemGpioState = (SystemGpioState) McuGpioGetInputState(portNum, pinNum);

    /*return status*/
    return systemGpioState ;
}/*--------------------------- End SystemGpioReadWithDebounceOption() -----------------------*/

#endif 

/*-----------------------------------------------------------------------------
** Function: SystemGpioWritePin()
**
** Description:
** This function isolates the drivers and application layer to make 
** GPIO pins high.
**
** Arguments:
** port: The GPIO port.
** pin: The GPIO pin.
** state: The desired state of the GPIO pin (high or low).
**          MCU_GPIO_HIGH
**          MCU_GPIO_LOW
**
** Return values:NA
**---------------------------------------------------------------------------*/
void SystemGpioWritePin(McuGpioPort portNum, McuGpioPin pinNum, McuGpioState pinState) 
{
    /*assign pinstate to array*/
    portPinState[portNum].pin[pinNum] = (uint8_t)pinState;
    /*Invoke MCAL API to write the output pin based on port and pin numbers and state*/
    McuGpioSetOutputState(portNum, pinNum, pinState);  

} /*--------------------------- End SystemGpioWritePin() -----------------------*/




/*--------------------------- End SystemGpio.c -----------------------------*/


