/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemGpioPrivate.h
**
** Description:
** General Header file for System Gpio
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_GPIO_PRIVATE_H
#define SYSTEM_GPIO_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/



#endif /* SYSTEM_GPIO_PRIVATE_H */
