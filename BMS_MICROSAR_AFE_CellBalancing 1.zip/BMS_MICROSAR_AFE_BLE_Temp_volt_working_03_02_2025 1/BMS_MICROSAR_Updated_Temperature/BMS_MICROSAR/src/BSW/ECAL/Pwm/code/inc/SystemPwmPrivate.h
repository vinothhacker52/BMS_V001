/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemPwmPrivate.h
**
** Description:
** General Header file for System pwm
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_PWM_PRIVATE_H
#define SYSTEM_PWM_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/



#endif /* SYSTEM_PWM_PRIVATE_H */