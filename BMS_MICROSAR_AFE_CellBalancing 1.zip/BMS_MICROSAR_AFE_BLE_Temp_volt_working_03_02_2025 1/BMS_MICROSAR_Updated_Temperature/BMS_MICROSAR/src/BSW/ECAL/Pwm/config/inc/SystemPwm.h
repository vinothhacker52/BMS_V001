/*-----------------------------------------------------------------------------
**                            
** File: SystemPwm.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for the ECUAL layer of the PWM Module.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 	:  10-June-2025  : Initial Version
*/
 
#ifndef SYSTEMPWM_H
#define SYSTEMPWM_H

#include "McuPwm.h"
#include "SystemCommonIncludes.h"
#include "SystemClock.h"


/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

#define MIN_PWM_FREQUENCY 10.0
#define MAX_PWM_FREQUENCY 1000.0
#define MIN_PWM_DUTYCYCLE 1.0
#define MAX_PWM_DUTYCYCLE 99.0

typedef enum
{
    PWM_UN_INITIALIZED=0,
    PWM_INITIALIZED=1
}PwmInitialise;

typedef enum
{
    PWM_NOTSTARTED,
    PWM_STARTED,
    PWM_NOT_INTITIALIZED,
    PWM_INTITIALIZED,
    INVALID_DUTY_OR_FREQ
}SystemPwmStatus;

typedef enum SYSTEM_PWM_SLAVE_OUTPUT_LEVEL_CHANNEL
{
    /* Specifies/reads the level of TAUBTTOUTm (TAUBnTO1) */
    TAUJ_CH1_NEGATIVE                   =         0x0002U,   /* Low level */
    TAUJ_CH1_POSITIVE                   =         0xFFFDU,   /* High level */
    
//    /* Specifies/reads the level of TAUBTTOUTm (TAUBnTO3) */
//    TAUB_CH3_NEGATIVE                   =         (0xFFF7U), /* Low level */
//    TAUB_CH3_POSITIVE                   =         (0x0008U), /* High level */
//
//    /* Specifies/reads the level of TAUBTTOUTm (TAUBnTO5) */
//    TAUB_CH5_NEGATIVE                   =         (0xFFDFU), /* Low level */
//    TAUB_CH5_POSITIVE                   =         (0x0020U),/* High level */
//    
//    /* Specifies/reads the level of TAUBTTOUTm (TAUBnTO7) */
//    TAUB_CH7_NEGATIVE                   =         (0xFF7FU),/* Low level */
//    TAUB_CH7_POSITIVE                   =         (0x0080U),/* High level */
}SystemPwmOutputLogic;


/*to config channels*/
typedef struct SYSTEM_PWM_CHANNEL_CONFIG_STRUCT
{
	
    McuPwmOutputLogic pwmOutputLevel;
    uint32_t dutyCycle;	/*dutycycle ranges from 1% to 99%*/
   
}SystemPwmChannelConfig;
/*to configur pwm channels*/
typedef struct SYSTEM_PWM_CONFIG
{
    uint32_t frequency;			/* PWM output frequency*/
    SystemPwmChannelConfig PwmCh1;     /*PWM Channel 1*/
//    SystemPwmChannelConfig PwmCh3;	/*PWM Channel 3*/
//    SystemPwmChannelConfig PwmCh5;	/*PWM Channel 5*/
//    SystemPwmChannelConfig PwmCh7;	/*PWM Channel 7*/
   
}SystemPwmConfig;
 
   
/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern PwmInitialise IsPwmInitialised ;


/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern SystemPwmStatus SystemPwmInit(SystemPwmConfig * pPwmConfig);
extern SystemPwmStatus SystemPwmStart(void);
extern void SystemPwmStop(void);


#endif // SYSTEMPWM_H

/*--------------------------- End SystemOstim0.h -----------------------------*/
