/*-----------------------------------------------------------------------------                  
** File: SystemPwm.c
**
** Description:
** This source file defines the ECUAL functions, macros and variables related
** to the operation of PWM.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/


/*******************************************************************************
**                      MISRA C Rule Violations                               **
*******************************************************************************/

/******************************************************************************/

/* 1. MISRA C RULE VIOLATION:                                                 */
/* Message       : Controlling expressions shall not be invariant.            */
/*                                                                            */
/* Rule          : MISRA-C:2012 D1.1                                        */
/* Justification : The use of float constants and explicit casting ensures    */
/*                 hat the behavior of the expressionis predictable and       */

/*                                                                            */                                                   
/* Verification  : The violation doesnt affect the module negatively.          */
/* Reference     : Look for START Msg(MISRA_PWM:1 - 6) and                    */
/*                 END Msg(MISRA_PWM:1 - 6) tags in the code.                 */

/******************************************************************************/

/******************************************************************************/
#include "SystemPwm.h"
#include "SystemPwmPrivate.h"


/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
PwmInitialise IsPwmInitialised = PWM_UN_INITIALIZED; // changes made 
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/
/*porototype declerations are generetaing violations*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: SystemPwmInit()
**
** Description:
** This function calculates the pulse value and compare values and loading into mcal structure .
** configures all channels at once and initializes MCAL structure.
** 
** Arguments: 
** pPwmConfig
**
** Return values:
** pwmInitStatus :  PWM_NOTSTARTED,
		    PWM_STARTED,
		    PWM_NOT_INTITIALIZED,
		    PWM_INTITIALIZED,
		    INVALID_DUTY_OR_FREQ
**---------------------------------------------------------------------------*/
 
SystemPwmStatus SystemPwmInit(SystemPwmConfig *pPwmConfig)
{
    /*Local Variables and initializations*/
    McuPwmConfig mcuPwmCfg;
    SystemPwmStatus pwmInitStatus  = PWM_NOT_INTITIALIZED;
    float compareValue = ZERO_FLOAT;
    float pulseValue = ZERO_FLOAT;
    float clockSource = ZERO_FLOAT;
    /*calculate pulse value*/
    /*PRESCALAR_2 : The input clock is divided by 2 */
    /* Clock source frequency in Hz after dividing PLL frequency by prescaler */
    /*START Msg(MISRA_PWM:1)*/
    clockSource = ((float)freqUsing.PPLLFrequency * PRESCALAR_2);
    /*END Msg(MISRA_PWM:1)*/
    if(((pPwmConfig->frequency) != ZERO)&&(((pPwmConfig->PwmCh1.dutyCycle )>= (uint32_t)MIN_PWM_DUTYCYCLE) && ((pPwmConfig->PwmCh1.dutyCycle )<= (uint32_t)MAX_PWM_DUTYCYCLE)))
    {
	       /*START Msg(MISRA_PWM:2)*/
	       pulseValue = (float)((float)((clockSource / (float)pPwmConfig->frequency)- ONE_FLOAT));//refer section 31.14.1.2 in datasheet for the formulea
	       /*END Msg(MISRA_PWM:1)*/
	       pwmInitStatus  = PWM_INTITIALIZED;
    }
    else
    {
	       pwmInitStatus = INVALID_DUTY_OR_FREQ;
    }
    /*pulse value into mcal structure variable*/
    mcuPwmCfg.masterCmpValue = (uint16_t)pulseValue;
    /* Range  */
    /*convrt dutycycle into compare value*/
    /*START Msg(MISRA_PWM:3)*/
    compareValue = (float)(((float)pPwmConfig->PwmCh1.dutyCycle * DUTY_CYCLE_CONVERSION_FACTOR) * pulseValue);
    /*END Msg(MISRA_PWM:3)*/
    /*load the Compare value to MCAL structure variable*/
    mcuPwmCfg.channel1.cmpValue = (uint16_t)compareValue;
    /*Loadng the outlogic*/
    mcuPwmCfg.channel1.activeOutputLevel  = pPwmConfig->PwmCh1.pwmOutputLevel;
    /* Clutch */
    /*convet dutycycle into compare value*/
    /*START Msg(MISRA_PWM:4)*/
//    compareValue = (float)(((float)pPwmConfig->PwmCh3.dutyCycle * DUTY_CYCLE_CONVERSION_FACTOR) * pulseValue);
    /*END Msg(MISRA_PWM:4)*/
    /*load the Compare value to MCAL structure variable*/
    //mcuPwmCfg.channel3.cmpValue = (uint16_t)compareValue;
    /*Loadng the outlogic*/
    //mcuPwmCfg.channel3.activeOutputLevel = pPwmConfig->PwmCh3.pwmOutputLevel;
    /* Gear Select */
    /*convet dutycycle into compare value*/
   /*START Msg(MISRA_PWM:5)*/
    //compareValue = (float)(((float)pPwmConfig->PwmCh5.dutyCycle * DUTY_CYCLE_CONVERSION_FACTOR) * pulseValue);
    /*END Msg(MISRA_PWM:5)*/
    /*load the Compare value to MCAL structure variable*/
    //mcuPwmCfg.channel5.cmpValue = (uint16_t)compareValue;
    /*Loadng the outlogic*/
    //mcuPwmCfg.channel5.activeOutputLevel = pPwmConfig->PwmCh5.pwmOutputLevel;
 
    /*  Gear Shift */ 
    /*convrt dutycycle into compare value*/
    /*START Msg(MISRA_PWM:6)*/
    //compareValue =(float)( ((float)pPwmConfig->PwmCh7.dutyCycle * DUTY_CYCLE_CONVERSION_FACTOR) * pulseValue);
    /*END Msg(MISRA_PWM:6)*/
    /*load the Compare value to MCAL structure variable*/
    //mcuPwmCfg.channel7.cmpValue = (uint16_t)compareValue;
    /*Loadng the outlogic*/
    //mcuPwmCfg.channel7.activeOutputLevel = pPwmConfig->PwmCh7.pwmOutputLevel;	

 
    /* Invoke MCAL PWM Init API  */
    McuPwmInit(&mcuPwmCfg);

    /* Storing the status of initialization */
    IsPwmInitialised = PWM_INITIALIZED;
    return pwmInitStatus ;
}
/*--------------------------- End SystemPwmInit() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemPwmStart()
**
** Description:
** Function to Start the PWM.
**
** Arguments: 
** pClmaConfig
**
** Return values:
** pwmStatus: start status of pwm.
**	PWM_NOTSTARTED
**	PWM_NOT_INTITIALIZED
**	PWM_STARTED
**---------------------------------------------------------------------------*/

SystemPwmStatus SystemPwmStart(void)
{
    /*default PWM status*/
    SystemPwmStatus pwmStatus = PWM_NOTSTARTED;
    
    /*validating PWM initialised or not*/
    if(IsPwmInitialised == PWM_UN_INITIALIZED)
    {
	/*eroor case*/
        pwmStatus = PWM_NOT_INTITIALIZED;
    }
    else
    { 
        /*start the pwm*/
        McuPwmStart();
	pwmStatus = PWM_STARTED;
    
    }
    /*return pwmstatus to application*/
    return pwmStatus; 

}/*--------------------------- End SystemPwmStart() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemPwmStop()
**
** Description:
** Function to Stop the PWM.
**
** Arguments: 
** NONE
**
** Return values:
** NA
**---------------------------------------------------------------------------*/

void SystemPwmStop(void)
{
    /*stop the pwm*/
    McuPwmStop();

}/*--------------------------- End SystemPwmStop() -----------------------*/

/*--------------------------- End SystemPwm.c -----------------------*/
