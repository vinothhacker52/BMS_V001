/*-----------------------------------------------------------------------------
**                           @ 2025 Ashokleyland
** File:SystemBle.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of UART Transmit and Receive
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                               **
*****************************************************************************************************************************************/
/*
 * V1.0 	:  25-Jun-2025  : Initial Version
 * v1.1     :  21-Jul-2025  : Version Integrated with Temporary CAN drivers
 */
/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemBle.h"
#include "SystemAfe.h"
//#include <stdint.h>
#include <stdio.h>
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/
uint8_t bleStrBuffer[20];
uint8_t bleFloatBuffer[7];
extern SystemUartAfeMeas pMeasurements;
uint8_t newLineChar[2] = {0x0D, 0x0A};
const char bleCellStr[18][20] = {
    {"Cell Voltage 00 : "},
    {"Cell Voltage 01 : "},
    {"Cell Voltage 02 : "},
    {"Cell Voltage 03 : "},
    {"Cell Voltage 04 : "},
    {"Cell Voltage 05 : "},
    {"Cell Voltage 06 : "},
    {"Cell Voltage 07 : "},
    {"Cell Voltage 08 : "},
    {"Cell Voltage 09 : "},
    {"Cell Voltage 10 : "},
    {"Cell Voltage 11 : "},
    {"Cell Voltage 12 : "},
    {"Cell Voltage 13 : "},
    {"Cell Voltage 14 : "},
    {"Cell Voltage 15 : "},
    {"Cell Voltage 16 : "},
    {"Cell Voltage 17 : "}
};
const char bleTempStr[8][10] = {
    {"NTC 0 : "},
    {"NTC 1 : "},
    {"NTC 2 : "},
    {"NTC 3 : "},
    {"NTC 4 : "},
    {"NTC 5 : "},
    {"NTC 6 : "},
    {"NTC 7 : "}
};
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/***********************************************************************************************************************
 * Function Name: SystemBleInit
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void SystemBleInit(void){
    McuUart1Init();
    McuUart1Start();
}

/***********************************************************************************************************************
 * Function Name: SystemBleSend
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/


void SystemBleSend(const char *str, uint8_t str_len, float value)
{
    uint8_t i;
    char float_str[10];
    /* Convert string to ASCII hex */
    for (i = 0; i < str_len && i < 20; i++)
    {
        bleStrBuffer[i] = (uint8_t)str[i];
    }
    /* Convert float to string */
    //snprintf(float_str, sizeof(float_str), "%.3f", value);
    /* Take first 5 characters of float string */
    if(value < 0){
	value = value * -1;
	bleFloatBuffer[0] = (uint8_t)('-');
    }
    else{
	bleFloatBuffer[0] = (uint8_t)(' ');
    }
    int int_part = (int)value;
    int frac_part = (int)((value - int_part) * 1000);
    bleFloatBuffer[1] = (uint8_t)(int_part + '0');
    bleFloatBuffer[2] = (uint8_t)('.');
    bleFloatBuffer[3] = (uint8_t)((frac_part /100) + '0');
    bleFloatBuffer[4] = (uint8_t)((frac_part /10 % 10) + '0');
    bleFloatBuffer[5] = (uint8_t)((frac_part % 10) + '0');
    bleFloatBuffer[6] = (uint8_t)0x0D;
    bleFloatBuffer[7] = (uint8_t)0x0A;
    
    McuUart1Tx(&bleStrBuffer, str_len);
    McuUart1Tx(&bleFloatBuffer, 8);
    
    
}
/***********************************************************************************************************************
 * Function Name: SystemBlePcvmSend
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void SystemBlePcvmSend(void){
    
    for(uint8_t cellNo = 0; cellNo < 18; cellNo++)
	SystemBleSend(&bleCellStr[cellNo], 18, pMeasurements.PCVM[cellNo]);
    
    McuUart1Tx(&newLineChar, 2);

}
/***********************************************************************************************************************
 * Function Name: SystemBleTempSend
 * Description  : This function starts the Config_UART1 module operation.
 * Arguments    : None
 * Return Value : None
 ***********************************************************************************************************************/
void SystemBleTempSend(void){
    for(uint8_t ntcNo = 0; ntcNo < 8; ntcNo++)
	SystemBleSend(&bleTempStr[ntcNo], 8, pMeasurements.extTemp[ntcNo]);
    
    McuUart1Tx(&newLineChar, 2);
}
