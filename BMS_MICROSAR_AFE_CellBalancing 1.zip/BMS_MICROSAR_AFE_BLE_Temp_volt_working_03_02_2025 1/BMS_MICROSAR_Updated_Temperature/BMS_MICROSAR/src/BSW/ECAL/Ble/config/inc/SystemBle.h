/*-----------------------------------------------------------------------------
**                           � 2025 Ashokleyland
** File: SystemTle9018.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for SystemUart functions
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_BLE_H
#define SYSTEM_BLE_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/

#include "McuTypedefs.h"
#include "McuUart1.h"
#include <stdbool.h>

/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/


extern void SystemBleSend(const char *str, uint8_t str_len, float value);
extern void SystemBleInit(void);
extern void SystemBlePcvmSend(void);
extern void SystemBleTempSend(void);
#endif /*SYSTEM_TLE9018_H*/

/*--------------------------End SystemCan.h----------------------------------*/
