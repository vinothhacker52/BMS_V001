/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemTle9018Private.h
**
** Description:
** General Header file for System Circuit
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_BLE_PRIVATE_H
#define SYSTEM_BLE_PRIVATE_H



#endif//SYSTEM_TLE9018_PRIVATE_H
