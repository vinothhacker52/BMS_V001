/*-----------------------------------------------------------------------------
**                            
** File: SystemClma.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for clock monitoring module(CLMA) in ECUAL .
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	:  Not integrated with MCAL
 */
 
#ifndef SYSTEM_CLMA_H
#define SYSTEM_CLMA_H

#include "SystemCommonIncludes.h"
#include "SystemClock.h"
#include "McuReset.h"
#include "McuClma.h"

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/
extern void SystemClmaInit(McuClmaId sysClmaId);
extern void SystemClmaControl(McuClmaId sysClmaId,McuClmaStatus operation );
 

#endif // SYSTEM_CLMA_H

/*--------------------------- End McuClma.h -----------------------------*/