/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemClmaPrivate.h
**
** Description:
** General Header file for System CLMA
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_CLMA_PRIVATE_H
#define SYSTEM_CLMA_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

#define PERCENTAGE_FIVE		5
#define PERCENTAGE_ONE		1


#endif /* SYSTEM_CLMA_PRIVATE_H */
