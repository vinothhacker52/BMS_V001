/*-----------------------------------------------------------------------------
**                            ï¿½ 2025 Ashok Leyland
** File: SystemClma.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of Clock monitor in ECUAL .
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	: Not Integrated with the project

 * V1.6		: 10 - June - 2025 : Integrated with project

 * V1.7		: 19 - June - 2025 : No change

 * V1.8 	: 00 - June - 2025 : The following Chamges  was made
 			1. name changed from McuClockMonitorInit to McuClmaInit.
			2. name changed from McuClockMonitorControl to McuClmaControl.
			3. name changed from SystemClockMonitorInit to SystemClmaInit
			4. name changed from SystemClockMonitorControl to SystemClmaControl
*/
#include "SystemClma.h"
#include "SystemClmaPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/


// <Add any functions whose "scope" is limited to this module here>

 
/*-----------------------------------------------------------------------------
** Function: SystemClmaInit()
**
** Description:
** Function to initialize clock monitor with CLMAID and tolerance, frequency.
**
** Arguments: 
** 1.sysClmaId : clock monitor ID 
** 		 CLMA0
		 CLMA1
		 CLMA3
** Return values:
** None
**---------------------------------------------------------------------------*/
void SystemClmaInit(McuClmaId sysClmaId)
{
     McuClmaConfig clmaConfig;
     /*Mcal clmaConfig structure configuration*/
     clmaConfig.clmaId = sysClmaId;
    /*input validation*/
    switch (sysClmaId) //validating input from app layer
    {
        case CLMA_0://for HsOSC
            
            /*mcal clmaConfig structure initialization*/
            clmaConfig.clockFreq =  freqUsing.HSOscFrequency;//using the same clock which was configured in clock config
            clmaConfig.tolerence =  PERCENTAGE_FIVE;         //5% tolerance 
            break;
        case CLMA_1://for MainOsc
           /*mcal clmaConfig structure initialization*/
            clmaConfig.clockFreq =  freqUsing.MainOscFrequency;//main Oscillator
            clmaConfig.tolerence =  PERCENTAGE_FIVE; //5% tolerance 
            break;

	case CLMA_3://for PPLL
           /*mcal clmaConfig structure initialization*/
            clmaConfig.clockFreq = freqUsing.PPLLFrequency;//PPLL 
            clmaConfig.tolerence = PERCENTAGE_FIVE; //5% tolerance 
            break;
        default: 
	    /*error state*/
	    break;//error case
	
           
    }
    /* Invoke the MCAL API to initialize the specified CLMA with the clock frequency and % of tolerance*/ 
    McuClmaInit(&clmaConfig);
    
    
}/*--------------------------- End SystemClmaInit() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: SystemClmaControl()
**
** Description :
** Function to initialize clock monitor with CLMAID to monitor clock frequency abnormality.
**
** Arguments:
** 1.sysClmaId : clock monitor ID 
** 		 CLMA0
		 CLMA1
		 CLMA3
** 2.status    : ENABLE_CLMA
** 		 DISABLE_CLMA
** Return values:
** None
**---------------------------------------------------------------------------*/
 
void SystemClmaControl(McuClmaId sysClmaId,McuClmaStatus operation )
{    
    
    /* Invoke the MCAL API to control the specified CLMA Id with the desired operation status*/
    McuClmaControl(sysClmaId,operation);
    
    
}/*--------------------------- End SystemClockMonitorStart () -----------------------*/

/*----------------------------------- End SystemClma.c --------------------------------*/
