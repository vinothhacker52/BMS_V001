/*-----------------------------------------------------------------------------
**                            ï¿½ 2025 Ashok Leyland
** File: SystemClock.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of clock module in ECUAL .
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*

*/
/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemClock.h"
#include "SystemClockPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/
/*Instance to hold the clock frequency configuration reused across different modules*/
ClockFreq freqUsing;

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/
static SystemClockStatus ClockNormalModeInit	(void);
static SystemClockStatus ClockReducedModeInit	(void);


// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: SystemClockInit()
**
** Description:
** Initializes system wide clocks
** intitializes every CLMA.
** checks reset cause.
**
** Arguments:
** void: N/A.
**
** Return values:
** NA.
**---------------------------------------------------------------------------*/
	
SystemClockInitStatus SystemClockInit(void)
{	
	/*default initializations*/
	SystemClockInitStatus clockInitStatus = NORMAL_CLOCK_INIT_SUCCESS;
	SystemClockMode resetState = STOP_OPERATION ;
	SystemClockStatus normalClockInitState = SYS_CLOCK_OK;                    //@changed from uninitialized 
	SystemClockStatus reducedClockInitState = SYS_CLOCK_OK;			 //@changed from uninitialized 
	
	/*retrieving reset cause by calling Mcal func*/
	//SystemResetCauseCheck();
	
	/*Invoke SystemClockModeHandler API to decide which clock need to be used and store return in a variable */
	resetState = (SystemClockMode) SystemClockModeHandler();
	/*validate return variable status*/
	if(resetState == NORMAL_MODE)
	{
		/*if the return ofSystemClockModeHandler is NORMAL_MODE then clock sjould be in normalmode */
		normalClockInitState =  ClockNormalModeInit();
		/*validate clock Initialization status*/
		if(normalClockInitState == SYS_CLOCK_FAIL)							//@changed != to ==
		{
			/*if fails increase ClockActivationRetryCount*/
			//NormalClockActivationFailureCount++;
			clockInitStatus = NORMAL_CLOCK_INIT_FAIL;
			/*Compare ClockActivationRetryCount with threshold value*/
			if(NormalClockActivationFailureCount >= MAX_CLK_ACTIVATION_RETRY_COUNT)
			{
				/*invoke ClockReducedModeInit API for fallback mode */
				//ClockReducedModeInit();
				resetState = REDUCED_MODE;
				
			}
		        else
		        {
			    //SystemResetSoftware();

		        }
			
		}
		
	}
	/*validate return variable status*/
	if (resetState == REDUCED_MODE)
	{
		/*InvokeSystemClockModeHandler API to decide which clock need to be used and store return in a variable */
		reducedClockInitState =  ClockReducedModeInit();
		/*validate clock Initialization status*/
		if(reducedClockInitState == SYS_CLOCK_FAIL)							//@changed != to ==
		{
			/*if fails increase ClockActivationRetryCount*/
			ReducedClockActivationFailureCount++;
			clockInitStatus = REDUCED_CLOCK_INIT_FAIL;
			/*Compare ClockActivationRetryCount with threshold value*/
			if(ReducedClockActivationFailureCount > MAX_CLK_ACTIVATION_RETRY_COUNT)
			{
				//stop operation
				resetState = STOP_OPERATION;
			}
			else
			{
			    SystemResetSoftware();

			}
			
		}
		
		
	}
	if(resetState == STOP_OPERATION)//if mainOSC fails it will be handled here
	{
		clockInitStatus = SYS_CLOCK_INIT_FAIL;
		//NOP
	}
	return clockInitStatus;
	
}/*--------------------------- End SystemClockInit() -----------------------------*/

 
/*-----------------------------------------------------------------------------
** Function: ClockNormalModeInit()
**
** Description:
** Initializes system wide clocks
** intitializes every CLMA.
**
** Arguments:
** void: N/A.
**
** Return values:
** SystemClockStatus:-SYS_CLOCK_OK   	
                      SYS_CLOCK_FAIL	
                      		
**
**---------------------------------------------------------------------------*/

static SystemClockStatus ClockNormalModeInit(void)
{
	SystemClockStatus clockStatus = SYS_CLOCK_OK;
	/*---------------------------------------------------------------------------
	Set up the Oscillator, PLL, CPU and Peripheral clocks for normal operation.
	---------------------------------------------------------------------------*/
	
	McuClkConfig mcuClocks;
	/* Set the output frequency of the MainOSC by setting the desired Amplification Gain */
	mcuClocks.mainOscGain = MAINOSC_16MHZ;
	
	/* Set the PLLn Source Oscillator */
	mcuClocks.pllConfig.sourceOsc = PLLN_SOURCE_MAINOSC;
	
	/* Set the PPLLCLK Source Oscillator to yield PPLL1OUT frequency = 80MHz*/
	mcuClocks.pllConfig.ppllSourceClk = PPLLCLK_SOURCE_PPLLOUT;
	
	/* Set the CPU Clock to yield a CPU Clock Frequency = 160MHz */
	/* Set the CPLL0OUT Frequency = 240MHz */
	#if 0
	mcuClocks.pllConfig.cpllOutDiv = CPLLOUT_DIVIDER_3;
	#else
	mcuClocks.pllConfig.cpllOutDiv = CPLLOUT_DIVIDER_4;
	#endif
	/* Set the CPU Clock Divider of 1 */
	mcuClocks.pllConfig.cpuClkDiv = CPU_CLK_DIVIDER_1;
	
	/* Set the CPU Source Clock */
	mcuClocks.pllConfig.cpuSourceClk = CPU_CLK_SOURCE_CPLL1OUT;



	/* Set the ADCA0 Clock at PPLL1OUT frequency*/
	mcuClocks.pClkConfig.adca0Config.mcuAdca0ClkisUsed = (_Bool)ONE;
	mcuClocks.pClkConfig.adca0Config.sourceClk = ADCA0_CLK_SOURCE_PPLLCLK2;
	
	mcuClocks.pClkConfig.adca0Config.clkDiv = ADCA0_CLK_DIVIDER_2;

	/* Set the ADCA1 Clock at PPLL1OUT/2 frequency*/
	
/*	mcuClocks.pClkConfig.adca1Config.mcuAdca1ClkisUsed = (_Bool) ONE;
 - 	
 - 	mcuClocks.pClkConfig.adca1Config.sourceClk =  ADCA1_CLK_SOURCE_MAINOSC;
 - 	
 - 	mcuClocks.pClkConfig.adca1Config.clkDiv = ADCA1_CLK_DIVIDER_2;*/

	/* Set the Peripheral1 Source Clock = PPLLCLK*/
	mcuClocks.pClkConfig.peri1Config.mcuPeri1ClkisUsed =(_Bool) ONE;
	mcuClocks.pClkConfig.peri1Config.sourceClk = PERI1_CLK_SOURCE_PPLLCLK;
	
	/* Set the Peripheral2 Source Clock = PPLLCLK2*/
	mcuClocks.pClkConfig.peri2Config.mcuPeri2ClkisUsed = (_Bool)ONE;
	mcuClocks.pClkConfig.peri2Config.sourceClk = PERI2_CLK_SOURCE_PPLLCLK2;
	
	/* Set the CAN Clock*/
	mcuClocks.pClkConfig.canConfig.mcuCanClkisUsed =(_Bool) ONE;
	mcuClocks.pClkConfig.canConfig.sourceClk = RSCAN_CLK_SOURCE_PPLLCLK;
	
	mcuClocks.pClkConfig.canConfig.clkDiv = RSCANOSC_CLK_SOURCE_MAINOSC;

	/* Set the CSI Clock*/
	mcuClocks.pClkConfig.csiConfig.mcuCsiClkisUsed =  (_Bool)ONE;
	mcuClocks.pClkConfig.csiConfig.sourceClk = CSI_CLK_SOURCE_HSOSC;
	
	/*Set the I2C Clock*/
	mcuClocks.pClkConfig.i2cConfig.mcuI2cClkisUsed = (_Bool)ONE;
	
	mcuClocks.pClkConfig.i2cConfig.sourceClk = I2C_CLK_SOURCE_PPLLCLK2;
	
	/*Set the UART Clock*/

	mcuClocks.pClkConfig.UARTConfig.mcuUARTClkisUsed = (_Bool)ONE;
	mcuClocks.pClkConfig.UARTConfig.sourceClk = RSUART_CLK_SOURCE_PPLLCLK2;
	mcuClocks.pClkConfig.UARTConfig.clkDiv = RSUART_CLK_DIVIDER_1;
	
	/*---------------------------------------------------------------------------
	Initialize the Oscillator, PLL, CPU and Peripheral clocks for normal operation.
	---------------------------------------------------------------------------*/
	clockStatus = (SystemClockStatus)McuClockInit (&mcuClocks);
	
	
	if (clockStatus == SYS_CLOCK_OK)
	{
		
		/* 
		�� Storing assigned clock values to the strcuture for the clock management
		*/

		/*assign 16 Mhz to MAIN osc*/
		freqUsing.MainOscFrequency 	= SET_FREQUENCY_16MHz ;
		/*assign 8 Mhz to Hs Osc*/
		freqUsing.HSOscFrequency   	= SET_FREQUENCY_8MHz ;
		/*assign 240 khz to Ls Osc*/
		freqUsing.LSOscFrequency 	= SET_FREQUENCY_240KHz ;
		/*assign 80 Mhz to PLLO*/
		//freqUsing.PLL0Frequency 	= SET_FREQUENCY_80MHz ;
		/*assign 80 Mhz to PLL1*/
		freqUsing.PLL1Frequency 	= SET_FREQUENCY_80MHz ;
		/*assign 80 Mhz to PPLL*/
		freqUsing.PPLLFrequency 	= SET_FREQUENCY_80MHz ;
		/*assign 160 Mhz to CPLL0*/
		//freqUsing.CPLL0Frequency	= SET_FREQUENCY_160MHz;
		freqUsing.CPLL0Frequency	= SET_FREQUENCY_120MHz;
		/*assign 60khz to OStimer*/
		freqUsing.OsTimerFrequency	= SET_FREQUENCY_60KHz;
		
	}
	else
	{
		/*ERROR case*/
		clockStatus = SYS_CLOCK_FAIL;
	}
	
	return clockStatus;
}/*--------------------------- End ClockNormalModeInit() -----------------------*/

/*-----------------------------------------------------------------------------
** Function: ClockReducedModeInit()
**
** Description:
** Initialize clocks based HSOSC, Main Osc wthout PLL's and assigned to peripherals 
** as per SRS.
**
** Arguments:
** void: N/A.
**
** Return values:
** retruns clock ok or fail.
**---------------------------------------------------------------------------*/
static SystemClockStatus ClockReducedModeInit(void)
{
	/*Initializing the clockStatus as uninitialized */
	SystemClockStatus clockStatus = SYS_CLOCK_OK;
	/*---------------------------------------------------------------------------
	Set up the Oscillator, PLL, CPU and Peripheral clocks for normal operation.
	---------------------------------------------------------------------------*/
	
	McuClkConfig mcuClocks;
	/* Set the output frequency of the MainOSC by setting the desired Amplification Gain */
	mcuClocks.mainOscGain = MAINOSC_16MHZ;
	
	/* Set the PLLn Source Oscillator */
	mcuClocks.pllConfig.sourceOsc = PLLN_SOURCE_INACTIVE;
	
	/* Set the PPLLCLK Source Oscillator to yield PPLL1OUT frequency = 16MHz*/
	mcuClocks.pllConfig.ppllSourceClk = PPLLCLK_SOURCE_MAINOSC;
	
	/* Set the CPU Clock Divider of 1 */
	mcuClocks.pllConfig.cpuClkDiv = CPU_CLK_DIVIDER_1;
	
	/* Set the CPU Source Clock */
	mcuClocks.pllConfig.cpuSourceClk = CPU_CLK_SOURCE_MAINOSC;


	/* Set the ADCA0 Clock at PPLL1OUT frequency*/
	mcuClocks.pClkConfig.adca0Config.mcuAdca0ClkisUsed = (_Bool)ONE;
	mcuClocks.pClkConfig.adca0Config.sourceClk = ADCA0_CLK_SOURCE_MAINOSC;
	
	mcuClocks.pClkConfig.adca0Config.clkDiv = ADCA0_CLK_DIVIDER_2;

	/* Set the ADCA1 Clock at PPLL1OUT/2 frequency*/
	
/*	mcuClocks.pClkConfig.adca1Config.mcuAdca1ClkisUsed =(_Bool)ZERO;
 - 	
 - 	mcuClocks.pClkConfig.adca1Config.sourceClk =  ADCA1_CLK_SOURCE_MAINOSC;
 - 	
 - 	mcuClocks.pClkConfig.adca1Config.clkDiv = ADCA1_CLK_DIVIDER_2;*/

	/* Set the Peripheral1 Source Clock = PPLLCLK*/
	mcuClocks.pClkConfig.peri1Config.mcuPeri1ClkisUsed =(_Bool) ONE;
	mcuClocks.pClkConfig.peri1Config.sourceClk = PERI1_CLK_SOURCE_PPLLCLK;
	
	/* Set the Peripheral2 Source Clock = PPLLCLK2*/
	mcuClocks.pClkConfig.peri2Config.mcuPeri2ClkisUsed =(_Bool) ONE;
	mcuClocks.pClkConfig.peri2Config.sourceClk = PERI2_CLK_SOURCE_PPLLCLK2;
	
	/* Set the CAN Clock*/
	mcuClocks.pClkConfig.canConfig.mcuCanClkisUsed = (_Bool)ONE;
	mcuClocks.pClkConfig.canConfig.sourceClk = RSCAN_CLK_SOURCE_MAINOSC;
	
	mcuClocks.pClkConfig.canConfig.clkDiv = RSCANOSC_CLK_SOURCE_MAINOSC;

	/* Set the CSI Clock*/
	mcuClocks.pClkConfig.csiConfig.mcuCsiClkisUsed = (_Bool) ONE;
	mcuClocks.pClkConfig.csiConfig.sourceClk = CSI_CLK_SOURCE_MAINOSC;
	
	/*Set the I2C Clock*/
	mcuClocks.pClkConfig.i2cConfig.mcuI2cClkisUsed = (_Bool)ONE;
	
	mcuClocks.pClkConfig.i2cConfig.sourceClk = I2C_CLK_SOURCE_PPLLCLK2;
	
	
	/*---------------------------------------------------------------------------
	Initialize the Oscillator, PLL, CPU and Peripheral clocks for reduced mode .
	---------------------------------------------------------------------------*/
	clockStatus = (SystemClockStatus)McuClockInit (&mcuClocks);
	
	/*validate clock status*/
	if (clockStatus == SYS_CLOCK_OK)//misra 2.1 :vio- that its always true but it won't
	{
	
		/*assign 16 Mhz to MAIN osc*/
		freqUsing.MainOscFrequency 	= SET_FREQUENCY_16MHz ;
		/*assign 8 Mhz to HSOsc*/
		freqUsing.HSOscFrequency   	= SET_FREQUENCY_8MHz ;
		/*assign 240 khz to lowspeed osc*/
		freqUsing.LSOscFrequency 	= SET_FREQUENCY_240KHz ;
		/*assign 16 Mhz to PPLLFrequency*/
		freqUsing.PPLLFrequency 	= SET_FREQUENCY_16MHz ;
		/*assign 16 Mhz to CPLL0Frequency*/
		freqUsing.CPLL0Frequency	= SET_FREQUENCY_16MHz;
		/*assign 60khz to ostimer*/
		freqUsing.OsTimerFrequency	= SET_FREQUENCY_60KHz;
	}
	else
	{
		/*return fail condition*/
		clockStatus = SYS_CLOCK_FAIL;
	}
	 
	 
	return clockStatus;
}/*--------------------------- End ClockReducedModeInit() -----------------------*/

  /*-----------------------------------------------------------------------------
** Function:SystemClockModeHandler()
**
** Description:
** 	This function will validates the flags of SystemResetFlag structure and 
** decides the mode of operation for clock which will be used to initialize the peripherals/modules.
**
** Arguments:
** void: N/A.
**
** Return values:SystemClockMode
** 		->STOP_OPERATION
		->REDUCED_MODE
		->NORMAL_MODE
**---------------------------------------------------------------------------*/
 //SystemClockMode resetReturn = NORMAL_MODE;
SystemClockMode SystemClockModeHandler(void)
{
	/*Initializing the resetReturn as NORMAL_MODE */
	    SystemClockMode resetReturn = NORMAL_MODE;
	    
	     /*if main osc and hsosc tried max times then STOP the operation*/

	     if((Clma1ResetCount == CLMA_MAX_RETRY_COUNT)||(( Clma0ResetCount == CLMA_MAX_RETRY_COUNT))) 	    
	     {
		   
			    /*don't proceed further*/
			resetReturn = STOP_OPERATION;
		 
		    
	    }
	     if(resetReturn != STOP_OPERATION)
	     {
		     /*if Main OSC and Hsosc works but PLL fails*/
/*		    if (Clma2ResetCount >= CLMA_MAX_RETRY_COUNT)
 - 		    {
 - 				    @/@*$do limited actions$*@/@
 - 			    	resetReturn = REDUCED_MODE;
 - 		    }
 - 		    else
 - 		    {
 - 			    @/@*$initialize every clock $*@/@
 - 			    resetReturn = NORMAL_MODE;
 - 			    
 - 		    }*/
		     resetReturn = NORMAL_MODE;//Need to change because of temporary compilation sake
	     }
	    
	  return resetReturn;
}/*--------------------------- End SystemClockModeHandler() -----------------------------*/

/*--------------------------- End SystemClock.c -----------------------*/
