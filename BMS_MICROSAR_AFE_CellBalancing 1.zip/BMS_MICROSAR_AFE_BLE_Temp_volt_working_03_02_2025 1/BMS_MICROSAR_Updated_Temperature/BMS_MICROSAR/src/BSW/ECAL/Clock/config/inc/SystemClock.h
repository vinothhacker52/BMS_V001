/*-----------------------------------------------------------------------------
**                            ï¿½ 2025 Ashok Leyland
** File: SystemClock.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for Clock Module in ECUAL .
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 - V1.5	:  Not integrated with MCAL
 */
 
#ifndef SYSTEM_CLOCK_H
#define SYSTEM_CLOCK_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/

#include "SystemCommonIncludes.h"
#include "retention.h"
#include "SystemClma.h"
#include "SystemReset.h"
#include "SystemGpio.h"
#include "McuClock.h"
//#include "McuTaub1Ch8.h"
//#include "McuTaub1Ch9.h"
//#include "McuTaub1Ch10.h"
//#include "McuTaub1Ch12.h"
//#include "McuTauj3Ch1.h"
//#include "McuTauj3Ch2.h"
//#include "McuTaubPrivate.h"

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

#define MAX_CLK_ACTIVATION_RETRY_COUNT 		(uint8_t)3U
/*OSC status selection*/
typedef enum SYSTEM_MAIN_OSC_STATUS
{
  SYSTEM_MAIN_OSC_STATUS_OK   	= 0,
  SYSTEM_MAIN_OSC_STATUS_FAIL 	= 1
} SYSTEM_MAINOSCStatus;

typedef enum SYSTEM_CPU_STATUS
{
  SYSTEM_CPU_NOT_ACTIVE = 0,
  SYSTEM_CPU_ACTIVE= 1
}SystemCpuStatus;


typedef enum {
  INACTIVE = 0,
  ACTIVE 
 
}ClockStatus;
 /*clock status*/
typedef enum SYS_CLOCK_STATUS
{
	SYS_CLOCK_OK   		= 0,
	SYS_CLOCK_FAIL		= 1, 
	
	
}SystemClockStatus;

typedef enum SYS_CLOCK_INIT_STATUS
{
	SYS_CLOCK_INIT_OK   		= 0,
	SYS_CLOCK_INIT_FAIL		= 1,
	NORMAL_CLOCK_INIT_SUCCESS	= 2,
	REDUCED_CLOCK_INIT_SUCCESS	= 3,
	NORMAL_CLOCK_INIT_FAIL	= 4,
	REDUCED_CLOCK_INIT_FAIL	= 5,
	
	
}SystemClockInitStatus;

/*for clock reusablility*/

typedef struct
{
   	uint32_t MainOscFrequency;
	uint32_t HSOscFrequency;
	uint32_t LSOscFrequency;
	//uint32_t PLL0Frequency;
	uint32_t PLL1Frequency;
	uint32_t PPLLFrequency;
	uint32_t CPLL0Frequency;
	uint32_t OsTimerFrequency;
	/*add every module clock here*/ 
	
}ClockFreq;

typedef enum
{
	NORMAL_MODE	 = 0,
	REDUCED_MODE 	 = 1,
	STOP_OPERATION 	 = 2,
	DEFAULT_MODE 	 = 3

}SystemClockMode;

  /*-----------------------------------------------------------------------------
  ** Exported Global Variable Declarations
  **---------------------------------------------------------------------------*/
 
extern ClockFreq freqUsing;
extern SystemClockStatus systemClockStatus;
extern SystemClockMode resetCause;

  /*-----------------------------------------------------------------------------
  ** Exported Function Declarations
  **---------------------------------------------------------------------------*/
extern SystemClockInitStatus SystemClockInit(void);
extern SystemClockMode SystemClockModeHandler(void);

  #endif // SYSTEM_CLOCK_H

    /*--------------------------- End SystemClock.h -----------------------------*/

