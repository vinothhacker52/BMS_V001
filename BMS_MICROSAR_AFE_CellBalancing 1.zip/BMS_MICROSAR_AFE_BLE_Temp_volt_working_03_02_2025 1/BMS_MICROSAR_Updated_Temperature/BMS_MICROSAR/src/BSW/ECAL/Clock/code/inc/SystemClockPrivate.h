/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemClockPrivate.h
**
** Description:
** General Header file for System CLMA
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_CLOCK_PRIVATE_H
#define SYSTEM_CLOCK_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
#define CLMA_MAX_RETRY_COUNT		 5

#define SET_FREQUENCY_40KHz 	40000

#define SET_FREQUENCY_60KHz 	60000

#define SET_FREQUENCY_240KHz 	240000

#define SET_FREQUENCY_8MHz      8000000

#define SET_FREQUENCY_16MHz     16000000

#define SET_FREQUENCY_80MHz     80000000

#define SET_FREQUENCY_120MHz    120000000

#define SET_FREQUENCY_160MHz    160000000

#define SET_FREQUENCY_240MHz    240000000



#endif /* SYSTEM_CLOCK_PRIVATE_H */
