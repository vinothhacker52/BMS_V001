/*-----------------------------------------------------------------------------
**                            
** File: SystemAdc.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for ADC Module in ECUAL.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 * V1.0 	:  10-June-2025  : Initial Version
 */
#ifndef SYSTEM_ADC_H
#define SYSTEM_ADC_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "McuAdc.h"
#include "SystemCommonIncludes.h"
#include "string.h"
#include "SystemAdcPrivate.h"
/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/


/*to check adc start status*/
typedef enum 
{
    ADC_UN_INITIALIZED=0,
    ADC_INITIALIZED=1,
    ADC_STARTED=2

}SystemAdcStartStatus;

/*to get the channel input*/
typedef enum 
{
	ADC_CH0 =0,
	ADC_CH1 =1,
	ADC_CH2 =2,
	ADC_CH3 =3,
	ADC_CH4 =4,
	ADC_CH5 =5,
	ADC_CH6 =6,
	ADC_CH7 =7,
	ADC_CH8 =8,
	ADC_CH9 =9,
	ADC_CH10 =10
}SystemAdcChannel;
/*to get ADC result voltage*/
typedef struct 
{
    float battVoltSens;//buffers to store the adc voltage result
       
}SystemAdcValues;



/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/

 extern void SystemAdc0Init(void);
 extern SystemAdcStartStatus SystemAdc0Start(void);
 extern float SystemGetBoardVoltage(SystemAdcChannel channel) ;

#endif // SYSTEM_ADC_H

/*--------------------------- End SystemAdc.h -----------------------------*/
