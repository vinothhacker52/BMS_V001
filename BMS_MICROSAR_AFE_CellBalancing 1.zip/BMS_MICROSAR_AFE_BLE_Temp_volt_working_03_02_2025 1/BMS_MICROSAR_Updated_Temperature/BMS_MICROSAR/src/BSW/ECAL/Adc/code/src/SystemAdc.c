/*-----------------------------------------------------------------------------
**                            
** File: SystemAdc.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of ADC module in ECUAL.
**---------------------------------------------------------------------------*/

/*****************************************************************************************************************************************
**                                              Revision Control History                                                                **
*****************************************************************************************************************************************/
/*
 				
 */
/*-----------------------------------------------------------------------------
** Includes.
**---------------------------------------------------------------------------*/
#include "SystemAdc.h"
#include "SystemAdcPrivate.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/



/*-----------------------------------------------------------------------------
** Exported Global Variable Definitions
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
** Local Global Variable Definitions
**---------------------------------------------------------------------------*/
/*Static variable to store the ADC initialization status. used to check if ADC is initialized before usage*/
static SystemAdcStartStatus IsAdcInitialized = ADC_UN_INITIALIZED;

/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/


// <Add any functions whose "scope" is limited to this module here>

/*-----------------------------------------------------------------------------
** Function: SystemAdc0Init()
**
** Description:
** This function initializes ADC 0.
**
** Arguments: None
**
** Return values: 
** N/A
**---------------------------------------------------------------------------*/
void SystemAdc0Init(void)
{
    /*creating instance for McuAdcConfig to configure the sampling time and bit resolution */
    McuAdcConfig adcConfiguration;

    /*intitialising MCAL structure*/
    /*sampling time*/
    /*
     -> the number of system or ADC clock cycles the ADC will spend sampling the input signal before starting the conversion.
     ->setting 24 cycles
     */
    adcConfiguration.samplingTime =  ADC_SAMPLING_24_CYCLES;
    /*Select resolution*/
    /*
     ->setting 12 bit mode
     */
    adcConfiguration.bitSelection = ADC_12_BIT_MODE;

    /*Invoke MCAL API to initialize the ADC with desired sampling time and resolution*/
    McuAdc0Init(&adcConfiguration);

    /*Set the ADC initialization status flag to indicate that ADC has been successfully initialized */
    IsAdcInitialized = ADC_INITIALIZED;

}/*--------------------------- End SystemAdc0Init () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: SystemAdc0Start()
**
** Description:
** This function starts ADC 0.
**
** Arguments: None
**
** Return values:
** adcStatus -  ADC_STARTED
ADC_INITIALIZED
ADC_UN_INITIALIZED
**
**---------------------------------------------------------------------------*/
SystemAdcStartStatus SystemAdc0Start(void)
{
    /*Default decleration*/
    SystemAdcStartStatus adcStatus = ADC_UN_INITIALIZED;

    /*validating if ADC start is called without ADC intialisation*/
    if(IsAdcInitialized == ADC_INITIALIZED)
    {
	/*Invoke MCAL API to start ADC*/
	McuAdc0Sg1Start();

	/*Set status flag - adc started*/
        adcStatus = ADC_STARTED;
    }
    else
    {
	/*Set ADC status flag - adc not initialized*/
	adcStatus = ADC_UN_INITIALIZED;

    }
    /*returns ADC status*/
    return adcStatus;

}/*--------------------------- End SystemAdc0Start () -----------------------*/


/*-----------------------------------------------------------------------------
** Function: SystemAdc0GetResult()
**
** Description:
** This function is to get the ADC Voltage based on the selective channel from the upper layer. stores the result in an address. 
**
** Arguments:pointer to board voltage variable
** *PsystemAdcValues :  Address of the buffer variable where ASW read the result ADC voltage
** 
** channel :  channel of the ADC of Int type
** ADC_CH1
** ADC_CH2
** Return values:
** NA
**---------------------------------------------------------------------------*/
 uint16_t buffer[TEN];
float SystemGetBoardVoltage(SystemAdcChannel channel) 
{
    /* Buffer to store ADC result */
    //uint16_t buffer[TEN];
    McuAdcStatus adcStatus = ADC_NOT_OK; // Default initialization
    float voltage = INVALID; // Default to invalid voltage

    /* Get ADC result */
    adcStatus = McuAdc0Sg1GetResult(buffer, 10);

    /* Check ADC status */
    if (adcStatus == ADC_OK) 
    {
	/*convertion to engg units
	 -> where,
	 ADC = ADC Raw Value (in count)
	 ADC Resolution = 12-bit ADC, ADC Resolution = 2^12 - 1 = 4095
	 ADC Reference Voltage = Maximum voltage the ADC can measure (V)
	 ADC_VOLTAGE_FACTOR = scaling factor for the customised board
	 */
	if (channel<=ADC_CH10)
	{
/*	    case ADC_CH0:
 - 	    case ADC_CH1:
 - 	    case ADC_CH2:
 - 	    case ADC_CH3:
 -    	    case ADC_CH4:
 - 	    case ADC_CH5:
 - 	    case ADC_CH6:
 - 	    case ADC_CH7:
 - 	    case ADC_CH8:
 - 	    case ADC_CH9:
 - 	    case ADC_CH10:	    */
		voltage = ((float)buffer[channel] / TWELVE_BIT_RESOLUTION) * ADC_REFERENCE_VOLTAGE * ADC_VOLTAGE_FACTOR;//formulea (refer datasheet)
	}

    }

    else 
    {
        /* Handle the error case*/
        voltage  = INVALID;// Return an invalid voltage value(-1.0)V for error case;
    }



    return voltage;
}
/*--------------------------- End SystemAdc.c -----------------------------*/
