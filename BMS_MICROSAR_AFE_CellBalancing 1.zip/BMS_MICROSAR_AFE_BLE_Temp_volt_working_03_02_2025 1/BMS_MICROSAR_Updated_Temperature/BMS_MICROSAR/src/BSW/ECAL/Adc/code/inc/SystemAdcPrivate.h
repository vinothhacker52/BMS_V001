/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemAdcPrivate.h
**
** Description:
** General Header file for System Gpio
**---------------------------------------------------------------------------*/
#ifndef SYSTEM_ADC_PRIVATE_H
#define SYSTEM_ADC_PRIVATE_H

/*-----------------------------------------------------------------------------
** Global Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/
// Define constants
#define TWELVE_BIT_RESOLUTION 4095.0f
#define TEN_BIT_RESOLUTION 1024.0f
#define ADC_VOLTAGE_FACTOR 1.0f//7.911f
#define ADC_REFERENCE_VOLTAGE 5.0f

#endif /* SYSTEM_ADC_PRIVATE_H */
