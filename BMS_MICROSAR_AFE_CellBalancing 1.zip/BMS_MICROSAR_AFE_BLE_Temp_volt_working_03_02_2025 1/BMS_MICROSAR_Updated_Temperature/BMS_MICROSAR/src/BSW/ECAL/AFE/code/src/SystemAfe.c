/*-----------------------------------------------------------------------------
**                           @ 2025 Ashokleyland
** File:SystemUart.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of UART Transmit and Receive
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                               **
*****************************************************************************************************************************************/
/*
 * V1.0 	:  25-Jun-2025  : Initial Version
 * v1.1     :  21-Jul-2025  : Version Integrated with Temporary CAN drivers
 */
/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemAfe.h"
#include "SystemCan.h"
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

extern McuUartReadResponse pReadRspnsePtr;
extern void delay_ms(uint16_t ms);
extern void delay100uS(uint16_t);
extern uint32_t milliTick;
McuUartReadMsg pRdMsgPtr = {0};
SystemUartAfeMeasRaw pRawMeasurements;
SystemUartAfeMeas pMeasurements;
uint8_t pcvm0_3[8] = {0};
uint8_t pcvm4_7[8] = {0};
uint8_t pcvm8_11[8] = {0};
uint8_t pcvm11_15[8] = {0};
uint8_t pcvm16_17[8] = {0};  
/*-----------------------------------------------------------------------------
** Function: SystemUartInit
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartInit(void){
    McuUart0Init();
    McuUart0Start();
}
/*-----------------------------------------------------------------------------
** Function: SystemUartStop
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartStop(void){
    McuUart0Stop();
}
/*-----------------------------------------------------------------------------
** Function: SystemAfeInit
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemAfeInit(void){

    uint8_t wakeUp[2];
    uint8_t status = 0;
    wakeUp[0] = 0xAA;
    wakeUp[1] = 0xAA;

    McuUart0Tx(&wakeUp, 2);
    delay100uS(20);
    SystemUartSndWrMsg(0x80, 0xC0, 0x8001);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x03, 0x0050);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x0F, 0xFFFF);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x01, 0xFFFF);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x02, 0xC000);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x91, 0xFFFF);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xB0, 0x007F);//WD_DOG
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x04, 0x4771);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x05, 0x99EB);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x06, 0x1CD4);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x09, 0x0ACA);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x0A, 0x152E);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x21, 0x051F);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0xBF, 0x22, 0x02D9);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xB0, 0x007F);//WD_DOG
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x3A, 0xE021);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x06, 0x1C00);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x3B, 0x0001);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x3A, 0xE021);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x01, 0xFFFF);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x92, 0xFFFF);
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xB0, 0x007F);//WD_DOG
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x01, 0xFFFF);
    status = SystemUartRdRply();

    //Temperature
    SystemUartSndWrMsg(0x81, 0x08, 0x8000); //EXT_TEMP_CFG_2
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x06, 0x1C00); //EXT_TEMP_CFG_0
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0x07, 0x03FF); //EXT_TEMP_CFG_1
    status = SystemUartRdRply();


    //Cell Balancing 
    SystemUartSndWrMsg(0x81, 0xE6, 0xFFFE); //BAL_CFG_0 cell 3 to 18
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xE7, 0xC000); //BAL_CFG_1 cell 0 and cell 1
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xE7, 0x0002); //BAL_CFG_1 switch ON  all cells
    status = SystemUartRdRply();
    SystemUartSndWrMsg(0x81, 0xE7, 0x0004); //BAL_CFG_1 switch OFF  all cells
    status = SystemUartRdRply();
    

    
}

/*-----------------------------------------------------------------------------
** Function: SystemUartRdPcvm
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartRdVoltage(void){

    //PCVM
    SystemUartSndWrMsg(0x81, 0xB0, 0x007F);//WD_DOG 
    SystemUartSndWrMsg(0x81, 0x3A, 0xE021); //PCVM Start
    
    for(uint8_t cellNo = 0; cellNo < CELL_COUNT; cellNo++){
	SystemUartSndRdMsg(readPcvm[cellNo].id, readPcvm[cellNo].address);
	pRawMeasurements.PCVM[cellNo] = SystemUartRdResponse(readPcvm[cellNo].id, readPcvm[cellNo].address);
    }
    SystemUartSndWrMsg(0x81, 0x3A, 0x0E21);
    SystemUartSndRdMsg(0x1, BVM_ADDR);
    pRawMeasurements.BVM = SystemUartRdResponse(0x1, BVM_ADDR);
}
/*-----------------------------------------------------------------------------
** Function: SystemUartRdTemp
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartRdTemp(void){

    SystemUartSndWrMsg(0x81, 0xB0, 0x007F);//WD_DOG 
    SystemUartSndWrMsg(0x81, 0x0D, 0x0081); //RR_CFG_1

    for(uint8_t tempNo = 0; tempNo < 8; tempNo++){
	SystemUartSndRdMsg(readTemp[tempNo].id, readTemp[tempNo].address);
	pRawMeasurements.extTemp[tempNo] = SystemUartRdResponse(readTemp[tempNo].id, readTemp[tempNo].address);
	pRawMeasurements.extTemp[tempNo] &= 0x3FF;
    }

    for(uint8_t tempNo = 0; tempNo < 8; tempNo++){
	float scale = (FSR_TMP_V * (1 << (7 - tempNo))) / (1024.0f * 640e-6f);
	float r_ntc = (pRawMeasurements.extTemp[tempNo] * scale) - R_TMP_OHM;
	pMeasurements.extTemp[tempNo] = r_ntc ;
    }
}
/*-----------------------------------------------------------------------------
** Function: SystemUartRdAfe
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartRdAfe(void){

    SystemUartSndRdMsg(0x1, CUSTOMER_ID_0_ADDR);
    pRawMeasurements.cusId0 = SystemUartRdResponse(0x1, CUSTOMER_ID_0_ADDR);

    SystemUartRdVoltage();   

    SystemUartSndRdMsg(0x1, INT_TEMP_0_ADDR);
    pRawMeasurements.intTemp0 = SystemUartRdResponse(0x1, INT_TEMP_0_ADDR);

    SystemUartSndRdMsg(0x1, INT_TEMP_1_ADDR);
    pRawMeasurements.intTemp1 = SystemUartRdResponse(0x1, INT_TEMP_1_ADDR);

    SystemUartSndRdMsg(0x1, GEN_DIAG_ADDR);
    pRawMeasurements.genDiag = SystemUartRdResponse(0x1, GEN_DIAG_ADDR);

    SystemUartSndRdMsg(0x1, SCVM_HIGH_ADDR);
    pRawMeasurements.scvmHigh = SystemUartRdResponse(0x1, SCVM_HIGH_ADDR);

    SystemUartSndRdMsg(0x1, SCVM_LOW_ADDR);
    pRawMeasurements.scvmLow = SystemUartRdResponse(0x1, SCVM_LOW_ADDR);

}
/*-----------------------------------------------------------------------------
** Function: SystemUartAfeCalc
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartAfeCalc(void){

    pMeasurements.cusId0  = pRawMeasurements.cusId0;

    for(uint8_t cellNo = 0; cellNo < CELL_COUNT; cellNo++)
	pMeasurements.PCVM[cellNo] = (float) PCVM_FACTOR * pRawMeasurements.PCVM[cellNo];
    
    pMeasurements.BVM = (float) BVM_FACTOR * pRawMeasurements.BVM;
    
    pMeasurements.intTemp0 = (float) pRawMeasurements.intTemp0; 
    pMeasurements.intTemp1 = (float) pRawMeasurements.intTemp1;
    pMeasurements.genDiag =  pRawMeasurements.genDiag;
    pMeasurements.scvmHigh = (float) SCVM_FACTOR * (pRawMeasurements.scvmHigh & SCVM_MASK);
    pMeasurements.scvmLow = (float) SCVM_FACTOR * (pRawMeasurements.scvmLow & SCVM_MASK );

}
/*-----------------------------------------------------------------------------
** Function: SystemAfeCanMsgOut
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemAfeCanMsgOut(void){
    
switch (milliTick % 50)
{
    case 0:   SystemCanSendData(MCU_CHANNEL_0, MCU_CAN_STANDARD, 0x100, 8, &pcvm0_3); break;
    case 1:   SystemCanSendData(MCU_CHANNEL_0, MCU_CAN_STANDARD, 0x101, 8, &pcvm4_7); break;
    case 2:  SystemCanSendData(MCU_CHANNEL_0, MCU_CAN_STANDARD, 0x102, 8, &pcvm8_11); break;
    case 3:  SystemCanSendData(MCU_CHANNEL_0, MCU_CAN_STANDARD, 0x103, 8, &pcvm11_15); break;
    case 4:  SystemCanSendData(MCU_CHANNEL_0, MCU_CAN_STANDARD, 0x104, 8, &pcvm16_17); break;
    default:
        break;
}
    
}
/*-----------------------------------------------------------------------------
** Function: SystemUartSendVlt
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartPcvmCanPacking(void){
   
    uint32_t  primaryCelln = 0;
    
    primaryCelln =pMeasurements.PCVM[0]* 1000;
    pcvm0_3[0] = (uint8_t)( primaryCelln >> 0);
    pcvm0_3[1] = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[1]* 1000;
    pcvm0_3[2]  = (uint8_t)( primaryCelln >> 0);
    pcvm0_3[3]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
	
    primaryCelln  = pMeasurements.PCVM[2]* 1000;
    pcvm0_3[4]  = (uint8_t)( primaryCelln >> 0);
    pcvm0_3[5]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
	
    primaryCelln  = pMeasurements.PCVM[3]* 1000;
    pcvm0_3[6]  = (uint8_t)( primaryCelln >> 0);
    pcvm0_3[7]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
	
    primaryCelln  =  pMeasurements.PCVM[4]* 1000;
    pcvm4_7[0]  = (uint8_t)( primaryCelln >> 0);
    pcvm4_7[1]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
	
    primaryCelln  =  pMeasurements.PCVM[5]* 1000;
    pcvm4_7[2]  = (uint8_t)( primaryCelln >> 0);
    pcvm4_7[3]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[6]* 1000;
    pcvm4_7[4]  = (uint8_t)( primaryCelln >> 0);
    pcvm4_7[5]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[7]* 1000;
    pcvm4_7[6]  = (uint8_t)( primaryCelln >> 0);
    pcvm4_7[7]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[8]* 1000;
    pcvm8_11[0]  = (uint8_t)( primaryCelln >> 0);
    pcvm8_11[1]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[9]* 1000;
    pcvm8_11[2]  = (uint8_t)( primaryCelln >> 0);
    pcvm8_11[3]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[10]* 1000;
    pcvm8_11[4]  = (uint8_t)( primaryCelln >> 0);
    pcvm8_11[5]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[11]* 1000;
    pcvm8_11[6]  = (uint8_t)( primaryCelln >> 0);
    pcvm8_11[7]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[12]* 1000;
    pcvm11_15[0]  = (uint8_t)( primaryCelln >> 0);
    pcvm11_15[1]  = (uint8_t)( primaryCelln >> 8);

    primaryCelln  =  pMeasurements.PCVM[13]* 1000;
    pcvm11_15[2]  = (uint8_t)( primaryCelln >> 0);
    pcvm11_15[3]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[14]* 1000;
    pcvm11_15[4]  = (uint8_t)( primaryCelln >> 0);
    pcvm11_15[5]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[15]* 1000;
    pcvm11_15[6]  = (uint8_t)( primaryCelln >> 0);
    pcvm11_15[7]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[16]* 1000;
    pcvm16_17[0]  = (uint8_t)( primaryCelln >> 0);
    pcvm16_17[1]  = (uint8_t)( primaryCelln >> 8);
    primaryCelln = 0;
    
    primaryCelln  =  pMeasurements.PCVM[17]* 1000;
    pcvm16_17[2]  = (uint8_t)( primaryCelln >> 0);
    pcvm16_17[3]  = (uint8_t)( primaryCelln >> 8);
 
}

/*-----------------------------------------------------------------------------
** Function: SystemUartSndWrMsg
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartSndWrMsg(uint8_t IdFrame, uint8_t address, uint16_t data){
    uint8_t crcFrame[5] = {0};
    uint8_t SystemCrcVal;

    static McuUartWriteMsg pWriteMsgPtr;
    pWriteMsgPtr.syncData = 0x1E;
    pWriteMsgPtr.idData.idFrame = IdFrame;
    pWriteMsgPtr.address = address;
    pWriteMsgPtr.data.data16Bit = data;

    crcFrame[0] = pWriteMsgPtr.syncData;
    crcFrame[1] = pWriteMsgPtr.idData.idFrame;
    crcFrame[2] = pWriteMsgPtr.address;
    crcFrame[3] = pWriteMsgPtr.data.bytes.data2;
    crcFrame[4] = pWriteMsgPtr.data.bytes.data1;

    SystemCrcVal = SystemUartCalcCRC(&crcFrame, 5, 8);
    pWriteMsgPtr.crcData = SystemCrcVal;

    McuUart0SndWrMsg(&pWriteMsgPtr);
    delay100uS(5);
}
/*-----------------------------------------------------------------------------
** Function: SystemUartSndRdMsg
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
void SystemUartSndRdMsg(uint8_t IdFrame, uint8_t address){ 
    uint8_t crcFrame[3] = {0};
    uint8_t SystemCrcVal;
    static McuUartReadMsg pRdMsgPtr = {0};

    pRdMsgPtr.syncData = 0x1E;
    pRdMsgPtr.idData.idFrame = IdFrame;
    pRdMsgPtr.address = address;

    crcFrame[0] = 0x1E;
    crcFrame[1] = pRdMsgPtr.idData.idFrame;
    crcFrame[2] = address;

    SystemCrcVal = SystemUartCalcCRC(&crcFrame, 3, 8);
    pRdMsgPtr.crcData = SystemCrcVal;

    McuUart0SndRdMsg(&pRdMsgPtr);
    delay100uS(5);

}
/*-----------------------------------------------------------------------------
** Function: SystemUartRdRply
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
uint8_t SystemUartRdRply(void){
    uint32_t timeout = UART_RX_TIMEOUT;
    while ((UartCommonBufferSts.ReplyFrame != 1) && (timeout > 0UL))
    {
	timeout--;
    }
    UartCommonBufferSts.ReplyFrame = 0;
    return pReplyFramePtr.replayFrame;
}
/*-----------------------------------------------------------------------------
** Function: SystemUartRdResponse
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
uint16_t SystemUartRdResponse(uint8_t Id, uint8_t address){
    uint8_t crcFrame[4] = {0};
    uint8_t SystemCrcVal;

    crcFrame[0] = pReadRspnsePtr.idData.idFrame;
    crcFrame[1] = pReadRspnsePtr.address;
    crcFrame[2] = pReadRspnsePtr.data.bytes.data2;
    crcFrame[3] = pReadRspnsePtr.data.bytes.data1;

    if(UartCommonBufferSts.ReadResponse == 1){
	if((pReadRspnsePtr.idData.McuUartIdFullFrame.ID == Id) && (pReadRspnsePtr.address == address)){
	    SystemCrcVal = SystemUartCalcCRC(&crcFrame, 4, 8);
	    if(SystemCrcVal == pReadRspnsePtr.crcData)
		return pReadRspnsePtr.data.data16Bit;
	}
	UartCommonBufferSts.ReadResponse = 0;
    }

    return 0;
}
/*-----------------------------------------------------------------------------
** Function: SystemUartCalcCRC
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
uint8_t SystemUartCalcCRC(uint8_t *data, uint16_t len, uint8_t crcBits) {
    uint8_t crc = 0xFF; 
    uint8_t poly8 = 0x1D; // Polynomial for CRC-8: x^8 + x^4 + x^3 + x^2 + 1
    uint8_t poly3 = 0x03; // Example polynomial for CRC-3: x^3 + x + 1 (binary 011)

    if (crcBits == 8) {
        for (uint16_t i = 0; i < len; i++) {
            crc ^= data[i];
            for (uint8_t j = 0; j < 8; j++) {
                crc = (crc & 0x80) ? ((crc << 1) ^ poly8) : (crc << 1);
            }
        }
        return crc ^ 0xFF; // Final XOR for CRC-8
    } else if (crcBits == 3) {
        uint8_t crc3 = 0; // Initial value for CRC-3
        for (uint16_t i = 0; i < len; i++) {
            crc3 ^= data[i];
            for (uint8_t j = 0; j < 8; j++) {
                crc3 = (crc3 & 0x08) ? ((crc3 << 1) ^ poly3) : (crc3 << 1);
                crc3 &= 0x07; // Keep only 3 bits
            }
        }
        return crc3; 
    }
    return 0; 
}

/*--------------------------- End TLE9018_ReadMulti()-----------------------------*/
/*-----------------------------------------------------------------------------
** Function: SystemCellBalancing
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/

void SystemAfeCellBalancingTask(void)
{
    uint8_t thr[CELL_COUNT];
    uint8_t enableMask;
    int i;

    
    for (i = 0; i < (int)CELL_COUNT; i++)//Init all thresholds to OFF 
        thr[i] = 0;

    /* Set thresholds for cell1 & cell2 */
    thr[0] = 1;
    thr[1] = 2;  /* cell1 = 2 * BAL_CNT_TIMEBASE */
    thr[2] = 3;  /* cell2 = 3 * BAL_CNT_TIMEBASE */

    /* Enable only cell1 and cell2 */
    enableMask = 0u;
    enableMask |= (1u << 1);  // cell1 
    enableMask |= (1u << 2);  //  cell2

    SystemCellBalancingStart(0x1,BAL_TB_MIN_8, thr, enableMask);
}


/*-----------------------------------------------------------------------------
** Function: SystemCellBalancingStart
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/

uint8_t cellThr[CELL_COUNT];
uint16_t SystemCellBalancingStart(uint8_t IdFrame,uint8_t timebaseCode,uint8_t *pCellThr, uint8_t enableMask) {
    int rc;
    // uint32_t enable_mask;

    
    rc = SystemCellBalanSetTimeBase(0x1, timebaseCode);
    if (rc != 0) return rc;

    rc = SystemCellWrtAllBalThreshold(0x1, cellThr);
    if (rc != 0) return rc;

    rc = SystemCellEnableReq(0x1, enableMask);
    if (rc != 0) return rc;

    rc = SystemCellStrBalanCount();
    if (rc != 0) return rc;

    return 0;
}


uint16_t SystemCellBalanSetTimeBase( uint8_t IdFrame, uint8_t timebaseCode)
{
    uint8_t id;
    uint16_t genNew;

    genNew &= (uint16_t)(~GENCFG_BAL_CNT_TIMEBASE_Msk);
    genNew |= (uint16_t)(((uint16_t)timebaseCode & 0x3u) << GENCFG_BAL_CNT_TIMEBASE_Pos);

    SystemUartSndWrMsg(id, GEN_CFG_ADDR, genNew);
    return 0;
}

/*-----------------------------------------------------------------------------
** Function: SystemCellWrtAllBalThreshold
**
** Description:
** This function used to initilize the uart0 
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
uint16_t SystemCellWrtAllBalThreshold(uint8_t IdFrame, uint8_t *pcellThr)
{
    uint8_t r;
    uint16_t v;
/*    for (r = 0; r < 6u; r++)
 -     {
 -         uint8_t c0 = (uint8_t)(r * 3u + 0u);
 -         uint8_t c1 = (uint8_t)(r * 3u + 1u);
 -         uint8_t c2 = (uint8_t)(r * 3u + 2u);
 - 
 -         uint16_t packed =  SystemCellBalanPack(cellThr[c0], cellThr[c1], cellThr[c2]);
 - 
 -         if (SystemUartSndWrMsg(0x1, SystemCellBalanCountConfigAdre(r), packed) != 0)
 -             return -1;
 -     }*/


    
    v = SystemCellBalanPack(cellThr[0], cellThr[1], cellThr[2]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_0_ADDR, v);

    v = SystemCellBalanPack(cellThr[3], cellThr[4], cellThr[5]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_1_ADDR, v);

    v = SystemCellBalanPack(cellThr[6], cellThr[7], cellThr[8]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_2_ADDR, v);

    v = SystemCellBalanPack(cellThr[9], cellThr[10], cellThr[11]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_3_ADDR, v);

    v = SystemCellBalanPack(cellThr[12], cellThr[13], cellThr[14]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_4_ADDR, v);

    v = SystemCellBalanPack(cellThr[15], cellThr[16], cellThr[17]);
    SystemUartSndWrMsg(0x1, BAL_CNT_CFG_5_ADDR, v);

    return 0;

}
/*@/@*$-----------------------------------------------------------------------------
 - ** Function: SystemCellBalanCountConfigAdre
 - **
 - ** Description:
 - ** This function used to initilize the uart0 
 - **                                              
 - ** Arguments: None
 - ** Return values: None
 - ** 
 - **---------------------------------------------------------------------------$*@/@
 - uint16_t SystemCellBalanCountConfigAdre(uint8_t idx)
 - {
 -     return (uint16_t)( BAL_CNT_CFG_0_ADDR + (uint16_t)idx);
 - }*/

/*-----------------------------------------------------------------------------
** Function: SystemCellBalanPack
**
** Description:
**  * Pack THR_0/THR_1/THR_2 into one BAL_CNT_CFG_x register value
 * THR_0 [4:0], THR_1 [9:5], THR_2 [14:10]
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/
uint16_t SystemCellBalanPack(uint8_t thr0, uint8_t thr1, uint8_t thr2)
{
    uint16_t v=0;
  
    thr0 &= 0x1FU;
    thr1 &= 0X1FU;
    thr2 &= 0X1FU;

    v  = (uint16_t)((uint16_t)thr0 << 0);
    v |= (uint16_t)((uint16_t)thr1 << 5);
    v |= (uint16_t)((uint16_t)thr2 << 10);

    return v;
}


/*-----------------------------------------------------------------------------
** Function: SystemCellBalanPack
**
** Description:
**  Enable required cells in BAL_CTRL_0 / BAL_CTRL_1

** enable_mask bit meaning:
**   bit0 -> cell0, bit1 -> cell1, ... bit17 -> cell17


** Mapping:
**   BAL_CTRL_0 bit0..15 -> cells 2..17  (bit = cell-2)
**   BAL_CTRL_1 bit14 -> cell0 (ON_0), bit15 -> cell1 (ON_1)
                                            
** Arguments: None
** Return values: 0 success, <0 error
** 
**---------------------------------------------------------------------------*/
uint16_t SystemCellEnableReq(uint8_t IdFrame, uint32_t enableMask)
{
    uint16_t ctrl0 = 0u;
    uint16_t ctrl1 = 0u;

    /* Build BAL_CTRL_0 for cells 2..17 */
    uint8_t cell;
    for (cell = 2u; cell < CELL_COUNT; cell++)
    {
        if (enableMask & (1u << cell))
        {
            ctrl0 |= (uint16_t)(1u << (cell - 2u));
        }
    }

    SystemUartSndWrMsg(0x1, BAL_CTRL_0_ADDR, ctrl0);
        

    /* Read-modify-write BAL_CTRL_1 to set ON_0/ON_1 without disturbing other bits */
/*    if (dev_read_reg(node_id, REG_BAL_CTRL_1, &ctrl1) != 0)
 -         return -3;*/

    /* cell0 -> ON_0 */
    if (enableMask & (1u << 0))
        ctrl1 |= (uint16_t)BAL_CTRL1_ON_0_Msk;
    else
        ctrl1 &= (uint16_t)(~BAL_CTRL1_ON_0_Msk);

    /* cell1 -> ON_1 */
    if (enableMask & (1u << 1))
        ctrl1 |= (uint16_t)BAL_CTRL1_ON_1_Msk;
    else
        ctrl1 &= (uint16_t)(~BAL_CTRL1_ON_1_Msk);

    SystemUartSndWrMsg(0x1, BAL_CTRL_1_ADDR, ctrl1);
       

    return 0;
}

/*-----------------------------------------------------------------------------
** Function: SystemCellStrBalanCount
**
** Description:
**  * Pack THR_0/THR_1/THR_2 into one BAL_CNT_CFG_x register value
 * THR_0 [4:0], THR_1 [9:5], THR_2 [14:10]
**                                              
** Arguments: None
** Return values: None
** 
**---------------------------------------------------------------------------*/

uint16_t SystemCellStrBalanCount(void)
{
    uint16_t ctrl1;

/*    if (SystemUartSndWrMsg(0x1, BAL_CTRL_1_ADDR, ctrl1)) != 0)
 -         return -5;*/

    ctrl1 |= (uint16_t)BAL_CTRL1_START_CNT_Msk;

   SystemUartSndWrMsg(0x1, BAL_CTRL_1_ADDR, ctrl1);
      

    return 0;
}






