/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemTle9018Private.h
**
** Description:
** General Header file for System Circuit
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_TLE9018_PRIVATE_H
#define SYSTEM_TLE9018_PRIVATE_H



/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/

#define DEVICE_ID 0x2B

#define UART_WRITE_REG 1
#define UART_READ_REG 1

#define RESPONE_OK 1
#define RESPONE_NOT_OK 0

#define AFE_CONFIG  0x00C0
#define PART_CONFIG_MSB 0x0001
#define PART_CONFIG_LSB 0x0002
#define OL_OV_CFG 0x0004

#endif//SYSTEM_TLE9018_PRIVATE_H
