/*-----------------------------------------------------------------------------
**                           � 2025 Ashokleyland
** File: SystemTle9018.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for SystemUart functions
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_TLE9018_H
#define SYSTEM_TLE9018_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/

#include "McuTypedefs.h"
#include "McuUart0.h"
#include <stdbool.h>
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/


/* AFE General Macros */

#define AFE_REG_READ             0U
#define AFE_REG_WRITE            1U

#define CELL_COUNT               18U
#define THR_MAX                  31U 
#define FSR_TMP_V 2.0f
#define R_TMP_OHM 10000.0f
/* Command / Data Type Register Addresses */

#define WDOG_CNT_ADDR           0xB0
#define IF_CFG_ADDR             0xC0
#define PART_CFG_0_ADDR         0x01
#define PART_CFG_1_ADDR         0x02
#define GEN_DIAG_ADDR           0x0F
#define SCVM_CFG_0_ADDR         0x91
#define SCVM_CFG_1_ADDR         0x92
#define RR_CFG_0_ADDR           0x0C
#define FAULT_MASK_CFG_ADDR     0x0E
#define CUSTOMER_ID_0_ADDR      0xC4
#define CUSTOMER_ID_1_ADDR      0xC5
#define ICVID_ADDR              0xC2
#define OL_OV_CFG_ADDR          0x04
#define OL_UV_CFG_ADDR          0x05
#define EXT_TEMP_CFG_0_ADDR     0x06
#define EXT_TEMP_CFG_1_ADDR     0x07
#define EXT_TEMP_CFG_2_ADDR     0x08
#define INT_TEMP_CFG_ADDR       0x09
#define UC_OC_CFG_ADDR          0x0A
#define RR_CFG_1_ADDR           0x0D
#define MEAS_CTRL_ADDR          0x3A
#define GEN_CFG_ADDR            0x03
/*Read / Measuments*/

#define PCVM_0_ADDR        0x3E
#define PCVM_1_ADDR        0x3F
#define PCVM_2_ADDR        0x40
#define PCVM_3_ADDR        0x41
#define PCVM_4_ADDR        0x42
#define PCVM_5_ADDR        0x43
#define PCVM_6_ADDR        0x44
#define PCVM_7_ADDR        0x45
#define PCVM_8_ADDR        0x46
#define PCVM_9_ADDR        0x47
#define PCVM_10_ADDR       0x48
#define PCVM_11_ADDR       0x49
#define PCVM_12_ADDR       0x4A
#define PCVM_13_ADDR       0x4B
#define PCVM_14_ADDR       0x4C
#define PCVM_15_ADDR       0x4D
#define PCVM_16_ADDR       0x4E
#define PCVM_17_ADDR       0x4F
#define BVM_ADDR           0x52
#define INT_TEMP_0_ADDR    0x5C
#define INT_TEMP_1_ADDR    0x5D
#define GEN_DIAG_ADDR      0x0F
#define SCVM_HIGH_ADDR     0x50
#define SCVM_LOW_ADDR      0x51

#define EXT_TEMP_0_ADDR          0x005E
#define EXT_TEMP_1_ADDR          0x005F
#define EXT_TEMP_2_ADDR          0x0060
#define EXT_TEMP_3_ADDR          0x0061
#define EXT_TEMP_4_ADDR          0x0062
#define EXT_TEMP_5_ADDR          0x0063
#define EXT_TEMP_6_ADDR          0x0064
#define EXT_TEMP_7_ADDR          0x0065

// Cell Balancing 
#define BAL_CNT_CFG_0_ADDR    0x00E0
#define BAL_CNT_CFG_1_ADDR    0x00E1
#define BAL_CNT_CFG_2_ADDR    0x00E2
#define BAL_CNT_CFG_3_ADDR    0x00E3
#define BAL_CNT_CFG_4_ADDR    0x00E4
#define BAL_CNT_CFG_5_ADDR    0x00E5


#define BAL_CTRL_1_ADDR       0x00E7
#define BAL_CTRL_0_ADDR       0x00E6


/* timebase codes */
#define BAL_TB_MIN_2        0u   /* 00b */
#define BAL_TB_MIN_4        1u   /* 01b */
#define BAL_TB_MIN_8        2u   /* 10b (default) */
#define BAL_TB_MIN_16       3u   /* 11b */


/* ---- GEN_CFG: BAL_CNT_TIMEBASE at bits [6:5] ---- */
#define GENCFG_BAL_CNT_TIMEBASE_Pos   5u
#define GENCFG_BAL_CNT_TIMEBASE_Msk   (0x3u << GENCFG_BAL_CNT_TIMEBASE_Pos)


/* ---- BAL_CTRL_1 bits ---- */
#define BAL_CTRL1_START_CNT_Msk   (1u << 0)   /* START_CNT */
#define BAL_CTRL1_ALL_ON_Msk      (1u << 1)   /* ALL_ON */
#define BAL_CTRL1_ALL_OFF_Msk     (1u << 2)   /* ALL_OFF */
#define BAL_CTRL1_ON_0_Msk        (1u << 14)  /* ON_0 : cell 0 switch state */
#define BAL_CTRL1_ON_1_Msk        (1u << 15)  /* ON_1 : cell 1 switch state */


#define BAL_THRESHOLD_BITS        5u
#define THR_MAX                   ((1u << BAL_THRESHOLD_BITS) - 1u) /* 31*/ 




						 
/*Calculation Macros*/

#define PCVM_FACTOR        0.0000762939453125f       //VPCVM [V] = (5 V / 2^16) � ABCDH = 3.355 V
#define BVM_FACTOR         0.001373291015625f        //VBVM [V] = (90 V / 2^16) � ABCDH = 60.399 V
#define SCVM_FACTOR        0.00244140625f	     //VSCVM [V] = (5 V / 2^11) � 1010101111B = 1.677 V
#define SCVM_MASK          0x7FF


typedef struct SYSTEM_BMS_RAW_MEASUREMENTS{
    uint16_t cusId0;
    uint16_t PCVM[18];
    uint16_t BVM;
    uint16_t intTemp0;
    uint16_t intTemp1;
    uint16_t genDiag;
    uint16_t scvmHigh;
    uint16_t scvmLow;
    uint16_t extTemp[8];
}SystemUartAfeMeasRaw;

typedef struct SYSTEM_BMS_MEASUREMENTS{
    uint16_t cusId0;
    float PCVM[18];
    float BVM;
    float intTemp0;
    float intTemp1;
    uint16_t genDiag;
    float scvmHigh;
    float scvmLow;
    float extTemp[8];
}SystemUartAfeMeas;

typedef struct SYSTEM_AFE_READ{
    uint8_t id;
    uint8_t address;
}SystemAfeRead;

static const SystemAfeRead readPcvm[18] = {
    {0x1,PCVM_0_ADDR},
    {0x1,PCVM_1_ADDR},
    {0x1,PCVM_2_ADDR},
    {0x1,PCVM_3_ADDR},
    {0x1,PCVM_4_ADDR},
    {0x1,PCVM_5_ADDR},
    {0x1,PCVM_6_ADDR},
    {0x1,PCVM_7_ADDR},
    {0x1,PCVM_8_ADDR},
    {0x1,PCVM_9_ADDR},
    {0x1,PCVM_10_ADDR},
    {0x1,PCVM_11_ADDR},
    {0x1,PCVM_12_ADDR},
    {0x1,PCVM_13_ADDR},
    {0x1,PCVM_14_ADDR},
    {0x1,PCVM_15_ADDR},
    {0x1,PCVM_16_ADDR},
    {0x1,PCVM_17_ADDR}
};

static const SystemAfeRead readTemp[8] = {
    {0x1, EXT_TEMP_0_ADDR},
    {0x1, EXT_TEMP_1_ADDR},
    {0x1, EXT_TEMP_2_ADDR},
    {0x1, EXT_TEMP_3_ADDR},
    {0x1, EXT_TEMP_4_ADDR},
    {0x1, EXT_TEMP_5_ADDR},
    {0x1, EXT_TEMP_6_ADDR},
    {0x1, EXT_TEMP_7_ADDR}
};
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/
extern void SystemUartInit(void);
extern void SystemUartStop(void);
extern void SystemUartSndRdMsg(uint8_t IdFrame, uint8_t address);
extern uint8_t SystemUartCalcCRC(uint8_t *data, uint16_t len, uint8_t crcBits);
extern uint16_t SystemUartRdResponse(uint8_t Id, uint8_t address);
extern void SystemUartSndWrMsg(uint8_t IdFrame, uint8_t address, uint16_t data);
extern uint8_t SystemUartRdRply(void);
extern void SystemAfeInit(void);
extern void SystemUartRdAfe(void);
extern void SystemUartAfeCalc(void);
extern void SystemUartRdVoltage(void);
extern void SystemUartPcvmCanPacking(void);
extern void SystemAfeCanMsgOut(void);
extern void SystemUartRdTemp(void);

// Cell Balancing 
extern void     SystemAfeCellBalancingTask(void);
extern uint16_t SystemCellBalancingStart(uint8_t IdFrame,uint8_t timebaseCode,uint8_t *pcellThr, uint8_t enableMask);
extern uint16_t SystemCellBalanSetTimeBase(uint8_t IdFrame,uint8_t timebase_code);
extern uint16_t SystemCellWrtAllBalThreshold(uint8_t IdFrame, uint8_t *pcellThr);
//extern uint16_t SystemCellBalanCountConfigAdre(uint8_t idx);
extern uint16_t SystemCellBalanPack(uint8_t thr0, uint8_t thr1, uint8_t thr2);
extern uint16_t SystemCellEnableReq(uint8_t IdFrame, uint32_t enableMask);
extern uint16_t SystemCellStrBalanCount(void);

/*-----------------------------------------------------------------------------
** Exported Global Variable Declarations
**---------------------------------------------------------------------------*/
extern SystemUartAfeMeasRaw pRawMeasurements;
extern SystemUartAfeMeas pMeasurements;
#endif /*SYSTEM_TLE9018_H*/

/*--------------------------End SystemCan.h----------------------------------*/
