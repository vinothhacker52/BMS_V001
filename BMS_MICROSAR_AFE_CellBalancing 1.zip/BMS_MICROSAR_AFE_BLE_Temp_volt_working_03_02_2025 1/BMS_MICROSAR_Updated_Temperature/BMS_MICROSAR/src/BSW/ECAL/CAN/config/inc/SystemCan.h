/*-----------------------------------------------------------------------------
**                           � 2025 Ashokleyland
** File: SystemCan.h
**
** Description:
** Header file containing constants, data type definitions, and function
** prototypes for SystemCan functions
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_CAN_H
#define SYSTEM_CAN_H

/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/

//#include  "McuTypedefs.h"
#include "McuCan.h"
/*-----------------------------------------------------------------------------
** Local Defines/Typedefs/Enums/Macros
**---------------------------------------------------------------------------*/

/* CAN RX Buffers */

/* Example@ MCAL LAYER*/
#define   CCVSENG_CANRX_BUFFER                                    3U
#define   AMB_CANRX_BUFFER                                        4U
#define   EEC1_CANRX_BUFFER                                       0U
#define   EEC2_CANRX_BUFFER                                       1U
#define   EEC3_CANRX_BUFFER                                       2U
#define   EBC1_CANRX_BUFFER                                       5U
#define   EBC2_CANRX_BUFFER                                       6U
#define   IC1_CANRX_BUFFER                                        8U
#define   PTOENG_CANRX_BUFFER                                     9U
#define   TC1_CANRX_BUFFER                                        10U


/*TP  Messages RX Buffers*/

/*Example@ MCAL LAYER*/
#define   EC1_TPCM_CANRX_BUFFER                                  74U
#define   EC1_TPDT_CANRX_BUFFER                                  73U
#define   DUMMY1_BUFF					 	76U
#define   DUMMY2_BUFF					 	77U
#define   DUMMY3_BUFF					 	78U

/*CAN TX Buffers */

/* Example@ MCAL LAYER*/
#define   ETC1_CANTX_BUFFER                                      1U
#define   ETC2_CANTX_BUFFER                                      2U
#define   ETC7_CANTX_BUFFER                                      3U
#define   TSC1_CANTX_BUFFER                                      4U
#define   TSC2DIS_CANTX_BUFFER                                   5U

#define   CCVSENG_ID                         0x18FEF100
#define   AMB_ID                             0x18FEF500                                     
#define   EEC1_ID                            0xCF00400                                 
#define   EEC2_ID                            0xCF00300                                 
#define   EEC3_ID                            0x18FEDF00                                                                        
#define   EBC1_ID                            0x18F0010B                                
#define   EBC2_ID                            0x18FEBF0B                                                                   
#define   IC1_ID                             0x18FEF63D                                
#define   PTOENG_ID                          0x18FEF000 
#define   TC1_ID                             0x0C010305

/* @may be used in future*/
#define   DUMMY1			     0x11234567
#define   DUMMY2			     0x11234568
#define   DUMMY3			     0x11234569

#define   EC1_ID                             0x18FEE300  

#define  EC1_TPCM_ID                         0x18EBFF00
#define  EC1_TPDT_ID                         0x18ECFF00



#define ETC1_ID                             0xCF00203
#define ETC2_ID                             0x18F00503
#define TSC1_ID                             0xC000003
#define ETC7_ID                             0x18FE4A03
#define TSC2DIS_ID                          0x18FF8503
#define DM1_ID                              0x18FECA03
/*TP  Messages TX Buffers*/

/* Example@ MCAL LAYER*/
#define   DM1_TPCM_CANTX_BUFFER                                 6U
#define   DM1_TPDT_CANTX_BUFFER                                 7U
#define   DM1_CANTX_BUFFER                                      8U


#define CANPACKET_SIZE                                          8U

#define  CONTROL_BYTE_TP_CM_BAM                 0x20U
#define   PGN_EC1                           0x00FEE3U 


/*Macro used for receiving of TPCM*/
#define DATAPACKET_SIZE                             7U
#define MAX_TP_DT                                   39U
#define MAX_DM_FIELD                                10U

/*Flags for BAM message received*/
#define BAM_NOT_RECEIVED                            0U                                                                                           
#define BAM_TPCM_RECEIVED                           1U                                                          
#define BAM_ALLPACKET_RECEIVED                      2U
#define BAM_TPDT_MISSED                             3U
#define WRONG_MESSAGEID                             4U

/*
typedef enum CAN_ID_SPECIFIER
{
    EEC1		= 63,
    EEC2		= 64,
    EEC3		= 65,
    CCVS_ENG		= 66,					//ADD this is ECUAL
    AMB			= 67,
    EBC1		= 68,
    EBC2		= 69,
    KA_SHIFTER		= 70,
    IC1			= 71,
    PTO_ENG		= 72,
    TPCM_EC1		= 73,
    TPDT_EC1		= 74,
    EC1			= 75
}McuCanIdSpecifier
*/
/* PGN: 0x00EC00 - Storing the Transport Protocol Connection Management from the reading process */
typedef struct  {
	/* General */
	uint8_t control_byte;							/* What type of message are we going to send */
	
	/* RTS */
	uint16_t total_message_size_being_transmitted;	/* Total bytes our complete message includes - 9 to 1785 */
	uint8_t number_of_packages_being_transmitted;	/* How many times we are going to send packages via TP_DT - 2 to 224 because 1785/8 is 224 rounded up */
	
	uint8_t reserved_byte ;                         /*reserved byte*/
	/* General */
	uint32_t PGN_of_the_packeted_message;		/* Our message is going to activate a PGN */
	
}J1939_TP_CM;


/* PGN: 0x00EB00 - Storing the Transport Protocol Data Transfer from the reading process */
typedef struct  {
	uint8_t sequence_number;						/* When this sequence number is the same as number_of_packages from TP_CM, then we have our complete message */
	uint8_t data[MAX_TP_DT];						/* This is the collected data we are going to send. Also we are using this as a filler */
}J1939_TP_DT;

typedef struct 
{
	/*CAN message Structure*/
	uint8_t  data[CANPACKET_SIZE];		/* This is the CAN bus data  */
	_Bool 	errorStatus;			/* This flags becomes true after every successfull transmission. */
	_Bool	bufferStatus;             	/* This is a flag that going to be set to true for every time ID and data updates */
}SystemCan;

typedef struct 
{
    /*CAN message Structure*/


    uint8_t  data[MAX_TP_DT];  /*40U*/                    /* This is the CAN bus data  */
    _Bool 	errorStatus;
    _Bool	bufferStatus;                          /* This is a flag that going to be set to true for every time ID and data updates */	
	

}J1939_ServiceCan;



typedef struct
{
    
 _Bool MMMTempMsg_received;
 _Bool MMonTempMsg_received;
 _Bool MMonVoltMsg_received;
 _Bool SysFaultStsMsg_received;
 _Bool TotVoltMaxMinMsg_received;
 
}J1939_BMS_Received_Flags;

typedef struct 
{
    /*CAN message Structure*/
    uint8_t  MaxMonoTempNo;
    uint8_t  MinMonoTempNo;
    uint16_t MaxiMonoTemp;
    uint16_t MiniMonoTemp;
    uint8_t  LifeSignalMinMax;

}MaxMinMonTempMsg;

typedef struct 
{
    /*CAN message Structure*/
    uint8_t  MonoMerTemp1;
}MMonTempMsg;

typedef struct 
{
	/*CAN message Structure*/
    uint8_t  MonoMerVolt1;
}MMonVoltMsg;

typedef struct 
{
    _Bool  	AFEInitFail;
    _Bool 	AFETaskExecFail;
    _Bool  	AFEDataReadErr;
    _Bool 	AFEInternalStsFail;
    _Bool  	BMUOpenCktFail;
    _Bool  	BMUNtcOpenShortCktFail;
    _Bool  	SyncMsgFail;
    _Bool 	CalledTstMsgTmoutFail;
    _Bool  	CANSendFail;
    _Bool  	CANRxBufFull;
    _Bool  	CANOverFlowInt;
    _Bool 	CANBusOffTrig;
    _Bool 	ClockLockLoss;
    _Bool  	EquCmdExecFail;
    _Bool  	EquMOSFail;
    _Bool 	EquCktTempTooHigh;
    _Bool  	AnalogEEPROMInitFail;

}SysFaultStsMsg;

typedef struct 
{
    /*CAN message Structure*/
    uint8_t 	MaxMonVoltNo;
    uint16_t  	MaxMonVolt;
}TotVoltMaxMinMsg;

extern SystemCan CanMessage;
/*-----------------------------------------------------------------------------
** Exported Function Prototype Declarations
**---------------------------------------------------------------------------*/

extern SystemCan SystemCanReceiveData(uint32_t CanRxID);
_Bool SytemCanReadBufferStatus(uint32_t CanRxID);
extern uint8_t SystemCanSendData(McuCanChannel channelNum, McuCanIdFormat CanIDformat, uint32_t CanTxID, uint8_t  DLC,uint8_t *pData);
extern J1939_ServiceCan  J1939_Read_EC1_message(uint32_t CanRxID) ;
extern void McuCanPinInit(void);
/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/

#endif /*SYSTEM_CAN_H*/

/*--------------------------End SystemCan.h----------------------------------*/
