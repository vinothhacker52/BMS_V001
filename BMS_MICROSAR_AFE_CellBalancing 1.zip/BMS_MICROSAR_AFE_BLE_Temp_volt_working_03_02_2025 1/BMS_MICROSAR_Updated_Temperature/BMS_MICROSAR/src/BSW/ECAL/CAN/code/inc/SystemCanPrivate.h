/*-----------------------------------------------------------------------------
**                            ? 2025 Ashok Leyland                            
** File: SystemCanPrivate.h
**
** Description:
** General Header file for System Circuit
**---------------------------------------------------------------------------*/

#ifndef SYSTEM_CAN_PRIVATE_H
#define SYSTEM_CAN_PRIVATE_H



/*-----------------------------------------------------------------------------
** Exported Function Declarations
**---------------------------------------------------------------------------*/


#endif//SYSTEM_CAN_PRIVATE_H
