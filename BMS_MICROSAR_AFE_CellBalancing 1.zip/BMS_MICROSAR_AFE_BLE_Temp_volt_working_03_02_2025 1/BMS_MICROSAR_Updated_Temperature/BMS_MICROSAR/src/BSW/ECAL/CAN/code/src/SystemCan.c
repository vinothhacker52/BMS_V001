 /*-----------------------------------------------------------------------------
**                           @ 2025 Ashokleyland
** File:SystemCan.c
**
** Description:
** This source file defines the functions, macros and variables related
** to the operation of CAN Transmit and Receive
**---------------------------------------------------------------------------*/
/*****************************************************************************************************************************************
**                                              Revision Control History                                                               **
*****************************************************************************************************************************************/
/*
 * V1.0 	:  25-Jun-2025  : Initial Version
 
 * v1.8         :  21-Jul-2025  : Version Integrated with Temporary CAN drivers

 * v1.9		:  12-Aug-2025	: Changed the no of byte in EC1 message.
 */
/*-----------------------------------------------------------------------------
** Includes
**---------------------------------------------------------------------------*/
#include "SystemCan.h"
#include "string.h"
/*-----------------------------------------------------------------------------
** Local Function Prototype Declarations
**---------------------------------------------------------------------------*/

SystemCan CanMessage={0};


J1939_BMS_Received_Flags recvd_flag_sts;

/*-----------------------------------------------------------------------------
** Function: SytemCanReadBufferStatus
**
** Description:
** This function used to read the CAN message update status from the Rxbuffer
**                                              
** Arguments:
** CanRxID           : CAN receive ID
** Return values     : status
** CAN message update status
**---------------------------------------------------------------------------*/
#if 0
_Bool SytemCanReadBufferStatus(uint32_t CanRxID)
{

    McuCanBufferReceiveStatus status=MCU_CAN_BUFFER_MESSAGE_NOT_RECEIVED;
    int  const CANmessageID=(int)CanRxID;
    switch(CANmessageID)
    {

	case EEC2_ID:
	    {

		/* Example@ MCAL LAYER*/
		status=McuCanReadMsgReceiveStatus(EEC2_CANRX_BUFFER);

		/*read the status of EEC2 buffer from the CAN*/
		break;
	    }
	case EEC3_ID:
	    {

		/* Example@ MCAL LAYER*/
		status=McuCanReadMsgReceiveStatus(EEC3_CANRX_BUFFER);

		/*read the status of EEC3 buffer from the CAN*/
		break;
	    }
	case EBC1_ID:
	    {

		/* Example@ MCAL LAYER*/
		status=McuCanReadMsgReceiveStatus(EBC1_CANRX_BUFFER);

		/*read the status of EBC1 buffer from the CAN*/
		break;
	    }

	default:
	    {
		status=MCU_CAN_BUFFER_MESSAGE_NOT_RECEIVED;
		/*default state*/
		break;
	    }	
	    /* Add more switch statement here */

    }
    return (_Bool)status;
}

/*------------------------ End SytemCanReadBufferStatus()-------------------------*/
#endif
/*-----------------------------------------------------------------------------
** Function: J1939_Send_Messages
**
** Description:
** This function used to send j1939 Messages to the CAN network
**                                              
** Arguments:
** CanRxID        : CAN receive ID
** CanData        : CAN Receive message data 
** Return values  : None
**---------------------------------------------------------------------------*/
#if 1
SystemCan SystemCanReceiveData(uint32_t CanRxID)
{
    McuCanRxMsg canRxMsg={0};
    uint8_t dataCount = 0U;
    int  const CANmessageID=(int)CanRxID;
    switch(CANmessageID)
    {
	case CCVSENG_ID: 
	    {

		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(CCVSENG_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of CCVSENG buffer from the CAN*/

		break;
	    }
	case AMB_ID: 
	    {

		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(AMB_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of AMB buffer from the CAN*/

		break;
	    }
	case EEC1_ID: 
	    {

		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EEC1_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EEC1 buffer from the CAN*/

		break;
	    }
	case EEC2_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EEC2_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EEC2 buffer from the CAN*/
		break;
	    }
	case EEC3_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EEC3_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EEC3 buffer from the CAN*/
		break;
	    }
	case EBC1_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EBC1_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EBC1 buffer from the CAN*/
		break;
	    }
	case EBC2_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EBC2_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EBC2 buffer from the CAN*/
		break;
	    }
	case IC1_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(IC1_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of IC1 buffer from the CAN*/
		break;
	    }
	case PTOENG_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(PTOENG_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of PTOENG buffer from the CAN*/
		break;
	    }
	case TC1_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(TC1_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of TC1 buffer from the CAN*/
		break;
	    }
	case EC1_TPDT_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EC1_TPDT_CANRX_BUFFER);

		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EC1_TPDT  buffer from the CAN*/
		break;
	    }
	case EC1_TPCM_ID: 
	    {
		/* Example@ MCAL LAYER*/
		canRxMsg = McuCanRx(EC1_TPCM_CANRX_BUFFER);
		//memcpy(CanData->data,CanMessage.data, sizeof(CanMessage.data));

		/*read the data of EC1_TPCM  buffer from the CAN*/

		break;
	    }
	     case DUMMY1:
	    {

		/* Example@ MCAL LAYER*/

		canRxMsg=McuCanRx(DUMMY1_BUFF);

		/*read the status of EC1_TPCM buffer from the CAN*/
		break;
	    }
	    case DUMMY2:
	    {

		/* Example@ MCAL LAYER*/

		canRxMsg=McuCanRx(DUMMY2_BUFF);

		/*read the status of EC1_TPCM buffer from the CAN*/
		break;
	    }
	    case DUMMY3:
	    {

		/* Example@ MCAL LAYER*/

		canRxMsg=McuCanRx(DUMMY3_BUFF);

		/*read the status of EC1_TPCM buffer from the CAN*/
		break;
	    }
	    /* Add more switch statement here */
	default:
	    {
		/*default state*/

		break;
	    }




    }
    for(dataCount = 0U; dataCount<CANPACKET_SIZE ; dataCount++)
    {
	CanMessage.data[dataCount] = canRxMsg.data[dataCount];
    }
    CanMessage.bufferStatus = (_Bool)canRxMsg.receiveStatus;
    CanMessage.errorStatus =(_Bool)0;
    return CanMessage;
}
#endif
/*--------------------------- End SystemCanReceiveData()-----------------------------*/

/*-----------------------------------------------------------------------------------
** Function: SystemCanSendData
**
** Description:
** This function used  to send CAN Messages to the CAN Bus
**                                              
** Arguments:
** CanTxID        : CAN Transmit ID
** CanData        : CAN  Transmit message data
** CAN transmission return type
**--------------------------------------------------------------------------------*/

uint8_t SystemCanSendData(McuCanChannel channelNum, McuCanIdFormat CanIDformat, uint32_t CanTxID, uint8_t  DLC,uint8_t *pData)
{
    const McuCanMode canMode=MCU_CAN;
    uint8_t  status = 0U;
    McuCanTx(channelNum,CanTxID,canMode,DLC,pData,CanIDformat);
    status=1U;
    return status;
}


